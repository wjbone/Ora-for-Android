package net.ora.mobile.core;

import java.sql.SQLException;
import java.util.List;

import net.ora.mobile.dao.FeedDBHelper;
import net.ora.mobile.dao.configuration.BaseConfiguration;

import android.content.Context;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.Dao.CreateOrUpdateStatus;
import com.j256.ormlite.stmt.QueryBuilder;

public class OraConfiguration {

	private Context context;
	private FeedDBHelper helper;
	
	public OraConfiguration(Context context) {
		this.context = context;
	}
	
    public Context getContext() {
		return context;
	}

	public void setContext(Context context) {
		this.context = context;
	}

	protected FeedDBHelper getHelper() {
        if (helper == null) {
        	helper = OpenHelperManager.
        			getHelper(getContext(), FeedDBHelper.class);
        }
        return helper;
    }
 
	public void close() {
        if (helper != null) {
            OpenHelperManager.releaseHelper();
            helper = null;
        }
    }
	
	/*
	 * 
	 */
	private BaseConfiguration getBaseConfiguration() throws SQLException {
		Dao<BaseConfiguration, ?> configurationDao = getHelper().getConfigurationDao();
		QueryBuilder<BaseConfiguration, ?> builder = configurationDao.queryBuilder();
		builder.limit(1L);
		List<BaseConfiguration> configurations = builder.query();
		
		BaseConfiguration configuration;
		if(configurations.size() == 0) {
			configuration = new BaseConfiguration();
			
			// Default values
			configuration.setLoadCircles(true);
			configuration.setLoadFeed(true);
		} else {
			configuration = configurations.get(0);
		}
		
		// Save
		configurationDao.createOrUpdate(configuration);
		return configuration;
	}
	
	public boolean isFirstTimeLoadingCircles() {
		try {
			BaseConfiguration configuration = getBaseConfiguration();
			return configuration.getLoadCircles();
		} catch (SQLException e) {
		}
		
		return true;
	}
	
	public void setFirstTimeLoadingCircles(boolean loadCircles) {
		try {
			Dao<BaseConfiguration, ?> configurationDao = 
					getHelper().getConfigurationDao();
			
			// Save
			BaseConfiguration configuration = getBaseConfiguration();
			configuration.setLoadCircles(loadCircles);
			configurationDao.createOrUpdate(configuration);
		} catch (SQLException e) {
		}
	}
	
	public boolean isFirstTimeLoadingFeed() {
		try {
			BaseConfiguration configuration = getBaseConfiguration();
			return configuration.getLoadFeed();
		} catch (SQLException e) {
		}
		
		return true;
	}
	
	public void setFirstTimeLoadingFeed(boolean loadFeed) {
		try {
			Dao<BaseConfiguration, ?> configurationDao = 
					getHelper().getConfigurationDao();
			
			// Save
			BaseConfiguration configuration = getBaseConfiguration();
			configuration.setLoadFeed(loadFeed);
			configurationDao.createOrUpdate(configuration);
		} catch (SQLException e) {
		}
	}
}
