package net.ora.mobile.dao.configuration;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class BaseConfiguration {
	public static final String COLUMN_NEXT_PAGE_FEED = "next_page_feed";

	@DatabaseField(generatedId = true)
	protected Integer id;
	
	@DatabaseField
	protected boolean loadCircles;
	
	@DatabaseField
	protected boolean loadFeed;
	
	@DatabaseField(columnName = COLUMN_NEXT_PAGE_FEED)
	protected int nexPageFeed;

	/*
	 * 
	 */
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean getLoadCircles() {
		return loadCircles;
	}

	public void setLoadCircles(boolean loadCircles) {
		this.loadCircles = loadCircles;
	}
	
	public boolean getLoadFeed() {
		return loadFeed;
	}

	public void setLoadFeed(boolean loadFeed) {
		this.loadFeed = loadFeed;
	}

	public int getNexPageFeed() {
		return nexPageFeed;
	}

	public void setNextPageFeed(int nexPageFeed) {
		this.nexPageFeed = nexPageFeed;
	}
	
//	/*
//	 * 
//	 */
//	public BaseConfiguration() {
//		loadCircles = true;
//		loadFeed = true;
//	}
}
