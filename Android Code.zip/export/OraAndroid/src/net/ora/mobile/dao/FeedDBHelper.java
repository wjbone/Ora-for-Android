package net.ora.mobile.dao;

import java.sql.SQLException;

import net.ora.mobile.dao.configuration.BaseConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.feed.Inspiration;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.PrayerAndCircle;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.digitalgeko.mobile.android.objects.User;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

public class FeedDBHelper extends OrmLiteSqliteOpenHelper {

	private static final String DATABASE_NAME = "ora.db";
	private static final int DATABASE_VERSION = 5;

	private Dao<BaseConfiguration, Integer> configurationDao;
	private Dao<User, Integer> userDao;
	private Dao<Circle, Integer> circleDao;
	private Dao<Prayer, Integer> prayerDao;
	private Dao<PrayerAndCircle, Integer> prayerAndCirclesDao;
	private Dao<Inspiration, Integer> inspirationDao;

	public FeedDBHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
		try {
			TableUtils.createTable(connectionSource, BaseConfiguration.class);
			TableUtils.createTable(connectionSource, User.class);
			TableUtils.createTable(connectionSource, Circle.class);
			TableUtils.createTable(connectionSource, Prayer.class);
			TableUtils.createTable(connectionSource, PrayerAndCircle.class);
			TableUtils.createTable(connectionSource, Inspiration.class);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVersion, int newVersion) {
		try {

			if (newVersion == 2 && oldVersion == 1) {
				getConfigurationDao().executeRaw(
						"ALTER TABLE `BaseConfiguration` ADD COLUMN " + BaseConfiguration.COLUMN_NEXT_PAGE_FEED + " INTEGER;");
			} else if (newVersion == 5) {
				switch (oldVersion) {
				case 2:
					TableUtils.createTable(connectionSource, Inspiration.class);
				case 3:
					getConfigurationDao()
							.executeRaw("ALTER TABLE `Circle` ADD COLUMN " + Circle.FIELD_IS_COMMUNITY + " INTEGER;");
				case 4:
					getConfigurationDao().executeRaw(
							"ALTER TABLE `Circle` ADD COLUMN " + Circle.FIELD_ANNOUNCEMENTS_COUNT + " INTEGER;");
				}
			} else {
				onCreate(db, connectionSource);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Dao<BaseConfiguration, Integer> getConfigurationDao() throws SQLException {
		if (configurationDao == null) {
			configurationDao = getDao(BaseConfiguration.class);
		}
		return configurationDao;
	}

	public Dao<User, Integer> getUserDao() throws SQLException {
		if (userDao == null) {
			userDao = getDao(User.class);
		}
		return userDao;
	}

	public Dao<Circle, Integer> getCircleDao() throws SQLException {
		if (circleDao == null) {
			circleDao = getDao(Circle.class);
		}
		return circleDao;
	}

	public Dao<Prayer, Integer> getPrayerDao() throws SQLException {
		if (prayerDao == null) {
			prayerDao = getDao(Prayer.class);
		}
		return prayerDao;
	}

	public Dao<PrayerAndCircle, Integer> getPrayerAndCirclesDao() throws SQLException {
		if (prayerAndCirclesDao == null) {
			prayerAndCirclesDao = getDao(PrayerAndCircle.class);
		}
		return prayerAndCirclesDao;
	}

	public Dao<Inspiration, Integer> getInspirationDao() throws SQLException {
		if (inspirationDao == null) {
			inspirationDao = getDao(Inspiration.class);
		}
		return inspirationDao;
	}

	public void clearData() {
		try {
			getConfigurationDao().delete(getConfigurationDao().queryForAll());
		} catch (SQLException e) {
		}
		try {
			getPrayerAndCirclesDao().delete(getPrayerAndCirclesDao().queryForAll());
		} catch (SQLException e) {
		}
		try {
			getPrayerDao().delete(getPrayerDao().queryForAll());
		} catch (SQLException e) {
		}
		try {
			getCircleDao().delete(getCircleDao().queryForAll());
		} catch (SQLException e) {
		}
		try {
			getUserDao().delete(getUserDao().queryForAll());
		} catch (SQLException e) {
		}
	}

	@Override
	public void close() {
		super.close();
		userDao = null;
		circleDao = null;
		configurationDao = null;
	}
}