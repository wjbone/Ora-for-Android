package net.ora.mobile.dto.profile.response;

import com.digitalgeko.mobile.android.objects.FriendUser;
import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class SuggestedFriendsResponse extends ServiceResponse {

	@JsonProperty(value="users")
	private FriendUser[] friendsList;

	public FriendUser[] getFriendsList() {
		return friendsList;
	}

	public void setFriendsList(FriendUser[] friendsList) {
		this.friendsList = friendsList;
	}
	
}
