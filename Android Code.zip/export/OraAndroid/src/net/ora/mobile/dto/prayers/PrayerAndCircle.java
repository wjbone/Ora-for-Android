package net.ora.mobile.dto.prayers;

import net.ora.mobile.dto.circles.Circle;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class PrayerAndCircle {

	@DatabaseField(generatedId = true) 
	protected Integer id;
	
	@DatabaseField(foreign = true, columnName = Circle.FOREIGN_FIELD_ID, index = true)
	protected Circle circle;
	
	@DatabaseField(foreign = true, columnName = Prayer.FOREIGN_FIELD_ID, index = true)
	protected Prayer prayer;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Circle getCircle() {
		return circle;
	}

	public void setCircle(Circle circle) {
		this.circle = circle;
	}

	public Prayer getPrayer() {
		return prayer;
	}

	public void setPrayer(Prayer prayer) {
		this.prayer = prayer;
	}
}
