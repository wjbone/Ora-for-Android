package net.ora.mobile.dto.circles.response;


public class CancelCircleRequestResponse extends CircleResponse {
}
