package net.ora.mobile.dto.prayers.response;

import java.util.List;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PrayedUsersForPrayerResponse extends ServiceResponse {

	@JsonProperty(value="user_list")
	public List<CircleMember> userList;

	public List<CircleMember> getUserList() {
		return userList;
	}

	public void setUserList(List<CircleMember> userList) {
		this.userList = userList;
	}
}
