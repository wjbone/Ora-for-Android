package net.ora.mobile.dto.circles;

import net.ora.mobile.android.R;
import android.os.Parcel;
import android.os.Parcelable;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class Circle implements Parcelable {

	public static final String FOREIGN_FIELD_ID = "circle_id";
	public static final String FIELD_NAME = "name";
	public static final String FIELD_IS_COMMUNITY = "is_community";
	public static final String FIELD_ANNOUNCEMENTS_COUNT = "announcements_count";

	@DatabaseField(id = true, index = true)
	protected int id;

	@DatabaseField(columnName = FIELD_NAME)
	protected String name;

	@DatabaseField
	@JsonProperty(value = "is_lite")
	protected boolean isLite;

	@DatabaseField
	protected String about;

	@DatabaseField
	protected String city;

	@DatabaseField
	@JsonProperty(value = "private")
	protected boolean isPrivate;

	@DatabaseField
	@JsonProperty(value = "approves_members")
	protected boolean approvesMembers;

	@DatabaseField
	protected String picture;

	@DatabaseField
	@JsonProperty(value = "is_owner")
	protected boolean isOwner;

	@DatabaseField
	@JsonProperty(value = "is_member")
	protected boolean isMember;

	@DatabaseField
	@JsonProperty(value = "is_requested")
	protected boolean isRequested;

	@JsonProperty(value = "parent_circle")
	protected Circle parentCircle;

	@DatabaseField(columnName = FIELD_IS_COMMUNITY)
	@JsonProperty(value = "is_community")
	protected boolean isCommunity;

	@DatabaseField
	@JsonProperty(value = "prayers_count")
	protected int prayersCount;

	@DatabaseField
	@JsonProperty(value = "members_count")
	protected int membersCount;

	@DatabaseField(foreign = true, foreignAutoRefresh = true, columnName = User.FOREIGN_FIELD_USER_ID)
	protected User user;

	@DatabaseField
	@JsonProperty(value = "related_circles_count")
	protected int relatedCirculesCount;

	@DatabaseField
	@JsonProperty(value = "date_created")
	protected String dateCreated;

	@DatabaseField
	@JsonProperty(value = "announcements_count")
	protected int announcementsCount;

	/*
	 * 
	 */
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}

	public boolean isMember() {
		return isMember;
	}

	public void setMember(boolean isMember) {
		this.isMember = isMember;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}

	public Circle getParentCircle() {
		return parentCircle;
	}

	public void setParentCircle(Circle parentCircle) {
		this.parentCircle = parentCircle;
	}

	public boolean isCommunity() {
		return isCommunity;
	}

	public void setCommunity(boolean isCommunity) {
		this.isCommunity = isCommunity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isLite() {
		return isLite;
	}

	public void setLite(boolean isLite) {
		this.isLite = isLite;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public boolean isPrivate() {
		return isPrivate;
	}

	public void setPrivate(boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public boolean isApprovesMembers() {
		return approvesMembers;
	}

	public void setApprovesMembers(boolean approvesMembers) {
		this.approvesMembers = approvesMembers;
	}

	public int getPrayersCount() {
		return prayersCount;
	}

	public void setPrayersCount(int prayersCount) {
		this.prayersCount = prayersCount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getRelatedCirculesCount() {
		return relatedCirculesCount;
	}

	public void setRelatedCirculesCount(int relatedCirculesCount) {
		this.relatedCirculesCount = relatedCirculesCount;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public int getMembersCount() {
		return membersCount;
	}

	public void setMembersCount(int membersCount) {
		this.membersCount = membersCount;
	}

	public int getAnnouncementsCount() {
		return announcementsCount;
	}

	public void setAnnouncementsCount(int announcementsCount) {
		this.announcementsCount = announcementsCount;
	}

	/*
	 * 
	 */
	@Override
	public boolean equals(Object o) {
		if (o instanceof Circle) {
			Circle other = (Circle) o;
			return getId() == other.getId();
		}
		return super.equals(o);
	}

	public int getSecurityLevelId() {
		if (isPrivate()) {
			return R.string.addCircle_lblScopeSecret;
		} else {
			if (isApprovesMembers()) {
				return R.string.addCircle_lblScopeClosed;
			} else {
				return R.string.addCircle_lblScopePublic;
			}
		}
	}

	/*
	 * 
	 */

	public Circle() {
		super();
	}

	protected Circle(Parcel in) {
		name = in.readString();
		isLite = in.readByte() != 0x00;
		about = in.readString();
		city = in.readString();
		isPrivate = in.readByte() != 0x00;
		approvesMembers = in.readByte() != 0x00;
		picture = in.readString();
		isOwner = in.readByte() != 0x00;
		isMember = in.readByte() != 0x00;
		isRequested = in.readByte() != 0x00;
		parentCircle = in.readParcelable(Circle.class.getClassLoader());
		isCommunity = in.readByte() != 0x00;
		id = in.readInt();
		prayersCount = in.readInt();
		membersCount = in.readInt();
		user = in.readParcelable(User.class.getClassLoader());
		relatedCirculesCount = in.readInt();
		dateCreated = in.readString();
		announcementsCount = in.readInt();
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(name);
		dest.writeByte((byte) (isLite ? 0x01 : 0x00));
		dest.writeString(about);
		dest.writeString(city);
		dest.writeByte((byte) (isPrivate ? 0x01 : 0x00));
		dest.writeByte((byte) (approvesMembers ? 0x01 : 0x00));
		dest.writeString(picture);
		dest.writeByte((byte) (isOwner ? 0x01 : 0x00));
		dest.writeByte((byte) (isMember ? 0x01 : 0x00));
		dest.writeByte((byte) (isRequested ? 0x01 : 0x00));
		dest.writeParcelable(parentCircle, 0);
		dest.writeByte((byte) (isCommunity ? 0x01 : 0x00));
		dest.writeInt(id);
		dest.writeInt(prayersCount);
		dest.writeInt(membersCount);
		dest.writeParcelable(user, 0);
		dest.writeInt(relatedCirculesCount);
		dest.writeString(dateCreated);
		dest.writeInt(announcementsCount);
	}

	public static final Parcelable.Creator<Circle> CREATOR = new Parcelable.Creator<Circle>() {
		public Circle createFromParcel(Parcel in) {
			return new Circle(in);
		}

		public Circle[] newArray(int size) {
			return new Circle[size];
		}
	};

}
