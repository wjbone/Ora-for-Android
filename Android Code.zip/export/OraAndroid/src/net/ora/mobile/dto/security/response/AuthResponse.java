package net.ora.mobile.dto.security.response;

import com.digitalgeko.mobile.android.objects.User;

import net.ora.mobile.dto.ServiceResponse;

public class AuthResponse extends ServiceResponse{

	protected User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	// {"status": true, "message": "User has been created and logged in", "user": {"username": "Byron", "city": "", "about": "", "mobile": "", "notifications_count": 0, "fb_id": "", "email": "byoms23@gmail.com", "is_premium": true, "profile_picture": "", "tw_id": "", "ignore_lite": false, "id": 852}}

}
