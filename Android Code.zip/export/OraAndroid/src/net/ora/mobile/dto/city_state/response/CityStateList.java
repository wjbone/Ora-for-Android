package net.ora.mobile.dto.city_state.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class CityStateList extends ServiceResponse {

	@JsonProperty(value = "cities_states")
	private String[] citiesStates;

	public String[] getCitiesStates() {
		return (citiesStates != null) ? citiesStates : new String[]{};
	}

	public void setCitiesStates(String[] citiesStates) {
		this.citiesStates = citiesStates;
	}
}
