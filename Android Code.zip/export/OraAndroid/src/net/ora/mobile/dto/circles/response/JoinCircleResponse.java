package net.ora.mobile.dto.circles.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JoinCircleResponse extends CircleResponse {

	@JsonProperty(value="is_full")
	protected boolean isFull;

	public boolean isFull() {
		return isFull;
	}

	public void setFull(boolean isFull) {
		this.isFull = isFull;
	}
}
