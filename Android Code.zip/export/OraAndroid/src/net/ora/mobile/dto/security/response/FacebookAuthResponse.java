package net.ora.mobile.dto.security.response;

public class FacebookAuthResponse extends AuthResponse {

	protected Boolean registered;

	public Boolean getRegistered() {
		return registered;
	}

	public void setRegistered(Boolean registered) {
		this.registered = registered;
	}
	
}
