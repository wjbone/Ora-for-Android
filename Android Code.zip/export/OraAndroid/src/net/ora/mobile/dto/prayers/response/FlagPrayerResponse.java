package net.ora.mobile.dto.prayers.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class FlagPrayerResponse extends ServiceResponse {

	protected String prayer_id;
	
	@JsonProperty(value="is_flagged")
	protected boolean isFlagged;
	
	public String getPrayer_id() {
		return prayer_id;
	}

	public void setPrayer_id(String prayer_id) {
		this.prayer_id = prayer_id;
	}

	public boolean isFlagged() {
		return isFlagged;
	}
	
	public void setFlagged(boolean isFlagged) {
		this.isFlagged = isFlagged;
	}
}
