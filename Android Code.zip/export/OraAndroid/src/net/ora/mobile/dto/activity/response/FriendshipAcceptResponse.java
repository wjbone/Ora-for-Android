package net.ora.mobile.dto.activity.response;

import net.ora.mobile.dto.ServiceResponse;

public class FriendshipAcceptResponse extends ServiceResponse {

}
