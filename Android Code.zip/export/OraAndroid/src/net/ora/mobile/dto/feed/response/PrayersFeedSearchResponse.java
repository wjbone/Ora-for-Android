package net.ora.mobile.dto.feed.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PrayersFeedSearchResponse extends PrayersFeedResponse {

	@JsonProperty(value = "total_search_results_count")
	protected int totalSearchResultsCount;

	public int getTotalSearchResultsCount() {
		return totalSearchResultsCount;
	}

	public void setTotalSearchResultsCount(int totalSearchResultsCount) {
		this.totalSearchResultsCount = totalSearchResultsCount;
	}

}
