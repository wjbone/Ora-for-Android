package net.ora.mobile.dto.activity.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class CancelRequestResponse extends ServiceResponse {

	@JsonProperty(value="is_friend")
	private boolean friend;
	
	@JsonProperty(value="is_requested")
	private boolean request;
	
	private int user_id;

	public boolean isFriend() {
		return friend;
	}

	public void setFriend(boolean friend) {
		this.friend = friend;
	}

	public boolean isRequest() {
		return request;
	}

	public void setRequest(boolean request) {
		this.request = request;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
}
