package net.ora.mobile.dto;

/**
 * @author Byron
 *
 * @param <T>
 */
public class ServiceResponse {
	
	protected boolean status;
	
	protected String message;
	
	protected String errors;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getErrors() {
		return errors;
	}
	
	public void setErrors(String errors) {
		this.errors = errors;
	}
	
}
