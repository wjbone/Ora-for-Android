package net.ora.mobile.dto.profile.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class RequestFriendResponse extends ServiceResponse {

	@JsonProperty(value="user_id")
	protected int userId;
	
	@JsonProperty(value="is_friend")
	protected boolean isFriend;
	
	@JsonProperty(value="is_requested")
	protected boolean isRequested;
	
	public boolean isFriend() {
		return isFriend;
	}

	public void setFriend(boolean isFriend) {
		this.isFriend = isFriend;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}
	
	
}
