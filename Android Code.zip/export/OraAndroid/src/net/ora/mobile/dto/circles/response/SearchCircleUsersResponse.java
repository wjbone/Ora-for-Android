package net.ora.mobile.dto.circles.response;

import java.util.List;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.CircleMember;

public class SearchCircleUsersResponse extends ServiceResponse {

	protected List<CircleMember> users;

	public List<CircleMember> getUsers() {
		return users;
	}

	public void setUsers(List<CircleMember> users) {
		this.users = users;
	}
}
