package net.ora.mobile.dto.prayers.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class PrayerListAddResponse extends ServiceResponse {

	@JsonProperty(value="is_in_my_list")
	protected boolean isInMyList;

	public boolean isInMyList() {
		return isInMyList;
	}

	public void setInMyList(boolean isInMyList) {
		this.isInMyList = isInMyList;
	}
}
