package net.ora.mobile.dto.activity.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.activity.Notification;

public class PrayersInteractionsResponse extends ServiceResponse {

	protected List<Notification> feed;
	
	@JsonProperty(value="next_page")
	protected int nextPage;

	public List<Notification> getFeed() {
		return feed;
	}

	public void setFeed(List<Notification> feed) {
		this.feed = feed;
	}

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	
}
