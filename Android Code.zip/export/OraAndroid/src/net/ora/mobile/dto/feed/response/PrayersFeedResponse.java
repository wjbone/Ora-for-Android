package net.ora.mobile.dto.feed.response;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.feed.Inspiration;
import net.ora.mobile.dto.prayers.Prayer;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PrayersFeedResponse extends ServiceResponse {
	
	public final static PrayersFeedResponse EMPTY_RESPONSE;
	
	static {
		EMPTY_RESPONSE = new PrayersFeedResponse();
		EMPTY_RESPONSE.setNextPage(-1);
		EMPTY_RESPONSE.setPrayers(new ArrayList<Prayer>());
	}

	@JsonProperty(value="next_page")
	protected int nextPage;
	
	protected List<Prayer> prayers;
	
	protected Inspiration inspiration;

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}

	public List<Prayer> getPrayers() {
		return prayers;
	}

	public void setPrayers(List<Prayer> prayers) {
		this.prayers = prayers;
	}
	
	@JsonProperty(value="prayer_list")
	public void setPrayersList(List<Prayer> prayers) {
		this.prayers = prayers;
	}

	public Inspiration getInspiration() {
		return inspiration;
	}

	public void setInspiration(Inspiration inspiration) {
		this.inspiration = inspiration;
	}
}
