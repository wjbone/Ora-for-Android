package net.ora.mobile.dto.profile.response;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GetProfileResponse extends ServiceResponse {

	@JsonProperty(value="user")
	protected User profileUser;

	public User getProfileUser() {
		return profileUser;
	}

	public void setProfileUser(User profileUser) {
		this.profileUser = profileUser;
	}
	
}
