package net.ora.mobile.dto.activity.response;

import net.ora.mobile.dto.ServiceResponse;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CircleInviteAcceptResponse extends ServiceResponse {

	@JsonProperty(value="is_member")
	private boolean isMember;
	
	@JsonProperty(value="is_requested")
	private boolean isRequested;
	
	@JsonProperty(value="is_owner")
	private boolean isOwner;
	
	@JsonProperty(value="is_full")
	private boolean isFulle;
	
	private JSONObject circle;

	public boolean isMember() {
		return isMember;
	}

	public void setMember(boolean isMember) {
		this.isMember = isMember;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}

	public boolean isFulle() {
		return isFulle;
	}

	public void setFulle(boolean isFulle) {
		this.isFulle = isFulle;
	}

	public JSONObject getCircle() {
		return circle;
	}

	public void setCircle(JSONObject circle) {
		this.circle = circle;
	}
	
	
}
