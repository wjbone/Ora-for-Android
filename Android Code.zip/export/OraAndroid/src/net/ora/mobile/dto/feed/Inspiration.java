package net.ora.mobile.dto.feed;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class Inspiration {

	@DatabaseField(id = true, index = true)
	protected int id;

	@DatabaseField
	protected String image;

	@DatabaseField
	@JsonProperty("date_to_air")
	protected String dateToAir;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDateToAir() {
		return dateToAir;
	}

	public void setDateToAir(String dateToAir) {
		this.dateToAir = dateToAir;
	}
}
