package net.ora.mobile.dto.prayers.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class AddCommentResponse extends ServiceResponse {

	protected Prayer prayer;
	
	@JsonProperty(value="comment_id")
	protected int commentId;
	
	protected String text;

	public Prayer getPrayer() {
		return prayer;
	}

	public void setPrayer(Prayer prayer) {
		this.prayer = prayer;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
