package net.ora.mobile.dto.circles.response;

import java.util.List;

import com.digitalgeko.mobile.android.objects.CircleMember;

import net.ora.mobile.dto.ServiceResponse;

public class FriendsMembershipResponse extends ServiceResponse {

	private List<CircleMember> users;

	public List<CircleMember> getUsers() {
		return users;
	}

	public void setUsers(List<CircleMember> users) {
		this.users = users;
	}
}
