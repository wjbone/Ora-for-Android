package net.ora.mobile.dto.circles.response;

import java.util.List;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.CircleMember;

public class CircleMembersResponse extends ServiceResponse {

	protected List<CircleMember> members;

	public List<CircleMember> getMembers() {
		return members;
	}

	public void setMembers(List<CircleMember> members) {
		this.members = members;
	}
	
	
}
