package net.ora.mobile.dto.activity.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class CircleInviteDeclineResponse extends ServiceResponse {

	@JsonProperty(value="is_member")
	private boolean isMember;
	
	@JsonProperty(value="is_requested")
	private boolean isRequested;
	
	@JsonProperty(value="is_owner")
	private boolean isOwner;

	public boolean isMember() {
		return isMember;
	}

	public void setMember(boolean isMember) {
		this.isMember = isMember;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}
	
}
