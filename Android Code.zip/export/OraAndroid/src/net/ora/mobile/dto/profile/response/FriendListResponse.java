package net.ora.mobile.dto.profile.response;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.FriendUser;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FriendListResponse extends ServiceResponse {

	@JsonProperty(value="friends_list")
	private FriendUser[] friendsList;

	public FriendUser[] getFriendsList() {
		return friendsList;
	}

	public void setFriendsList(FriendUser[] friendsList) {
		this.friendsList = friendsList;
	}
	
}
