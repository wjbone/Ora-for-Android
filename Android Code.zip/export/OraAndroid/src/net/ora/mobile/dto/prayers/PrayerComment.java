package net.ora.mobile.dto.prayers;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PrayerComment {

	// {"text": "Bla Bla ", "user": {"is_requested": false,
	// "profile_picture": "", "id": 852, "is_friend": false, "name": "Byron"},
	// "is_flagged": false, "id": 280, "date_created": "27-06-2013T19:12:08"}
	//
	// {"text": "New ", "user": {"is_requested": false, "profile_picture": "",
	// "id": 852, "is_friend": false, "name": "Byron"}, "is_flagged": false,
	// "id": 279, "date_created": "27-06-2013T19:10:56"}]}

	protected String text;
	
	protected User user;
	
	@JsonProperty(value="is_flagged")
	protected boolean isFlagged;
	
	public int id;
	
	@JsonProperty(value="date_created")
	public String dateCreated;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public boolean isFlagged() {
		return isFlagged;
	}

	public void setFlagged(boolean isFlagged) {
		this.isFlagged = isFlagged;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	
}
