package net.ora.mobile.dto.profile.request;

import java.util.List;

import com.digitalgeko.mobile.android.objects.profile.PhoneContact;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SuggestedUsersV2Request {

	private List<PhoneContact> contacts;
	
	@JsonProperty(value="access_token")
	private String accessToken;
	
	public SuggestedUsersV2Request() {
	}

	public List<PhoneContact> getContacts() {
		return contacts;
	}

	public void setContacts(List<PhoneContact> contacts) {
		this.contacts = contacts;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
}
