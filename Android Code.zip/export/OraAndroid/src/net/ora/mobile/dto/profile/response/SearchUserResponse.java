package net.ora.mobile.dto.profile.response;

import com.digitalgeko.mobile.android.objects.FriendUser;

import net.ora.mobile.dto.ServiceResponse;

public class SearchUserResponse extends ServiceResponse {

	private int next_page;
	
	private FriendUser[] users;

	public int getNext_page() {
		return next_page;
	}

	public void setNext_page(int next_page) {
		this.next_page = next_page;
	}

	public FriendUser[] getUsers() {
		return users;
	}

	public void setUsers(FriendUser[] users) {
		this.users = users;
	}
	
}
