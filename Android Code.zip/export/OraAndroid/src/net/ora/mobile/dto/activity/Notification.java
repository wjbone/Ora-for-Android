package net.ora.mobile.dto.activity;

import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.PrayerComment;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Notification {

	// Prayer notifications
	public static final String TYPE_ANSWERED = "answered";
	public static final String TYPE_COMMENT = "comment";
	public static final String TYPE_LIKE = "like";
	// Circle notifications
	public static final String TYPE_USER_JOINED = "user_joined";
	public static final String TYPE_CIRCLE_WAS_DELETED = "circle_was_deleted";
	public static final String TYPE_CIRCLE_JOIN_REQUEST = "circle_join_request";
	public static final String TYPE_FULL_CIRCLE_REQUESTED = "full_circle_requested";
	public static final String TYPE_CIRCLE_INVITATION = "circle_invitation";
	public static final String TYPE_MEMBER_CIRCLE_INVITE = "member_circle_invite";
	public static final String TYPE_JOIN_REQUEST_ACCEPTED = "join_request_accepted";
	public static final String TYPE_ANNOUNCEMENT = "announcement";
	// Friends notifications
	public static final String TYPE_FRIENDSHIP_APPROVED = "friendship_approved";
	public static final String TYPE_FRIENDSHIP_REQUEST = "friendship_request";

	@JsonProperty(value = "like_available")
	protected boolean likeAvailable;

	protected String type;

	protected boolean reported;

	protected User user;

	protected Prayer prayer;

	@JsonProperty(value = "date_created")
	protected String dateCreated;

	@JsonProperty(value = "date_liked")
	protected String dateLiked;

	protected long id;

	protected PrayerComment comment;

	protected Circle circle;

	public boolean isLikeAvailable() {
		return likeAvailable;
	}

	public void setLikeAvailable(boolean likeAvailable) {
		this.likeAvailable = likeAvailable;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isReported() {
		return reported;
	}

	public void setReported(boolean reported) {
		this.reported = reported;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Prayer getPrayer() {
		return prayer;
	}

	public void setPrayer(Prayer prayer) {
		this.prayer = prayer;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDateLiked() {
		return dateLiked;
	}

	public void setDateLiked(String dateLiked) {
		this.dateLiked = dateLiked;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public PrayerComment getComment() {
		return comment;
	}

	public void setComment(PrayerComment comment) {
		this.comment = comment;
	}

	public Circle getCircle() {
		return circle;
	}

	public void setCircle(Circle circle) {
		this.circle = circle;
	}

	public String getNotificationImageUrl() {
		switch (getType()) {
		// Prayer notifications
		case TYPE_ANSWERED:
		case TYPE_COMMENT:
		case TYPE_LIKE:
			// Friends notifications
		case TYPE_FRIENDSHIP_APPROVED:
		case TYPE_FRIENDSHIP_REQUEST:
			return getUser().getProfilePicture();
			// Circle notifications
		case TYPE_USER_JOINED:
		case TYPE_CIRCLE_WAS_DELETED:
		case TYPE_CIRCLE_JOIN_REQUEST:
		case TYPE_FULL_CIRCLE_REQUESTED:
		case TYPE_CIRCLE_INVITATION:
		case TYPE_MEMBER_CIRCLE_INVITE:
		case TYPE_JOIN_REQUEST_ACCEPTED:
		case TYPE_ANNOUNCEMENT:
			return getCircle().getPicture();
		default:
			return null;
		}
	}
}
