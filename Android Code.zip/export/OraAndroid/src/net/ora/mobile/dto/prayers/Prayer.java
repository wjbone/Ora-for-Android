package net.ora.mobile.dto.prayers;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.dto.circles.Circle;
import android.os.Parcel;
import android.os.Parcelable;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class Prayer implements Parcelable {
	
	public static final String FOREIGN_FIELD_ID = "prayer_id";
	private static final int FAVORITE_VALUE = 1;
	
	@DatabaseField(id = true, index = true)
	protected int id;

	protected List<Circle> circles;

	@DatabaseField
	@JsonProperty(value = "like_available")
	protected boolean likeAvailable;

	@DatabaseField
	@JsonProperty(value = "date_added")
	protected String dateAdded;

	@DatabaseField
	protected String text;

	@DatabaseField
	@JsonProperty(value = "is_liked")
	protected boolean isLiked;

	@DatabaseField
	protected boolean answered;

	@DatabaseField
	@JsonProperty(value = "comments_count")
	protected int commentsCount;

	@DatabaseField
	@JsonProperty(value = "is_in_my_list")
	protected boolean isInMyList;

	@DatabaseField
	@JsonProperty(value = "date_created")
	protected String dateCreated;

	@DatabaseField
	@JsonProperty(value = "date_answered")
	protected String dateAnswered;

	@DatabaseField
	@JsonProperty(value = "date_liked")
	protected String dateLiked;

	@DatabaseField
	@JsonProperty(value = "likes_count")
	protected int likesCount;

	@DatabaseField
	@JsonProperty(value = "is_announcement")
	protected boolean isAnnouncement;

	@DatabaseField(foreign = true, foreignAutoRefresh = true, columnName = User.FOREIGN_FIELD_USER_ID)
	protected User user;


	@DatabaseField
	@JsonProperty(value = "answer_statement")
	protected String answerStatement;
	
	@DatabaseField
	protected int rating;

	/*
	 * 
	 */
	public List<Circle> getCircles() {
		return circles;
	}
	
	public void setCircles(List<Circle> circles) {
		this.circles = circles;
	}

	public boolean isLikeAvailable() {
		return likeAvailable;
	}

	public void setLikeAvailable(boolean likeAvailable) {
		this.likeAvailable = likeAvailable;
	}

	public String getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(String dateAdded) {
		this.dateAdded = dateAdded;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public boolean isLiked() {
		return isLiked;
	}

	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}

	public boolean isAnswered() {
		return answered;
	}

	public void setAnswered(boolean answered) {
		this.answered = answered;
	}

	public int getCommentsCount() {
		return commentsCount;
	}

	public void setCommentsCount(int commentsCount) {
		this.commentsCount = commentsCount;
	}

	public boolean isInMyList() {
		return isInMyList;
	}

	public void setInMyList(boolean isInMyList) {
		this.isInMyList = isInMyList;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDateAnswered() {
		return dateAnswered;
	}

	public void setDateAnswered(String dateAnswered) {
		this.dateAnswered = dateAnswered;
	}

	public String getDateLiked() {
		return dateLiked;
	}

	public void setDateLiked(String dateLiked) {
		this.dateLiked = dateLiked;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLikesCount() {
		return likesCount;
	}

	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}
	
	public boolean isAnnouncement() {
		return isAnnouncement;
	}
	
	public void setAnnouncement(boolean isAnnouncement) {
		this.isAnnouncement = isAnnouncement;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAnswerStatement() {
		return answerStatement;
	}

	public void setAnswerStatement(String answerStatement) {
		this.answerStatement = answerStatement;
	}
	
	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
	
	/*
	 * 
	 */
	public boolean isFavorite() {
		return getRating() == FAVORITE_VALUE;
	}
	
	public void setPrayer(Prayer other) {
		this.setLikeAvailable(other.isLikeAvailable());
		this.setDateAdded(other.getDateAdded());
		this.setText(other.getText());
		this.setAnswered(other.isAnswered());
		this.setCommentsCount(other.getCommentsCount());
		this.setInMyList(other.isInMyList());
		this.setDateCreated(other.getDateCreated());
		this.setDateAnswered(other.getDateAnswered());
		this.setDateLiked(other.getDateLiked());
		this.setId(other.getId());
		this.setLikesCount(other.getLikesCount());
		this.setAnnouncement(other.isAnnouncement());
		this.setAnswerStatement(other.getAnswerStatement());
		this.setRating(other.rating);
	}
	
	/**
	 * Should be called after retrieving a prayer from storage.
	 */
	public void setCircleList(List<PrayerAndCircle> prayerCircles) {
		List<Circle> circles = new ArrayList<Circle>();
		for(PrayerAndCircle prayerCircle : prayerCircles) {
			circles.add(prayerCircle.getCircle());
		}
		setCircles(circles);
	}

	/*
	 * 
	 */
	public Prayer() {
		super();
	}

	protected Prayer(Parcel in) {
		circles = new ArrayList<Circle>();
		in.readList(circles, null);
		likeAvailable = in.readByte() != 0x00;
		dateAdded = in.readString();
		text = in.readString();
		isLiked = in.readByte() != 0x00;
		answered = in.readByte() != 0x00;
		commentsCount = in.readInt();
		isInMyList = in.readByte() != 0x00;
		dateCreated = in.readString();
		dateAnswered = in.readString();
		dateLiked = in.readString();
		id = in.readInt();
		likesCount = in.readInt();
		isAnnouncement = in.readByte() != 0x00;
		user = in.readParcelable(User.class.getClassLoader());
		answerStatement = in.readString();
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeList(circles);
		dest.writeByte((byte) (likeAvailable ? 0x01 : 0x00));
		dest.writeString(dateAdded);
		dest.writeString(text);
		dest.writeByte((byte) (isLiked ? 0x01 : 0x00));
		dest.writeByte((byte) (answered ? 0x01 : 0x00));
		dest.writeInt(commentsCount);
		dest.writeByte((byte) (isInMyList ? 0x01 : 0x00));
		dest.writeString(dateCreated);
		dest.writeString(dateAnswered);
		dest.writeString(dateLiked);
		dest.writeInt(id);
		dest.writeInt(likesCount);
		dest.writeByte((byte) (isAnnouncement ? 0x01 : 0x00));
		dest.writeParcelable(user, 0);
		dest.writeString(answerStatement);
	}

	public static final Parcelable.Creator<Prayer> CREATOR = new Parcelable.Creator<Prayer>() {
		public Prayer createFromParcel(Parcel in) {
			return new Prayer(in);
		}

		public Prayer[] newArray(int size) {
			return new Prayer[size];
		}
	};
}
