package net.ora.mobile.dto.circles.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class InviteToCircleResponse extends ServiceResponse {
	
	@JsonProperty(value="is_member")
	public boolean isMember;
	
	@JsonProperty(value="is_requested")
	public boolean isRequested;
	
	@JsonProperty(value="is_invited")
	public boolean isInvited;

	public boolean isMember() {
		return isMember;
	}

	public void setMember(boolean isMember) {
		this.isMember = isMember;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}

	public boolean isInvited() {
		return isInvited;
	}

	public void setInvited(boolean isInvited) {
		this.isInvited = isInvited;
	}
	
}
