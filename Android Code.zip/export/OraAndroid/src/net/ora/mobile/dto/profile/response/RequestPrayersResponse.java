package net.ora.mobile.dto.profile.response;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class RequestPrayersResponse extends ServiceResponse {

	private Prayer[] prayers;
	
	private int next_page;

	public Prayer[] getPrayers() {
		return prayers;
	}

	public void setPrayers(Prayer[] prayers) {
		this.prayers = prayers;
	}

	public int getNext_page() {
		return next_page;
	}

	public void setNext_page(int next_page) {
		this.next_page = next_page;
	}
	
}
