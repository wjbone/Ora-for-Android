package net.ora.mobile.dto.prayers.response;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class AnswerPrayerResponse extends ServiceResponse {

	protected Prayer prayer;
	
	public Prayer getPrayer() {
		return prayer;
	}

	public void setPrayer(Prayer prayer) {
		this.prayer = prayer;
	}
}
