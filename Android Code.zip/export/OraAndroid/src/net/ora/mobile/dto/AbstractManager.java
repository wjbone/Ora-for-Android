package net.ora.mobile.dto;

import java.util.Date;

public class AbstractManager {
	
	public static final long RELOAD_TIME = 1 * 60 * 60 * 1000;

	protected Date lastReload;

	public boolean shouldReload() {
		if(lastReload == null)
			return true;
		
		long maxTime = lastReload.getTime() + RELOAD_TIME;
		long currentTime = new Date().getTime();
		
		return maxTime < currentTime;
	}
	
	public void afterReload() {
		lastReload = new Date();
	}
	
	public void markToReload() {
		lastReload = null;
	}
}
