package net.ora.mobile.dto.profile.response;

import java.util.List;

import com.digitalgeko.mobile.android.objects.RequestFriendUser;

import net.ora.mobile.dto.ServiceResponse;

public class SugResponse extends ServiceResponse {

	private List<RequestFriendUser> users;

	public List<RequestFriendUser> getUsers() {
		return users;
	}

	public void setUsers(List<RequestFriendUser> users) {
		this.users = users;
	}
	
}
