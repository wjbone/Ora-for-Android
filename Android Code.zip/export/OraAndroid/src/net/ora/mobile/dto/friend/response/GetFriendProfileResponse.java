package net.ora.mobile.dto.friend.response;

import net.ora.mobile.dto.ServiceResponse;

import com.digitalgeko.mobile.android.objects.friends.FriendProfileUser;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GetFriendProfileResponse extends ServiceResponse {

	@JsonProperty(value="user")
	protected FriendProfileUser profileUser;

	public FriendProfileUser getProfileUser() {
		return profileUser;
	}

	public void setProfileUser(FriendProfileUser profileUser) {
		this.profileUser = profileUser;
	}
	
}
