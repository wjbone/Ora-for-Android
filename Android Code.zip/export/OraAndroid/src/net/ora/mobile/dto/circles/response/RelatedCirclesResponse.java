package net.ora.mobile.dto.circles.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.circles.Circle;

public class RelatedCirclesResponse extends ServiceResponse {

	@JsonProperty(value="related_circles")
	protected List<Circle> relatedCircles;
	
	public List<Circle> getRelatedCircles() {
		return relatedCircles;
	}
	
	public void setRelatedCircles(List<Circle> relatedCircles) {
		this.relatedCircles = relatedCircles;
	}
	
}
