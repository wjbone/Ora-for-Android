package net.ora.mobile.dto.circles.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.circles.Circle;

public class CircleSearchResponse extends ServiceResponse {
	
	protected List<Circle> circles;
	
	@JsonProperty(value="next_page")
	protected int nextPage;

	public List<Circle> getCircles() {
		return circles;
	}

	public void setCircles(List<Circle> circles) {
		this.circles = circles;
	}

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
}
