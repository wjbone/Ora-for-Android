package net.ora.mobile.dto.circles.response;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.circles.Circle;

public class CreateCircleResponse extends ServiceResponse {

	protected Circle circle;

	public Circle getCircle() {
		return circle;
	}

	public void setCircle(Circle circle) {
		this.circle = circle;
	}
	
	
}
