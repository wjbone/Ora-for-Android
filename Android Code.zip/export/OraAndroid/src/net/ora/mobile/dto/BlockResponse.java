package net.ora.mobile.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"user"})
public class BlockResponse extends ServiceResponse {

}
