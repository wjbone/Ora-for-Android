package net.ora.mobile.dto.profile.response;

import com.digitalgeko.mobile.android.objects.RequestFriendUser;
import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;

public class SuggestedUsersV2Response extends ServiceResponse {

	@JsonProperty(value="access_token")
	private String accessToken;
	
	private RequestFriendUser[] users;

	public RequestFriendUser[] getUsers() {
		return users;
	}

	public void setUsers(RequestFriendUser[] users) {
		this.users = users;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
}
