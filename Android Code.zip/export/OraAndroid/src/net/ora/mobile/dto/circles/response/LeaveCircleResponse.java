package net.ora.mobile.dto.circles.response;


public class LeaveCircleResponse extends CircleResponse {
}
