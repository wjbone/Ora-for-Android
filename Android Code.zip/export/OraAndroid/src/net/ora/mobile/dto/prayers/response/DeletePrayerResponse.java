package net.ora.mobile.dto.prayers.response;

import net.ora.mobile.dto.ServiceResponse;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DeletePrayerResponse extends ServiceResponse {

	@JsonProperty(value="prayer_id")
	protected String prayerId;

	public String getPrayerId() {
		return prayerId;
	}

	public void setPrayerId(String prayerId) {
		this.prayerId = prayerId;
	}
}
