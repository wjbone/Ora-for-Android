package net.ora.mobile.dto.profile.request;

import java.util.ArrayList;
import java.util.List;

import com.digitalgeko.mobile.android.objects.profile.PhoneContact;

public class PhoneFacebookContacts {

	private List<PhoneContact> contacts;
	
	private String[] fb_ids;
	
	public PhoneFacebookContacts() {
		contacts = new ArrayList<PhoneContact>();
		fb_ids = new String[0];
	}

	public List<PhoneContact> getContacts() {
		return contacts;
	}

	public void setContacts(List<PhoneContact> contacts) {
		this.contacts = contacts;
	}

	public String[] getFb_ids() {
		return fb_ids;
	}

	public void setFb_ids(String[] fb_ids) {
		this.fb_ids = fb_ids;
	}
}
