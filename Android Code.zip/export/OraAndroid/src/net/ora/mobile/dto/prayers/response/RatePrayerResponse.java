package net.ora.mobile.dto.prayers.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class RatePrayerResponse extends ServiceResponse {

	protected String prayer_id;
	
	protected int rating;
	
	public String getPrayer_id() {
		return prayer_id;
	}

	public void setPrayer_id(String prayer_id) {
		this.prayer_id = prayer_id;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

}
