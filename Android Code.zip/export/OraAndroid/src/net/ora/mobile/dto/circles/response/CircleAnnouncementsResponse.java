package net.ora.mobile.dto.circles.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.Prayer;

public class CircleAnnouncementsResponse extends ServiceResponse {

	@JsonProperty(value="next_page")
	protected int nextPage;
	
	protected List<Prayer> prayers;

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}

	public List<Prayer> getPrayers() {
		return prayers;
	}

	public void setPrayers(List<Prayer> prayers) {
		this.prayers = prayers;
	}
}
