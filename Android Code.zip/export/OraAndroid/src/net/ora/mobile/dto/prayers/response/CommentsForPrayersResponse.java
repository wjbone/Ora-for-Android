package net.ora.mobile.dto.prayers.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.prayers.PrayerComment;

public class CommentsForPrayersResponse extends ServiceResponse {

	protected List<PrayerComment> comments;
	
	@JsonProperty(value="comments_count")
	protected int commentsCount;

	public List<PrayerComment> getComments() {
		return comments;
	}

	public void setComments(List<PrayerComment> comments) {
		this.comments = comments;
	}

	public int getCommentsCount() {
		return commentsCount;
	}

	public void setCommentsCount(int commentsCount) {
		this.commentsCount = commentsCount;
	}
}
