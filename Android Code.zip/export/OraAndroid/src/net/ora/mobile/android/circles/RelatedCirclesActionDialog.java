package net.ora.mobile.android.circles;

import java.sql.SQLException;
import java.util.List;

import net.ora.mobile.android.ui.OraDbActionDialog;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSRelatedCircles;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.circles.Circle;
import android.content.Context;
import android.widget.Toast;

import com.digitalgeko.mobile.android.objects.User;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.QueryBuilder;

/**
 * 
 * @author Byron
 * 
 */
public class RelatedCirclesActionDialog extends OraDbActionDialog<List<Circle>> {

	private User user;
	private boolean reload;
	private OnRelatedCirclesLoadedListener onRelatedCirclesLoadedListener;

	public RelatedCirclesActionDialog(Context context, User user, boolean reload,
			OnRelatedCirclesLoadedListener onRelatedCirclesLoadedListener) {
		super(context);
		this.user = user;
		this.reload = reload;
		this.onRelatedCirclesLoadedListener = onRelatedCirclesLoadedListener;
	}

	@Override
	public List<Circle> preAction() {
		List<Circle> circles = null;
		OraConfiguration configuration = new OraConfiguration(getContext());

		if (!(reload || configuration.isFirstTimeLoadingCircles())) {
			try {
				Dao<User, Integer> userDao = getHelper().getUserDao();
				QueryBuilder<User, Integer> userQueryBuilder = userDao.queryBuilder();
				userQueryBuilder.where().idEq(user.getId());

				Dao<Circle, Integer> circleDao = getHelper().getCircleDao();
				QueryBuilder<Circle, Integer> circleQueryBuilder = circleDao.queryBuilder();

				QueryBuilder<Circle, Integer> builder = circleQueryBuilder.join(userQueryBuilder);
				builder.orderBy(Circle.FIELD_NAME, true);

				circles = builder.query();
			} catch (SQLException e) {
			}
		}

		configuration.close();
		return circles;
	}

	@Override
	public List<Circle> performAction() {
		return WSRelatedCircles.getRelatedCirclesFromServer(context, user);
	}

	@Override
	public void afterAction(List<Circle> circles) {
		if (MasterService.isFailedConnection()) {
			Toast.makeText(getContext(), MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
		} else {
			// Persist info
			try {
				Dao<User, ?> userDao = getHelper().getUserDao();
				Dao<Circle, ?> circleDao = getHelper().getCircleDao();

				// Erase old circles
				List<Circle> oldCircles = circleDao.queryForAll();
				for (Circle oldCircle : oldCircles) {
					if (!circles.contains(oldCircle)) {
						circleDao.delete(oldCircle);
					}
				}

				// Save circles
				for (Circle circle : circles) {
					userDao.createOrUpdate(circle.getUser());
					circleDao.createOrUpdate(circle);
				}

				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(false);
				configuration.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			// Deliver them
			if (onRelatedCirclesLoadedListener != null) {
				onRelatedCirclesLoadedListener.onLoaded(circles);
			}
		}
	}

	public static interface OnRelatedCirclesLoadedListener {
		public void onLoaded(List<Circle> circles);
	}
}