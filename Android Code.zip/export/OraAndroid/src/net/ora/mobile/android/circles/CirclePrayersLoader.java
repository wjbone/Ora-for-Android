package net.ora.mobile.android.circles;

import net.ora.mobile.android.ui.OraAsyncTaskLoader;
import net.ora.mobile.android.ui.OraLoaderCallbacks;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCirclePrayers;
import net.ora.mobile.dto.circles.response.CirclePrayersResponse;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;

/**
 * 
 * @author byron
 * 
 */
public class CirclePrayersLoader extends OraAsyncTaskLoader<CirclePrayersResponse> {

	private int page = 1;
	private int circleId = -1;

	public CirclePrayersLoader(Activity activity, OraLoaderCallbacks<CirclePrayersResponse> callbacks) {
		super(activity, callbacks);
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getCircleId() {
		return circleId;
	}

	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}

	@Override
	public CirclePrayersResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			abandon();
			Log.i("Loader", "abandon");
			return null;
		}

		Context context = getContext();
		int circleId = this.circleId;
		int prayerId = WSCirclePrayers.PRAYER_ID_ALL_PRAYERS;
		int page = this.page;
		CirclePrayersResponse response = WSCirclePrayers.getCirclePrayers(context, circleId, prayerId, page);

		if (MasterService.isFailedConnection()) {
			showErrorMessage(MasterService.getErrorMessage());
			abandon();
			return null;
		}
		this.page = response.getNextPage();

		Log.i("Loader", "finish");

		return response;
	}
}
