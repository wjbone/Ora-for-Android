package net.ora.mobile.android.friends;

import net.ora.mobile.android.MainActivity;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.fragment.FriendsPrayersFragment;
import net.ora.mobile.android.profile.ProfileManager;
import net.ora.mobile.android.ui.activities.OraSherlockFragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.objects.User;

public class PrayersListFriendActivity extends OraSherlockFragmentActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		ActionBar _actionBar = getSupportActionBar();

		_actionBar.setDisplayHomeAsUpEnabled(true);
		_actionBar.setDisplayShowTitleEnabled(false);
		_actionBar.setDisplayShowCustomEnabled(true);

		// Save action bar title view
		_actionBar.setCustomView(R.layout.custom_action_layout);
		View customView = _actionBar.getCustomView();
		((TextView) customView.findViewById(R.id.action_custom_title)).setText("Prayers");

		String name = getIntent().getExtras().getString("friend_name");
		((OraApplication) getApplication()).addParam("friend_id_PLFA", getIntent().getExtras().getInt("friend_id"));
		((OraApplication) getApplication()).addParam("name_PLFA", name);
		((OraApplication) getApplication()).addParam("picture_PLFA", getIntent().getExtras().getString("friend_picture"));

		// Get friend
		User friend = getIntent().getParcelableExtra(FriendsPrayersFragment.TAG_FRIEND);

		setContentView(R.layout.view_prayers_friend);
		
		// Set friend
		FriendsPrayersFragment fragment = (FriendsPrayersFragment) getSupportFragmentManager().findFragmentById(
				R.id.friend_fragment);
		fragment.setFriend(friend);
	}

	@Override
	protected void onStart() {
		super.onStart();

		ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
		if (manager.isGoToProfileSettings()) {
			finish();
		} else if (manager.isLogout()) {
			finish();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		if (MainActivity.shouldShowOldMenu()) {
			MenuInflater inflater = getSupportMenuInflater();
			inflater.inflate(R.menu.base_menu, menu);
			return true;
		} else {
			return super.onCreateOptionsMenu(menu);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			finish();
			break;
		}
		case R.id.menu__base_setting: {
			ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
			manager.setGoToProfileSettings(true);
			finish();
			return true;
		}
		case R.id.menu__base_logout: {
			ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
			manager.setLogout(true);
			finish();
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}

}
