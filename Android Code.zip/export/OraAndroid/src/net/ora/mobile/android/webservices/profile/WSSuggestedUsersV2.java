package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.profile.request.PhoneFacebookContacts;
import net.ora.mobile.dto.profile.request.SuggestedUsersV2Request;
import net.ora.mobile.dto.profile.response.SugResponse;
import net.ora.mobile.dto.profile.response.SuggestedFriendsResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;
import android.util.Log;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.objects.profile.PhoneContact;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class WSSuggestedUsersV2 extends MasterService {

	private final static String TAG_LOG = "WSSuggestedUsersV2";

	private static final String URL = "suggested_users_v2/";
	
	public static SugResponse getSuggestedFriends(Context context, String accessToken, List<PhoneContact> contacts){
		try{
			// Build request
			SuggestedUsersV2Request request = new SuggestedUsersV2Request();
			request.setAccessToken(accessToken);
			request.setContacts(contacts);
			
			// Map request to string
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			Log.i(TAG_LOG, "Begin to Json");
			String jsonRepresentation = mapper.writeValueAsString(request);
			Log.i(TAG_LOG, "End to Json");
			
			Vector<NameValuePair> requestParams = new Vector<NameValuePair>();
			requestParams.add(new BasicNameValuePair("data", jsonRepresentation));
			
			Log.i(TAG_LOG, "Begin request");
			SugResponse response = makeRequest(context, CONNECTION_TYPE.POST, 
					URL , requestParams, new TypeReference< SugResponse >() {});
			Log.i(TAG_LOG, "End request");
			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsBase_error);
		}
		
		return null;
	}

	
}
