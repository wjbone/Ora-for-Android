package net.ora.mobile.android.profile;

import net.ora.mobile.android.R;
import net.ora.mobile.android.util.ImageDownloader;
import net.ora.mobile.android.webservices.profile.WSSearchUser;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageSearchFriends;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.RequestFriendshipDialog;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class AddOraFriendsListAdapter extends BaseAdapter {

	private Activity context;
	private FriendUser[] users;
	public int width;
	private ImageDownloader imageDownloader;
	
	public AddOraFriendsListAdapter(Activity context, FriendUser[] users, Bitmap defaultBitmap) {
		this.context = context;
		this.users = users;
		
		// Set up instance data
		width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(context);
		imageDownloader = new ImageDownloader(context, context.getResources(), defaultBitmap);
	}
	
	@Override
	public int getCount() {
		int count = 0;
		if(users != null) {
			count = users.length;
		}
		return count;
	}

	@Override
	public Object getItem(int position) {
		return users[position];
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		FriendUserViewHolder holder;
		
		if(view == null) {
			LayoutInflater inflater = LayoutInflater.from(parent.getContext());
		
			view = inflater.inflate(R.layout.item_friend_list, null);
			
			holder = new FriendUserViewHolder();
			holder.friendPicture = ((ImageView) view.findViewById(R.id.iv_item_friend_image));
			holder.circlePicture = (ImageView) view.findViewById(R.id.iv_friends_Cirle);
			holder.tvName = ((TextView) view.findViewById(R.id.tv_item_friend_name));
			
			// Configure image views
			holder.friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.button = ((ImageButton) view.findViewById(R.id.b_item_friend_button));
			
			// Save holder for later
			view.setTag(holder);
			
		} else {
			holder = (FriendUserViewHolder) view.getTag();
			
			if(holder.position == position) {
				return view;
			}
		}
		
		// Set data
		FriendUser user = users[position];
		holder.tvName.setText(user.getName());
		if(user.isFriend()){
			holder.button.setImageResource(R.drawable.ic_check_green);
		}else if(user.isRequested()){
			holder.button.setImageResource(R.drawable.ic_check_gray_pending);
		}else{
			holder.button.setImageResource(R.drawable.ic_add_request);
		}
		holder.button.setOnClickListener(new AddFriendViewManager(user, holder.button));
		// Profile picture
		if(user.getPicture() != null) {
			Log.i("InviteMembersFragment", user.getPicture());
			imageDownloader.download(user.getPicture(), holder.friendPicture);
		}
		
		// Return
		return view;
	}
	
	
	
	/*
	 * 
	 */
	public static class  FriendUserViewHolder {
		public int position;
		public ImageView friendPicture;
		public ImageView circlePicture;
		public TextView tvName;
		public ImageButton button;
		
	}
	
	/*
	 * 
	 */
	public class AddFriendViewManager implements OnClickListener {
		
		private FriendUser user;
		private ImageButton button;
		
		public AddFriendViewManager(FriendUser user, ImageButton button) {
			this.user = user;
			this.button = button;
		}
		
		@Override
		public void onClick(View v) {
			if((!user.isFriend()) && (!user.isRequested())) {
				new RequestFriendshipDialog(context, button, user, null).init();
			}
		}
	}
		
}
