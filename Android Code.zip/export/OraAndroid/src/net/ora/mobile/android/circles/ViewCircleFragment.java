package net.ora.mobile.android.circles;

import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.prayers.PrayedUsersForPrayerFragment;
import net.ora.mobile.android.prayers.PrayerCirclesFragment;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.ui.OraLoaderCallbacks;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSDeleteCircle;
import net.ora.mobile.android.webservices.circles.WSGetCircleProfile;
import net.ora.mobile.android.webservices.circles.WSJoinCircle;
import net.ora.mobile.android.webservices.circles.WSLeaveCircle;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.ServiceResponse;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CirclePrayersResponse;
import net.ora.mobile.dto.circles.response.JoinCircleResponse;
import net.ora.mobile.dto.circles.response.LeaveCircleResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.Loader;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class ViewCircleFragment extends CachedImageDataFragment implements OraLoaderCallbacks<CirclePrayersResponse> {

	public static final String TAG_CIRCLE = "circle";

	private static final int ITEM_DELETE_CIRCLE = 3;
	private static final int ITEM_LEAVE_CIRCLE = 4;
	private static final int ITEM_INVITE_MEMBERS = 5;

	private Circle circle;

	private View view;
	private ViewGroup viewCirclePrayers;
	private ImageView imageBackgroundPicture;
	private ImageView userPicture;
	private LinearLayout pictureMargin;

	public static ViewCircleFragment getInstance(Circle circle) {
		ViewCircleFragment fragment = new ViewCircleFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments().getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}

		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Save
		if (circle == null) {
			return null;
		}

		// Inflate view
		view = inflater.inflate(R.layout.fragment_circles_view_circle, container, false);

		// Announcements tab
		if (circle.isCommunity()) {
			View viewTabAnnouncements = view.findViewById(R.id.layoutAnnouncements);
			viewTabAnnouncements.setVisibility(View.VISIBLE);
			viewTabAnnouncements.setOnClickListener(onAnnouncementsTabClick);
			view.findViewById(R.id.separatorAnnouncements).setVisibility(View.VISIBLE);
		}

		// Join button configuration
		if (!circle.isMember() && !circle.isOwner()) {
			View temp = view.findViewById(R.id.viewCircle_btnJoin);
			temp.setVisibility(View.VISIBLE);
		}

		// Prayers list view group
		viewCirclePrayers = (ViewGroup) view.findViewById(R.id.viewCircle_lstPrayers);

		// Set up title
		getActivity().setTitle(circle.getName());

		/* ***********************************
		 * obtaining the profile picture view
		 * 
		 * ***********************************
		 */
		int background_heigth = GeneralMethods.getProfileBackgroundWidth(getActivity());
		int picture_width = (int) (background_heigth * 0.75);

		imageBackgroundPicture = (ImageView) view.findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		userPicture = (ImageView) view.findViewById(R.id.iv_Profile_Picture);
		userPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		pictureMargin = (LinearLayout) view.findViewById(R.id.ly_Profile_Margin_Picture);
		pictureMargin.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		// Load circle info
		new LoadCircleProfileActionDialog(getActivity(), circle).init();
		// Load circle prayers
		getActivity().getSupportLoaderManager().initLoader(CirclePrayersFragment.LOADER_ID_CIRCLE_PRAYERS, null, this);
		// Load circle's picture
		if (circle.getPicture().trim().length() > 0) {
			List<ImageView> pictures = Arrays.asList(userPicture);
			List<ImageView> picturesFaded = Arrays.asList(imageBackgroundPicture);

			DownloadProfilePicture asyncJob = new DownloadProfilePicture(getActivity(), ViewCircleFragment.this, pictures,
					picturesFaded, "ViewCircleProfileFragment");
			asyncTaskList.add(asyncJob);
			asyncJob.execute(circle.getPicture());

			userPicture.setVisibility(View.VISIBLE);
			pictureMargin.setBackgroundResource(R.drawable.profile_image_margin);
			pictureMargin.invalidate();
		}

		// Return
		return view;
	}

	@Override
	public void onStop() {
		super.onStop();
		getActivity().getSupportLoaderManager().destroyLoader(CirclePrayersFragment.LOADER_ID_CIRCLE_PRAYERS);
	}

	public void onLoadComplete(List<Prayer> data) {
		if (data != null && getActivity() != null) {
			// Clear list
			viewCirclePrayers.removeAllViews();

			// Inflate views
			LayoutInflater inflater = LayoutInflater.from(getActivity());
			// Set vars
			int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
			Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[data.size()];
			int i = 0;

			for (final Prayer prayer : data) {

				ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);

				// Set listeners
				TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
				descriptionView.setOnClickListener(new GoPrayerDetailManager(prayer, false));
				if (prayer.isLikeAvailable()) {
					View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
					ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
					btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer, containerView));
				} else {
					View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
					btnPray.setVisibility(View.GONE);
				}
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments).setOnClickListener(
						new GoPrayerDetailManager(prayer, true));
				if (prayer.getUser().equals(((OraApplication) getActivity().getApplication()).getUser())) {
					// Can see prays list only in is the owner of the pray
					viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(new GoPrayerPraysManager(prayer));
				}
				OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);

				// Set info
				((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
				// Prayer User View
				TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
				prayerUserTextView.setText(prayer.getUser().getName());
				prayerUserTextView.setOnClickListener(goToProfileListener);

				// Go to user profile
				ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
				friendPicture.setOnClickListener(goToProfileListener);

				// Set circle
				ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

				friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
				circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

				pictureImageViewList.add(friendPicture);
				circleImageViewList.add(circlePicture);

				// Save user/image view info
				usersImagesViewsPairs[i++] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);

				// Circles
				int circlesCount = prayer.getCircles().size();
				String strCircles = "";
				if (circlesCount == 0) {
					viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
				} else {
					// Set listener
					viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(new GoPrayerCirclesManager(prayer));

					for (Circle circle : prayer.getCircles())
						strCircles += circle.getName() + ", ";
					strCircles = strCircles.substring(0, strCircles.length() - 2);
					// Set circles string
					((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);
				}

				// Set prayer likes count
				TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
				likesCount.setText(Integer.toString(prayer.getLikesCount()));

				// Set prayer comments count
				TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
				commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
				// Set prayer time
				TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
				timeCount.setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));

				// Add view
				viewCirclePrayers.addView(viewPrayer);
				viewCirclePrayers.invalidate();
			}

			// Start loading pictures
			AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayersFeedFragmets", getActivity(), this);
			asyncTaskList.add(async);
			async.execute(usersImagesViewsPairs);
		}
	}

	public void onCirclesViewPrayersClick(View view) {
		pushFragment(CirclePrayersFragment.getInstance(circle));
	}

	public void onCirclesViewMembersClick(View view) {
		pushFragment(CircleMembersFragment.getInstance(circle));
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// super.onCreateOptionsMenu(menu, inflater);

		SubMenu subMenu = menu.addSubMenu(0, 0, 0, getString(R.string.viewCircle_btnMenu));
		subMenu.setIcon(R.drawable.ic_bar_menu);
		subMenu.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

		// Invite friends button
		if (circle.isOwner() || (!circle.isPrivate() && circle.isMember())) {
			subMenu.add(MyCirclesFragment.GROUP_CIRCLES, ITEM_INVITE_MEMBERS, Menu.NONE,
					getString(R.string.viewCircle_btnInviteMembers));
		}

		// delete circle button
		if (circle.isOwner()) {
			subMenu.add(MyCirclesFragment.GROUP_CIRCLES, ITEM_DELETE_CIRCLE, Menu.NONE,
					getString(R.string.viewCircle_btnDeleteCircle));
		} else {
			// Leave circle button
			if (circle.isMember()) {
				subMenu.add(MyCirclesFragment.GROUP_CIRCLES, ITEM_LEAVE_CIRCLE, Menu.NONE,
						getString(R.string.viewCircle_btnLeaveCircle));
			}
		}

		// Check sub menus
		if (subMenu.size() == 0) {
			menu.removeItem(0);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case ITEM_INVITE_MEMBERS:
			onCirclesInviteMemberClick(item.getActionView());
			return true;
		case ITEM_DELETE_CIRCLE:
			onCirclesDeleteCircleClick(item.getActionView());
			return true;
		case ITEM_LEAVE_CIRCLE:
			onCirclesLeaveCircleClick(item.getActionView());
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public void onCirclesInviteMemberClick(View view) {
		pushFragment(InviteFriendsFragment.getInstance(circle));
	}

	public void onCirclesDeleteCircleClick(View view) {
		GeneralMethods.showDialogYesNo(getString(R.string.viewCircle_askDeleteCircle, circle.getName()), getActivity(),
				getActivity(), new Runnable() {
					@Override
					public void run() {
						new DeleteCircleActionDialog(getActivity()).init();
					}
				});
	}

	public void onCirclesLeaveCircleClick(View view) {
		GeneralMethods.showDialogYesNo(getString(R.string.viewCircle_askLeaveCircle, circle.getName()), getActivity(),
				getActivity(), new Runnable() {
					@Override
					public void run() {
						new LeaveCircleActionDialog(getActivity()).init();
					}
				});
	}

	public void onCirclesJoinCircleClick(View view) {
		new JoinCircleActionDialog(getActivity()).init();
	}

	@Override
	public Loader<CirclePrayersResponse> onCreateLoader(int id, Bundle args) {
		showProgressBar();

		CirclePrayersLoader loader = new CirclePrayersLoader(getActivity(), this);
		loader.setCircleId(circle.getId());
		loader.setPage(1);
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<CirclePrayersResponse> loader, CirclePrayersResponse data) {
		hideProgressBar();
		onLoadComplete(data.getPrayers());
	}

	@Override
	public void onAbandon(Loader<CirclePrayersResponse> loader) {
		hideProgressBar();
	}

	@Override
	public void onLoaderReset(Loader<CirclePrayersResponse> loader) {
	}

	private void showProgressBar() {
		if (view != null) {
			view.findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
		}
	}

	private void hideProgressBar() {
		if (view != null) {
			view.findViewById(R.id.pbLoading).setVisibility(View.GONE);
		}
	}

	private OnClickListener onAnnouncementsTabClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			pushFragment(CirclesAnnouncementsFragment.getInstance(circle));
		}
	};

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class LoadCircleProfileActionDialog extends ActionDialog<Circle> {

		private Circle circle;

		public LoadCircleProfileActionDialog(Activity context, Circle circle) {
			super(context);
			this.circle = circle;
		}

		@Override
		public Circle performAction() {
			int circleId = circle.getId();
			return WSGetCircleProfile.getCircleProfile(context, circleId);
		}

		@Override
		public void afterAction(Circle circle) {
			// Validate result
			if (MasterService.isFailedConnection() || circle == null) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				popFragment();
				return;
			}

			TextView temp;

			// Set Prayers Count
			temp = (TextView) view.findViewById(R.id.viewCircle_lblPrayersQuantity);
			temp.setText(Integer.toString(circle.getPrayersCount()));

			// Set Announcements Count
			if (circle.isCommunity()) {
				temp = (TextView) view.findViewById(R.id.viewCircle_lblAnnouncementsQuantity);
				temp.setText(Integer.toString(circle.getAnnouncementsCount()));
			}

			// Set Members Count
			temp = (TextView) view.findViewById(R.id.viewCircle_lblCirclesQuantity);
			temp.setText(Integer.toString(circle.getMembersCount()));

			// Scope
			temp = (TextView) view.findViewById(R.id.circleProfile_tv_scope);
			temp.setText(circle.getSecurityLevelId());
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class DeleteCircleActionDialog extends ActionDialog<ServiceResponse> {

		public DeleteCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public ServiceResponse performAction() {
			int circleId = circle.getId();
			return WSDeleteCircle.deleteCircle(context, circleId);
		}

		@Override
		public void afterAction(ServiceResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
				popFragment();

				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();
			}
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class LeaveCircleActionDialog extends ActionDialog<LeaveCircleResponse> {

		public LeaveCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public LeaveCircleResponse performAction() {
			int circleId = circle.getId();
			return WSLeaveCircle.leaveCircle(context, circleId);
		}

		@Override
		public void afterAction(LeaveCircleResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();

				popFragment();
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
			}
		}

	}

	public class JoinCircleActionDialog extends ActionDialog<JoinCircleResponse> {

		public JoinCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public JoinCircleResponse performAction() {
			int circleId = circle.getId();
			return WSJoinCircle.joinCircle(context, circleId);
		}

		@Override
		public void afterAction(JoinCircleResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			if (response.isMember() || response.isOwner()) {
				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();
			}
			Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
			View temp = view.findViewById(R.id.viewCircle_btnJoin);
			temp.setVisibility(View.GONE);
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, boolean showOnlyComments) {
			this.prayer = prayer;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			pushFragment(PrayerDetailFragment.getInstance(prayer, showOnlyComments));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			getActivity().startActivity(
					new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerPraysManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerCirclesManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
				pushFragment(ViewCircleFragment.getInstance(circle));
			} else {
				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}
}
