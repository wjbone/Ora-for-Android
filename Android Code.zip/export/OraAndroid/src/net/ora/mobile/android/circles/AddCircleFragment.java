package net.ora.mobile.android.circles;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.SQLException;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.city_state.SearchCountryActivity;
import net.ora.mobile.android.profile.SettingsFragment;
import net.ora.mobile.android.ui.OraDbActionDialog;
import net.ora.mobile.android.util.Blur;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCreateCircle;
import net.ora.mobile.dto.circles.Circle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.ui.DGFragment;
import com.digitalgeko.mobile.android.ui.SegmentedRadioGroup;
import com.digitalgeko.mobile.android.utilities.ContentUtilities;
import com.j256.ormlite.dao.Dao;

public class AddCircleFragment extends DGFragment implements OnCheckedChangeListener {

	private String picturePath;

	private View view;
	private TextView txtScopeDescription;
	private Button btnCircleCity;

	private LinearLayout marginImage;
	private ImageView backgroundImage;
	private ImageView pictureImage;
	private ImageView cameraImage;

	@Override
	protected int getActionBarString() {
		return R.string.addCircle_title;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
	}

	@Override
	protected boolean isShowKeyboard() {
		return false;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_circles_create_circle, container, false);

		SegmentedRadioGroup rGroup = (SegmentedRadioGroup) view.findViewById(R.id.createCricle_srgScopes);
		rGroup.setOnCheckedChangeListener(this);

		txtScopeDescription = (TextView) view.findViewById(R.id.addCircle_msgScope);

		//
		btnCircleCity = (Button) view.findViewById(R.id.addCircle_txtCity);
		btnCircleCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(getActivity(), SearchCountryActivity.class), SettingsFragment.SELECT_PLACE);
			}
		});

		/* Load images */
		int background_heigth = GeneralMethods.getProfileBackgroundWidth(getActivity());
		int picture_width = (int) (background_heigth * 0.75);

		backgroundImage = (ImageView) view.findViewById(R.id.iv_setting_background);
		backgroundImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		pictureImage = (ImageView) view.findViewById(R.id.iv_setting_picture);
		pictureImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		cameraImage = (ImageView) view.findViewById(R.id.iv_setting_camera);
		cameraImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

				builder.setItems(new String[] { "Camera", "Gallery" }, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
						Intent intent = null;
						switch (which) {
						case 0:
							intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
							startActivityForResult(intent, SettingsFragment.TAKE_PICTURE);
							break;
						case 1:
							intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
							intent.setType("image/*");
							startActivityForResult(intent, SettingsFragment.SELECT_PICTURE);
							break;
						}
					}
				});

				builder.create().show();
			}
		});

		marginImage = (LinearLayout) view.findViewById(R.id.ly_setting_margin);
		marginImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		return view;
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.create_circle_menu, menu);

		final MenuItem item = menu.findItem(R.id.createCircle_miCreate);
		item.getActionView().findViewById(R.id.menu__create_circle__btn_create).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onOptionsItemSelected(item);
			}
		});

		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.createCircle_miCreate:
			onCreateCircleClick(view);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SettingsFragment.TAKE_PICTURE) {
			if (data != null) {
				if (data.hasExtra("data")) {
					Bitmap bitmap = data.getParcelableExtra("data");
					Uri selectedImage = Uri.parse(MediaStore.Images.Media.insertImage(getActivity().getContentResolver(), bitmap,
							"", ""));
					picturePath = ContentUtilities.getRealPathFromURI(getActivity(), selectedImage);
					setImagesViews(bitmap);
				}
			}
		} else if (requestCode == SettingsFragment.SELECT_PICTURE) {
			if (data != null) {
				Uri selectedImage = data.getData();
				picturePath = ContentUtilities.getRealPathFromURI(getActivity(), selectedImage);
				setImage(selectedImage);
			}
		} else if ((requestCode == SettingsFragment.SELECT_PLACE) && (resultCode == android.app.Activity.RESULT_OK)) {
			String response = data.getStringExtra("city_state");
			btnCircleCity.setText(response);
		}
	}

	private void setImage(Uri selectedImage) {
		if (selectedImage != null) {
			try {
				InputStream is = getActivity().getContentResolver().openInputStream(selectedImage);
				BufferedInputStream bis = new BufferedInputStream(is);
				Bitmap bitmap = BitmapFactory.decodeStream(bis);
				setImagesViews(bitmap);
			} catch (FileNotFoundException e) {
			}
		}
	}

	private void setImagesViews(Bitmap bitmap) {
		Bitmap bmpFaded = Blur.fastblur(getActivity(), bitmap, DownloadProfilePicture.BLUR_RATIO);

		backgroundImage.setImageBitmap(bmpFaded);
		pictureImage.setImageBitmap(bitmap);

		pictureImage.setVisibility(View.VISIBLE);
		marginImage.setBackgroundResource(R.drawable.profile_image_margin);
	}

	public void onCreateCircleClick(View view) {
		new CreateCircleActionDialog(getActivity()).init();
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.createCircle_rbtnScopeSecret:
			txtScopeDescription.setText(getString(R.string.addCircle_msgScopeSecret));
			break;
		case R.id.createCircle_rbtnScopeClose:
			txtScopeDescription.setText(getString(R.string.addCircle_msgScopeClosed));
			break;
		case R.id.createCircle_rbtnScopePublic:
			txtScopeDescription.setText(getString(R.string.addCircle_msgScopePublic));
			break;
		}
	}

	public class CreateCircleActionDialog extends OraDbActionDialog<Circle> {

		public CreateCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Circle performAction() {

			String name = ((TextView) view.findViewById(R.id.addCircle_txtName)).getText().toString();
			boolean isLite = !(((OraApplication) getActivity().getApplication()).getUser().isPremium());
			String about = ((TextView) view.findViewById(R.id.addCircle_txtAbout)).getText().toString();
			String city = ((TextView) view.findViewById(R.id.addCircle_txtCity)).getText().toString();

			boolean isPrivate;
			boolean approvesMembers;

			int idSelected = ((RadioGroup) view.findViewById(R.id.createCricle_srgScopes)).getCheckedRadioButtonId();
			switch (idSelected) {
			case R.id.createCircle_rbtnScopePublic:
				// Public
				isPrivate = false;
				approvesMembers = false;
				break;
			case R.id.createCircle_rbtnScopeClose:
				// Close
				isPrivate = false;
				approvesMembers = true;
				break;
			default:
				// Secret
				// case R.id.createCircle_rbtnScopeSecret:
				isPrivate = true;
				approvesMembers = true;
				break;
			}

			return WSCreateCircle.createCircle(context, name, isLite, about, city, isPrivate, approvesMembers, picturePath);
		}

		@Override
		public void afterAction(Circle circle) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				// Persist info
				try {
					Dao<Circle, ?> circleDao = getHelper().getCircleDao();
					circleDao.create(circle);
				} catch (SQLException e) {
				}

				popFragment();
				pushFragment(ViewCircleFragment.getInstance(circle));
			}
		}
	}
}
