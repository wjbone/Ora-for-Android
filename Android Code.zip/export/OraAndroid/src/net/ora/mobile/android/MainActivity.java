package net.ora.mobile.android;

import net.ora.mobile.android.activity.ActivityFragment;
import net.ora.mobile.android.circles.AddCircleFragment;
import net.ora.mobile.android.circles.MyCirclesFragment;
import net.ora.mobile.android.circles.ViewCircleFragment;
import net.ora.mobile.android.feed.PrayersFeedFragment;
import net.ora.mobile.android.prayers.NewPrayerFragment;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.profile.ProfileManager;
import net.ora.mobile.android.profile.SettingsFragment;
import net.ora.mobile.android.profile.UserFragment;
import net.ora.mobile.android.ui.OraStackTabManager;
import net.ora.mobile.android.ui.OraTextView;
import net.ora.mobile.android.ui.OraTextViewForOraName;
import net.ora.mobile.android.ui.activities.OraBaseFragmentActivity;
import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.ActionBar.Tab;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.ui.DGFragment;
import com.digitalgeko.mobile.android.ui.StackTabManager;
import com.facebook.Session;

@SuppressWarnings("static-access")
public class MainActivity extends OraBaseFragmentActivity<OraStackTabManager> {

	public static final int INDEX_TAB_FEED = 0;
	public static final int INDEX_TAB_MY_CIRCLES = 1;
	public static final int INDEX_TAB_NEW_PRAYER = 2;
	public static final int INDEX_TAB_ACTIVITY = 3;
	public static final int INDEX_TAB_PROFILE = 4;

	private TextView titleView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// ActionBar gets initiated
		ActionBar actionbar = getSupportActionBar();
		// Tell the ActionBar we want to use Tabs.
		actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Set info
		actionbar.setCustomView(R.layout.custom_action_layout);
		View customView = actionbar.getCustomView();
		titleView = (TextView) customView.findViewById(R.id.action_custom_title);
		if (titleView.getText().toString().compareToIgnoreCase("ORA") == 0) {
			titleView.setTypeface(Typeface.createFromAsset(getAssets(), OraTextViewForOraName.FONT_NAME));
		} else {
			titleView.setTypeface(Typeface.createFromAsset(getAssets(), OraTextView.FONT_NAME));
		}

		// set tabs style
		actionbar.setStackedBackgroundDrawable(getResources().getDrawable(R.drawable.bg_action_bar_tab_normal));

		// Create tabs to show in the action bar
		addActionBarTab(R.drawable.ic_tab_home, new PrayersFeedFragment());
		addActionBarTab(R.drawable.ic_tab_circles, new MyCirclesFragment());
		addActionBarTab(R.drawable.ic_tab_add, new NewPrayerFragment());
		addActionBarTab(R.drawable.ic_tab_activity, new ActivityFragment());
		addActionBarTab(R.drawable.ic_tab_user, new UserFragment());

		// Configure new prayer tab
		// temp.setCustomView(R.layout.action_bar_tab_new_prayer);

		if (((OraApplication) getApplication()).isTimeToPray()) {
			DGFragment fragment = PrayersFeedFragment.getInstance(PrayersFeedFragment.TYPE_MY_LIST);
			popAllFragments(fragment);
		}
	}

	@Override
	protected void onStart() {
		super.onStart();

		ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
		if (manager.isGoToProfileSettings()) {
			manager.setGoToProfileSettings(false);
			onGoToProfileSettingClick(null);
		} else if (manager.isLogout()) {
			manager.setLogout(false);
			onLogoutClick(null);
		}
	}

	protected Tab addActionBarTab(int tabDrawableResource, DGFragment fragment) {
		// Create listener
		OraStackTabManager listener = new OraStackTabManager(this, fragment, R.id.fragment_container);
		Tab tab = super.addActionBarTabWithDrawable(tabDrawableResource, fragment, listener);

		/*
		 * if(fragment instanceof UserFragment && getIntent().getBooleanExtra("is_fist_time", false)) listener.pushFragment(new
		 * AddFriendsListFragment());
		 */

		// Return
		return tab;
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		System.out.println(requestCode + " - " + resultCode);
		if ((requestCode == 64206) && (resultCode == -1)) {
			Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		if (shouldShowOldMenu()) {
			MenuInflater inflater = getSupportMenuInflater();
			inflater.inflate(R.menu.base_menu, menu);
			return true;
		} else {
			return super.onCreateOptionsMenu(menu);
		}
	}

	@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
	protected boolean hasPermanentMenuKey(Context context) {
		return ViewConfiguration.get(context).hasPermanentMenuKey();
	}

	/**
	 * 
	 * @return true if the activity should add items to the old style, otherwise false.
	 */
	public static boolean shouldShowOldMenu() {
		// return Build.VERSION.SDK_INT <= Build.VERSION_CODES.GINGERBREAD_MR1 ||
		// (Build.VERSION.SDK_INT <= Build.VERSION_CODES.ICE_CREAM_SANDWICH &&
		// hasPermanentMenuKey()));

		return Build.VERSION.SDK_INT <= Build.VERSION_CODES.GINGERBREAD_MR1;

		// return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			// Pop in the current tab
			popFragment();

			return true;

		}
		case R.id.menu__base_setting: {
			onGoToProfileSettingClick(null);
			return true;
		}
		case R.id.menu__base_logout: {
			onLogoutClick(null);
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public DGFragment getFragment() {
		return super.getFragment(R.id.fragment_container);
	}

	protected void showActionBarIcon(int resourceId) {
		// search for the current tab listener
		Tab tab = getSupportActionBar().getSelectedTab();
		StackTabManager listener = listeners.get(tab);

		ActionBar actionbar = getSupportActionBar();
		actionbar.setDisplayShowTitleEnabled(false);
		actionbar.setDisplayShowCustomEnabled(true);
		if (listener != null && listener.isLastFragment()) {
			actionbar.setDisplayHomeAsUpEnabled(false);
			actionbar.setHomeButtonEnabled(false);
		} else {
			actionbar.setDisplayHomeAsUpEnabled(true);
			actionbar.setHomeButtonEnabled(true);
		}

		titleView.setText(getString(resourceId));
		setTitleTypeface();
		actionbar.show();
	}

	@Override
	public void setTitle(CharSequence title) {
		super.setTitle(title);
		titleView.setText(title);
		setTitleTypeface();
	}

	@Override
	public void setTitle(int titleId) {
		super.setTitle(titleId);
		titleView.setText(getString(titleId));
		setTitleTypeface();
	}

	private void setTitleTypeface() {
		if (titleView.getText().toString().compareToIgnoreCase("ORA") == 0) {
			titleView.setTypeface(Typeface.createFromAsset(getAssets(), OraTextViewForOraName.FONT_NAME));
		} else {
			titleView.setTypeface(Typeface.createFromAsset(getAssets(), OraTextView.FONT_NAME));
		}
	}

	@Override
	public void finish() {
	}

	public void superFinish() {
		super.finish();
		((OraApplication) getApplication()).clearData();
	}

	@Override
	public void popFragment() {
		OraStackTabManager listener = getSelectedTabListener();
		listener.setShouldClear(false);
		super.popFragment();
		listener.setShouldClear(true);
	}

	@Override
	public void popAllFragments(DGFragment fragment) {
		OraStackTabManager listener = getSelectedTabListener();
		listener.setShouldClear(false);
		super.popAllFragments(fragment);
		listener.setShouldClear(true);
	}

	@Override
	public void pushFragment(DGFragment fragment) {
		OraStackTabManager listener = getSelectedTabListener();
		listener.setShouldClear(false);
		super.pushFragment(fragment);
		listener.setShouldClear(true);
	}

	/*
	 * Base methods
	 */
	public void onGoToProfileSettingClick(View view) {
		getSupportActionBar().getTabAt(INDEX_TAB_PROFILE).select();
		popAllFragments(new UserFragment());
		pushFragment(new SettingsFragment());
	}

	public void onLogoutClick(View view) {
		AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		SettingsFragment.onLogout(manager, this);
	}

	/*
	 * Home tab fragments
	 */

	public void onPrayerDetailAddCommentClick(View view) {
		((PrayerDetailFragment) getFragment()).onPrayerDetailAddCommentClick(view);
	}

	/*
	 * Circles tab fragments
	 */
	public void onCreateCircleClick(View view) {
		((AddCircleFragment) getFragment()).onCreateCircleClick(view);
	}

	public void onCirclesViewPrayersClick(View view) {
		((ViewCircleFragment) getFragment()).onCirclesViewPrayersClick(view);
	}

	public void onCirclesViewMembersClick(View view) {
		((ViewCircleFragment) getFragment()).onCirclesViewMembersClick(view);
	}

	public void onCirclesButtonClick(View view) {
		((ViewCircleFragment) getFragment()).onCirclesJoinCircleClick(view);
	}

	/*
	 * Create Prayers tab fragments
	 */

	/*
	 * Activities tab fragments
	 */

	/*
	 * User tab fragments
	 */

}
