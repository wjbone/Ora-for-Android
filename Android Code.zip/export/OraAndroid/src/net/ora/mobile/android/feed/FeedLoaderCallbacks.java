package net.ora.mobile.android.feed;

import net.ora.mobile.android.ui.OraLoaderCallbacks;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;

public interface FeedLoaderCallbacks<T> extends OraLoaderCallbacks<T> {
}
