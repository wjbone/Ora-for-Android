package net.ora.mobile.android.prayers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSAddComment;
import net.ora.mobile.android.webservices.prayers.WSDeletePrayer;
import net.ora.mobile.android.webservices.prayers.WSFlagPrayer;
import net.ora.mobile.android.webservices.prayers.WSPrayerListAdd;
import net.ora.mobile.android.webservices.prayers.WSPrayerListRemove;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.PrayerComment;
import net.ora.mobile.dto.prayers.response.AddCommentResponse;
import net.ora.mobile.dto.prayers.response.CommentsForPrayersResponse;
import net.ora.mobile.dto.prayers.response.DeletePrayerResponse;
import net.ora.mobile.dto.prayers.response.FlagPrayerResponse;
import net.ora.mobile.dto.prayers.response.PrayerListAddResponse;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.format.DateUtils;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.profile.PrayerView;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class PrayerDetailFragment extends CachedImageDataFragment implements
		LoaderManager.LoaderCallbacks<CommentsForPrayersResponse> {

	public static final String TAG_PRAYER = "prayer";
	public static final String TAG_SHOW_ONLY_COMMENTS = "show_only_comments";
	public static final int LOADER_ID_PRAYER_COMMENTS = 30;
	public static final int MENU_ID_DELETE_PRAYER = Menu.NONE + 1;
	public static final int MENU_ID_PRAYER_ANSWER = Menu.NONE + 2;
	public static final int MENU_ID_REMOVE_PRAYER = Menu.NONE + 3;
	public static final int MENU_ID_REPORT_PRAYER = Menu.NONE + 4;
	public static final int MENU_ID_ADD_PRAYER = Menu.NONE + 5;
	public static final int MENU_GROUP_MY_PRAYERS_LIST = Menu.NONE + 10;

	private Prayer prayer;

	private ViewGroup view;
	private ScrollView viewScroll;
	private ViewGroup viewPrayer;
	private EditText viewNewComment;
	private ViewGroup viewPrayerComments;
	private Menu menu;

	private PrayerView prayerView;
	private boolean showOnlyComments;

	public static PrayerDetailFragment getInstance(Prayer prayerId) {
		PrayerDetailFragment fragment = new PrayerDetailFragment();

		Bundle args = new Bundle();
		args.putParcelable(TAG_PRAYER, prayerId);

		fragment.setArguments(args);

		return fragment;
	}

	public static PrayerDetailFragment getInstance(Prayer prayerId, boolean showOnlyComments) {
		PrayerDetailFragment fragment = new PrayerDetailFragment();

		Bundle args = new Bundle();
		args.putParcelable(TAG_PRAYER, prayerId);
		args.putBoolean(TAG_SHOW_ONLY_COMMENTS, showOnlyComments);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			prayer = getArguments().getParcelable(TAG_PRAYER);
			showOnlyComments = getArguments().getBoolean(TAG_SHOW_ONLY_COMMENTS, false);
		}

		// Action bar icons
		setHasOptionsMenu(true);
	}

	protected boolean isShowKeyboard() {
		return showOnlyComments;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if (prayer == null)
			return super.onCreateView(inflater, container, savedInstanceState);

		String name = prayer.getUser().getRealName();
		int index = name.indexOf(" ");
		getActivity().setTitle(name.substring(0, ((index != -1 ? index : name.length()))) + "'s Prayer");
		prayerView = (PrayerView) ((OraApplication) getActivity().getApplication()).getParam("prayer_view");

		view = (ViewGroup) inflater.inflate(R.layout.fragment_prayer_detail, container, false);

		// Scroll view
		viewScroll = (ScrollView) view.findViewById(R.id.prayerDetail_sv_main);

		// Edit Text for new comment
		viewNewComment = (EditText) view.findViewById(R.id.prayerDetail_txtComment);
		viewNewComment.setOnFocusChangeListener(new CommentFocusListener());

		// Prayers list view group
		viewPrayerComments = (ViewGroup) view.findViewById(R.id.prayerDetail_lstComments);

		// Prayer info
		viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_prayer_full_description, null);
		((ViewGroup) view.findViewById(R.id.prayerDetail_layoutHeader)).addView(viewPrayer);
		setUpPrayerInfo(viewPrayer, prayer);

		// Show only comments
		if (showOnlyComments) {
			EditText viewComments = (EditText) view.findViewById(R.id.prayerDetail_txtComment);
			viewComments.requestFocus();
			InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.showSoftInput(viewComments, InputMethodManager.SHOW_IMPLICIT);
		}

		// Activate loader
		getActivity().getSupportLoaderManager().initLoader(LOADER_ID_PRAYER_COMMENTS, null, this);

		return view;
	}

	@Override
	public void onStop() {
		super.onStop();
		getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID_PRAYER_COMMENTS);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (prayerView != null) {
			prayerView.getCommentsCount().setText(Integer.toString(prayer.getCommentsCount()));
			prayerView.getPrayersCount().setText(Integer.toString(prayer.getLikesCount()));
			if (!prayer.isLikeAvailable()) {
				prayerView.getGrabber().setVisibility(View.GONE);
			}
			((OraApplication) getActivity().getApplication()).deleteParam("prayer_view");
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		// Save menu
		this.menu = menu;

		User user = ((OraApplication) getActivity().getApplication()).getUser();
		if (prayer.getUser().equals(user)) {
			// Delete
			menu.add(Menu.NONE, MENU_ID_DELETE_PRAYER, Menu.NONE, R.string.viewPrayer_btnDelete);

			if (!prayer.isAnswered()) {
				// Answer
				menu.add(Menu.NONE, MENU_ID_PRAYER_ANSWER, Menu.NONE, R.string.viewPrayer_btnAnswer);

				// Menu From List
				setMenuForMyPrayersList();
			}
		} else {
			// Report
			menu.add(Menu.NONE, MENU_ID_REPORT_PRAYER, Menu.NONE, R.string.viewPrayer_btnReport);
		}
	}

	private void setMenuForMyPrayersList() {
		menu.removeGroup(MENU_GROUP_MY_PRAYERS_LIST);
		if (prayer.isInMyList()) {
			// Remove
			menu.add(MENU_GROUP_MY_PRAYERS_LIST, MENU_ID_REMOVE_PRAYER, Menu.NONE, R.string.viewPrayer_btnRemove);
		} else {
			// Add
			menu.add(MENU_GROUP_MY_PRAYERS_LIST, MENU_ID_ADD_PRAYER, Menu.NONE, R.string.viewPrayer_btnAdd);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case MENU_ID_DELETE_PRAYER:
			new DeletePrayerActionDialog(getActivity()).init();
			return true;
		case MENU_ID_PRAYER_ANSWER:
			pushFragment(PrayerAnswerFragment.getInstance(prayer));
			return true;
		case MENU_ID_REPORT_PRAYER:
			new ReportPrayerActionDialog(getActivity()).init();
			return true;
		case MENU_ID_REMOVE_PRAYER:
			new RemoveFromMyListActionDialog(getActivity()).init();
			return true;
		case MENU_ID_ADD_PRAYER:
			new AddToMyListActionDialog(getActivity()).init();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void setUpPrayerInfo(ViewGroup viewPrayer, final Prayer prayer) {

		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());

		// Set listeners
		// if (prayer.isLikeAvailable()) {
		// viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer,
		// viewPrayer));
		// } else {
		// }
		View imgGrabber = viewPrayer.findViewById(R.id.feedPrayer_imGrabber);
		imgGrabber.setVisibility(View.GONE);

		// Set info
		((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());

		((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer)).setText(prayer.getUser().getName());

		// Go to user profile
		ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
		friendPicture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(
						new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
			}
		});
		ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

		friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
		circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

		pictureImageViewList.add(friendPicture);
		circleImageViewList.add(circlePicture);

		// Circles
		int circlesCount = prayer.getCircles().size();
		String firstCircle = "";
		if (circlesCount >= 1)
			firstCircle = prayer.getCircles().get(0).getName();
		String strCircles = getResources().getQuantityString(R.plurals.viewCircle_lblItemPrayer_circles, circlesCount,
				firstCircle, circlesCount - 1);
		// Set circles string
		((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);

		// Set prayer likes count
		((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer)).setText(Integer.toString(prayer.getLikesCount()));

		// Set prayer comments count
		((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer))
				.setText(Integer.toString(prayer.getCommentsCount()));

		// Set prayer time
		((TextView) viewPrayer.findViewById(R.id.tv_pray_time)).setText(GeneralMethods.fromDate(GeneralMethods
				.parseStringToDate(prayer.getDateCreated())));

		if (asyncTaskList.isEmpty()) {
			AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayerDetailFragmetsMain", getActivity(), this);
			asyncTaskList.add(async);

			// Set data
			Pair<User, ImageView>[] tempPair = new Pair[1];
			tempPair[0] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);
			async.execute(tempPair);
		}
	}

	private void setUpCommentView(View viewComment, final PrayerComment comment) {

		// Set info
		((TextView) viewComment.findViewById(R.id.tv_prayer_comment_text)).setText(comment.getText());

		((TextView) viewComment.findViewById(R.id.tv_prayer_comment_name_user)).setText(comment.getUser().getName());

		// Set date info
		Date date = GeneralMethods.parseStringToDate(comment.getDateCreated());
		if (date != null) {
			String strTime = DateUtils.getRelativeDateTimeString(getActivity(), date.getTime(), DateUtils.MINUTE_IN_MILLIS,
					DateUtils.MINUTE_IN_MILLIS, 0).toString();
			((TextView) viewComment.findViewById(R.id.tv_prayer_comment_time)).setText(strTime);
		}

		ImageView friendPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
		friendPicture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(
						new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", comment.getUser().getId()));
			}
		});
	}

	@Override
	public Loader<CommentsForPrayersResponse> onCreateLoader(int id, Bundle args) {
		PrayerCommentsLoader loader = new PrayerCommentsLoader(getActivity());
		loader.setPrayerId(prayer.getId());
		return loader;
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public void onLoadFinished(Loader<CommentsForPrayersResponse> loader, CommentsForPrayersResponse data) {
		// Load pictures
		Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[data.getComments().size()];
		int i = 0;

		// Inflate views
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		for (PrayerComment comment : data.getComments()) {
			View viewComment = inflater.inflate(R.layout.item_prayer_comment, null);
			setUpCommentView(viewComment, comment);
			viewPrayerComments.addView(viewComment);

			// Load picture
			ImageView commentPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
			usersImagesViewsPairs[i++] = new Pair<User, ImageView>(comment.getUser(), commentPicture);
		}
		AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayerDetailFragmetsMain", getActivity(),
				PrayerDetailFragment.this);
		asyncTaskList.add(async);
		async.execute(usersImagesViewsPairs);
	}

	@Override
	public void onLoaderReset(Loader<CommentsForPrayersResponse> loader) {
	}

	public void onPrayerDetailAddCommentClick(View view) {
		new AddCommentActionDialog(getActivity()).init();
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class AddCommentActionDialog extends ActionDialog<AddCommentResponse> {

		public AddCommentActionDialog(Activity context) {
			super(context);
		}

		@Override
		public AddCommentResponse performAction() {

			int prayerId = prayer.getId();
			String text = ((TextView) view.findViewById(R.id.prayerDetail_txtComment)).getText().toString();

			return WSAddComment.addComment(context, prayerId, text);
		}

		@SuppressWarnings("unchecked")
		@Override
		public void afterAction(AddCommentResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Update
			prayer.setCommentsCount(response.getPrayer().getCommentsCount());
			setUpPrayerInfo(viewPrayer, prayer);

			// Add new comment to layout
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss", Locale.getDefault());
			TimeZone timeZone = TimeZone.getTimeZone("UTC");
			format.setTimeZone(timeZone);

			LayoutInflater inflater = LayoutInflater.from(getActivity());
			View viewComment = inflater.inflate(R.layout.item_prayer_comment, null);
			PrayerComment comment = new PrayerComment();
			comment.setId(response.getCommentId());
			comment.setFlagged(false);
			comment.setText(response.getText());
			comment.setDateCreated(format.format(new Date()));
			comment.setUser(new User(((OraApplication) getActivity().getApplication()).getUser()));

			setUpCommentView(viewComment, comment);

			// Clear comment text box
			TextView viewTemp = (TextView) view.findViewById(R.id.prayerDetail_txtComment);
			viewTemp.setText("");
			// Hide keyboard
			hideKeyboard(viewTemp);

			viewPrayerComments.addView(viewComment, 0);

			// Load picture
			ImageView commentPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
			AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayerDetailFragmetsMain", getActivity(),
					PrayerDetailFragment.this);
			asyncTaskList.add(async);
			Pair<User, ImageView>[] tempPair = new Pair[1];
			tempPair[0] = new Pair<User, ImageView>(comment.getUser(), commentPicture);
			async.execute(tempPair);
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	class DeletePrayerActionDialog extends ActionDialog<DeletePrayerResponse> {

		public DeletePrayerActionDialog(Activity context) {
			super(context);
		}

		@Override
		public DeletePrayerResponse performAction() {
			return WSDeletePrayer.deletePrayer(context, prayer);
		}

		@Override
		public void afterAction(DeletePrayerResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Confirmation
			Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();

			// Exit
			popFragment();
		}

	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	class ReportPrayerActionDialog extends ActionDialog<FlagPrayerResponse> {

		public ReportPrayerActionDialog(Activity context) {
			super(context);
		}

		@Override
		public FlagPrayerResponse performAction() {
			return WSFlagPrayer.flagPrayer(context, prayer);
		}

		@Override
		public void afterAction(FlagPrayerResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Confirmation
			Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();

			// Exit
			if (response.isFlagged()) {
				popFragment();
			}
		}

	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class AddToMyListActionDialog extends ActionDialog<PrayerListAddResponse> {

		public AddToMyListActionDialog(Activity context) {
			super(context);
		}

		@Override
		public PrayerListAddResponse performAction() {
			return WSPrayerListAdd.addToPrayerList(context, prayer.getId());
		}

		@Override
		public void afterAction(PrayerListAddResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Show success message
			Toast.makeText(context, context.getString(R.string.prayer_msgAddToMyList), Toast.LENGTH_SHORT).show();
			prayer.setInMyList(response.isInMyList());

			// configure menu
			setMenuForMyPrayersList();
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class RemoveFromMyListActionDialog extends ActionDialog<PrayerListAddResponse> {

		public RemoveFromMyListActionDialog(Activity context) {
			super(context);
		}

		@Override
		public PrayerListAddResponse performAction() {
			return WSPrayerListRemove.removeFromPrayerList(context, prayer.getId());
		}

		@Override
		public void afterAction(PrayerListAddResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Show success message
			Toast.makeText(context, context.getString(R.string.prayer_msgRemovedFromMyList), Toast.LENGTH_SHORT).show();
			prayer.setInMyList(response.isInMyList());

			// configure menu
			setMenuForMyPrayersList();
		}

	}

	public class CommentFocusListener implements OnFocusChangeListener {

		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			if (hasFocus) {
				viewScroll.requestDisallowInterceptTouchEvent(true);
			} else {
				viewScroll.requestDisallowInterceptTouchEvent(false);
				hideKeyboard(v);
			}

		}

	}
}
