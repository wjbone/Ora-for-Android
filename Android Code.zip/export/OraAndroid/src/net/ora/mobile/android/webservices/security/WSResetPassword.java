package net.ora.mobile.android.webservices.security;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.ServiceResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSResetPassword extends MasterService {

private static String URL = "rec_pwd/";
	
	public static ServiceResponse resetPassword(Context context, String username) {
		try {
			// Validates
			validateRequired(context, username, R.string.wsResetPassword_errorUsarname);
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("email", username));
		
			// Make request
			ServiceResponse response = makeRequest(context, CONNECTION_TYPE.POST, 
					URL, request, new TypeReference< ServiceResponse >() {});
			
			return response;
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsResetPassword_error);
		}
		
		return null;
	}
}
