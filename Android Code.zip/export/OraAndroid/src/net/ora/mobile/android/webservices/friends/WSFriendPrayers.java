package net.ora.mobile.android.webservices.friends;

import java.io.IOException;
import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.core.type.TypeReference;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;

import android.content.Context;

public class WSFriendPrayers extends MasterService {

	private static final String URL = "prayers_for_user";
	private static RequestPrayersResponse response;
	
	public static RequestPrayersResponse requestPrayersForUser(Context context, User user, String page){
		RequestPrayersResponse result = null;
		
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("user_id", Integer.toString(user.getId())));			
			request.add(new BasicNameValuePair("prayer_id", "-1"));			
			request.add(new BasicNameValuePair("page", page));
			
			// Request to server
			result = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< RequestPrayersResponse >() {});

			// Set user in the prayers
			if(!isFailedConnection()) {
				for(Prayer prayer : result.getPrayers()) {
					if(prayer.getUser() == null) {
						prayer.setUser(user);
					}
				}
			}
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
		
		response = result;
		return result;
	}

	public static RequestPrayersResponse getResponse() {
		return response;
	}
	
}
