package net.ora.mobile.android.util;

import java.io.File;
import java.util.Vector;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CustomHttpEntityBuilder;

public class ParseImageHttpEntityBuilder implements CustomHttpEntityBuilder {

	private String pictureName;
	
	public ParseImageHttpEntityBuilder(String pictureName) {
		this.pictureName = pictureName;
	}
	
	public void build(Vector<NameValuePair> vars, HttpPost request) {
		// Post Params (new entity)
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

		for (NameValuePair pair : vars) {
			if (pair.getName().equals(pictureName)) {
				File videoFile = new File(pair.getValue());
				// InputStream inputStream = new FileInputStream(videoFile);
				// FileBody pictureFileBody = new FileBody(videoFile, ContentType.DEFAULT_BINARY);
				// builder.addPart("profile_picture", pictureFileBody);
				builder.addBinaryBody(pictureName, videoFile, ContentType.DEFAULT_BINARY, "picture_name");
			} else {
				builder.addTextBody(pair.getName(), pair.getValue());
			}
		}

		HttpEntity httpEntity = builder.build();
		request.setEntity(httpEntity);
	}
}
