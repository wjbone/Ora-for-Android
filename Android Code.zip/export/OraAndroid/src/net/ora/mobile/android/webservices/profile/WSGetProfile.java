package net.ora.mobile.android.webservices.profile;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.profile.response.GetProfileResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSGetProfile extends MasterService {

	private static String URL = "get_profile/";
	private static GetProfileResponse response;
	
	public static void getProfile(OraApplication application, Context context, String userId) {
		try {
			// Validates
			validateRequired(context, userId, R.string.wsGetProfile_errorUserId);
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("user_id", userId));
		
			// Make request
			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL, request, new TypeReference< GetProfileResponse >() {});
			
			if(response.getProfileUser() != null){
				response.getProfileUser().setHaveNotification(application.getUser().isHaveNotification());
				response.getProfileUser().setHour(application.getUser().getHour());
				response.getProfileUser().setMinute(application.getUser().getMinute());
				
				application.setUser(response.getProfileUser());
			}
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsGetProfile_error);
		}
	}

	public static GetProfileResponse getResponse() {
		return response;
	}
	
}
