package net.ora.mobile.android.help;

import net.ora.mobile.android.R;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class TutorialPageFragment extends Fragment {
	
	private static final String TAG_INDEX = "index";

	private int index; 

	public static TutorialPageFragment getInstance(int index) {
		// Fragment
		TutorialPageFragment fragment = new TutorialPageFragment();
		
		// Args
		Bundle args = new Bundle();
		args.putInt(TAG_INDEX, index);
		fragment.setArguments(args);
		
		// Return
		return fragment;
	}
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Creck index
		Bundle args = getArguments();
		if(args != null) {
			index = args.getInt(TAG_INDEX, 0);
		}
	};
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_tutorial_page, container, false);
		
		ImageView ivPage = (ImageView) view.findViewById(R.id.tutorial_page__iv_image);
		ivPage.setImageResource(getTutorialPageResourceId(this.index));
		
		return view;
	};
	
	private int getTutorialPageResourceId(int index) {
		switch(index) {
		case 4:
			return R.drawable.tutorial__learning_ora_overlay__page_5;
		case 3:
			return R.drawable.tutorial__learning_ora_overlay__page_4;
		case 2:
			return R.drawable.tutorial__learning_ora_overlay__page_3;
		case 1:
			return R.drawable.tutorial__learning_ora_overlay__page_2;
		default:
			return R.drawable.tutorial__learning_ora_overlay__page_1;
		}
	}
}
