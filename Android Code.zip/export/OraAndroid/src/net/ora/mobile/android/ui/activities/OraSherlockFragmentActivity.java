package net.ora.mobile.android.ui.activities;

import net.ora.mobile.android.R;
import com.actionbarsherlock.app.SherlockFragmentActivity;

public class OraSherlockFragmentActivity extends SherlockFragmentActivity {

	@Override
	protected void onResume() {
		super.onResume();

		// Facebook tracking
		com.facebook.Settings.publishInstallAsync(this, getString(R.string.applicationId));
	}
}
