package net.ora.mobile.android.ui;

import net.ora.mobile.dao.FeedDBHelper;
import android.content.Context;

import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.j256.ormlite.android.apptools.OpenHelperManager;

public abstract class OraDbActionDialog<T> extends ActionDialog<T> {

	private FeedDBHelper helper;
	
	public OraDbActionDialog(Context context) {
		super(context);
	}
	 
    protected FeedDBHelper getHelper() {
        if (helper == null) {
        	helper = OpenHelperManager.
        			getHelper(getContext(), FeedDBHelper.class);
        }
        return helper;
    }
 
    @Override
	public void finallyAction() {
        if (helper != null) {
            OpenHelperManager.releaseHelper();
            helper = null;
        }
    }


}
