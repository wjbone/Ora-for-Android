package net.ora.mobile.android.profile;

import net.ora.mobile.android.R;
import net.ora.mobile.android.city_state.SearchCityStateActivity;
import net.ora.mobile.android.city_state.SearchCountryActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSSearchUser;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;

public class AddOraFriendsListFragment extends FragmentImageData {

	public static final int SELECT_PLACE = 3;

	private ListView oraFriendsList;
	private EditText friendName;
	private Button friendCity;

	private View viewProgressBar;
	private LoadingSearchFriendsAsync task;
	private AddOraFriendsListAdapter adapter;
	private Bitmap defaultBitmap;

	@Override
	protected int getActionBarString() {
		return R.string.addOraFriendsList_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.list_search_for_add, container, false);

		// Progress bar
		viewProgressBar = view.findViewById(R.id.pbLoading);

		oraFriendsList = (ListView) view.findViewById(R.id.ly_search_friend_list);

		friendCity = (Button) view.findViewById(R.id.b_search_friend_city);
		friendCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(getActivity(), SearchCountryActivity.class), SELECT_PLACE);
			}
		});

		friendName = (EditText) view.findViewById(R.id.et_search_friend_name);
		/*
		 * friendName.requestFocus();
		 * getActivity().getWindow().setSoftInputMode(
		 * LayoutParams.SOFT_INPUT_STATE_VISIBLE);
		 */
		friendName.addTextChangedListener(new SearchFeedManager(friendName));

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		// Load bitmap
		defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
	}

	// private Runnable searchForName = new Runnable() {
	// @Override
	// public void run() {
	// if(friendName.getText().toString().trim().length() > 0){
	// View loadingView = setLoading();
	//
	// LoadingSearchFriendsAsync asyncSearch = new
	// LoadingSearchFriendsAsync("AddOraFriendsList", getActivity(),
	// oraFriendsList, loadingView, AddOraFriendsListFragment.this);
	// asyncSearch.execute(new String[]{friendName.getText().toString().trim(),
	// friendCity.getText().toString(), "1"});
	// }
	// }
	// };

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if ((requestCode == SELECT_PLACE) && (resultCode == android.app.Activity.RESULT_OK)) {
			String response = data.getStringExtra("city_state");
			friendCity.setText(data.getStringExtra("city_state"));
			if (response.length() > 0) {

				task = new LoadingSearchFriendsAsync("AddOraFriendsList", getActivity());
				getAsyncTaskList().add(task);
				task.execute(new String[] { friendName.getText().toString().trim(), friendCity.getText().toString(), "1" });
			}
		} else {
			friendCity.setText("");
		}
	}

	// private View setLoading() {
	// oraFriendsList.removeAllViews();
	//
	// LayoutInflater inflater = LayoutInflater.from(getActivity());
	// View loadingView = inflater.inflate(R.layout.item_city_loading, null);
	//
	// oraFriendsList.addView(loadingView);
	//
	// return loadingView;
	// }

	private AddOraFriendsListAdapter getSearchCityListAdapter(FriendUser[] users) {
		adapter = new AddOraFriendsListAdapter(getActivity(), users, defaultBitmap);
		return adapter;
	}

	/*
	 * 
	 */
	public class LoadingSearchFriendsAsync extends AsyncTask<String, Void, FriendUser[]> {

		private Activity context;
		private String name;

		public LoadingSearchFriendsAsync(String name, Activity context) {
			super();
			this.name = name;
			this.context = context;
		}

		@Override
		protected FriendUser[] doInBackground(String... params) {
			
			Log.w("LoadingSearchFriendsAsync", name);
			WSSearchUser.searchForUser(context, params[0], params[1], params[2]);
			Log.w("LoadingSearchFriendsAsync", "Ending Process - " + name);

			return WSSearchUser.getResponse().getUsers();
		}

		@Override
		protected void onPostExecute(FriendUser[] users) {
			super.onPostExecute(users);

			// Progress bar
			viewProgressBar.setVisibility(View.GONE);

			// Check errror
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Users
			oraFriendsList.setAdapter(getSearchCityListAdapter(users));
			oraFriendsList.setVisibility(View.VISIBLE);
		}
	}

	/*
	 * 
	 */
	public class SearchFeedManager implements TextWatcher {

		private Handler mHandler;
		private EditText etSearch;

		public SearchFeedManager(EditText text) {
			this.etSearch = text;
			mHandler = new Handler();
		}

		private Runnable searchRunnable = new Runnable() {
			@Override
			public void run() {
				mHandler.removeCallbacks(searchRunnable);
				if (etSearch.getText().toString().trim().length() > 0) {
					task = new LoadingSearchFriendsAsync("AddOraFriendsList", getActivity());
					getAsyncTaskList().add(task);
					task.execute(etSearch.getText().toString(), "", "1");
				}
			}

		};

		@Override
		public void afterTextChanged(Editable s) {
			// Stop
			mHandler.removeCallbacks(searchRunnable);
			if (task != null)
				task.cancel(true);

			// Visual
			oraFriendsList.setVisibility(View.GONE);

			if (s.length() > 0) {
				viewProgressBar.setVisibility(View.VISIBLE);
				mHandler.postDelayed(searchRunnable, 1500);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}
}
