package net.ora.mobile.android.prayers;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSCommentsForPrayer;
import net.ora.mobile.dto.prayers.response.CommentsForPrayersResponse;
import android.content.Context;
import android.util.Log;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;

/**
 * 
 * @author byron
 * 
 */
public class PrayerCommentsLoader extends DGAsyncTaskLoader<CommentsForPrayersResponse> {
	
	private int prayerId = 0;
	
	public PrayerCommentsLoader(Context context) {
		super(context);
	}
	
	public int getPrayerId() {
		return prayerId;
	}

	public void setPrayerId(int prayerId) {
		this.prayerId = prayerId;
	}

	@Override
	public CommentsForPrayersResponse loadInBackground() {
		
		Log.i("Loader", "init");
		
		Context context = getContext();
		CommentsForPrayersResponse response = WSCommentsForPrayer.getCommentsForPrayer(context, prayerId);
		
		if (MasterService.isFailedConnection()) {
//			Toast.makeText(context, MasterService.getErrorMessage(),
//					Toast.LENGTH_SHORT).show();
			abandon();
			return null;
		}
		
		Log.i("Loader", "finish");
		
		return response;
	}
}
