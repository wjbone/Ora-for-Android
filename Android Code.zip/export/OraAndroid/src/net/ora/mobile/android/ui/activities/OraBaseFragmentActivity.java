package net.ora.mobile.android.ui.activities;

import net.ora.mobile.android.R;

import com.digitalgeko.mobile.android.ui.BaseFragmentActivity;
import com.digitalgeko.mobile.android.ui.StackTabManager;

public class OraBaseFragmentActivity<T extends StackTabManager> extends BaseFragmentActivity<T> {

	@Override
	protected void onResume() {
		super.onResume();

		// Facebook tracking
		com.facebook.Settings.publishInstallAsync(this, getString(R.string.applicationId));
	}
}
