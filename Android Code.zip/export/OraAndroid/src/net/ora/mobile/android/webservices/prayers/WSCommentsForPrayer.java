package net.ora.mobile.android.webservices.prayers;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.response.CommentsForPrayersResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCommentsForPrayer extends MasterService {

	private static final String URL = "comments_for_prayer/";

	public static CommentsForPrayersResponse getCommentsForPrayer(Context context, int prayerId) {

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("prayer_id", Integer
					.toString(prayerId)));

			// Make request
			CommentsForPrayersResponse response = makeRequest(context,
					CONNECTION_TYPE.GET, URL, request,
					new TypeReference<CommentsForPrayersResponse>() {
					});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsRelatedCircles_error);
		}

		return null;
	}
}
