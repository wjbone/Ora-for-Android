package net.ora.mobile.android.webservices.friends;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.friend.response.GetFriendProfileResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSGetFriendProfile extends MasterService {

	private static String URL = "get_profile/";
	
	public static GetFriendProfileResponse getFriendProfile(Context context, String userId){
		GetFriendProfileResponse result = null;
		
		try{
			// Validates
			validateRequired(context, userId, R.string.wsGetProfile_errorUserId);
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("user_id", userId));
		
			// Make request
			result = makeRequest(context, CONNECTION_TYPE.GET, 
					URL, request, new TypeReference< GetFriendProfileResponse >() {});
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsGetProfile_error);
		}
		
		return result;
	}
	
}
