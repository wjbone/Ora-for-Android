package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.util.ParseImageHttpEntityBuilder;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.EditProfileResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSEditProfile extends MasterService {

	private static final String URL = "user_profile_edit_v2/";
	private static EditProfileResponse response;

	public static EditProfileResponse getResponse() {
		return response;
	}

	public static void editProfile(OraApplication application, Context context, String name, String about, String email, String mobile, String city,
			String password, String current_password, boolean isPrivate, String picturePath) {

		try {
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			if (name.trim().length() > 0) {
				request.add(new BasicNameValuePair("name", name.trim()));
			}
			if (about.trim().length() > 0) {
				request.add(new BasicNameValuePair("about", about.trim()));
			}
			if (email.trim().length() > 0) {
				request.add(new BasicNameValuePair("email", email.trim()));
			}
			if (mobile.trim().length() > 0) {
				request.add(new BasicNameValuePair("mobile", mobile.trim()));
			}
			if (city.trim().length() > 0) {
				request.add(new BasicNameValuePair("city", city.trim()));
			}
			if (password.trim().length() > 0) {
				request.add(new BasicNameValuePair("password", password.trim()));
			}
			if (current_password.trim().length() > 0) {
				request.add(new BasicNameValuePair("current_password", current_password.trim()));
			}
			request.add(new BasicNameValuePair("private", (isPrivate ? "1" : "0")));
			if (picturePath != null && picturePath.trim().length() > 0) {
				request.add(new BasicNameValuePair("image", picturePath));
			}
			request.add(new BasicNameValuePair("remove_image", "0")); // Don't remove profile picture

			// Make request
			response = makeRequest(context, CONNECTION_TYPE.POST, URL, request, new ParseImageHttpEntityBuilder("image"),
					new TypeReference<EditProfileResponse>() {
					});

			if (response.getProfileUser() != null) {
				response.getProfileUser().setHaveNotification(application.getUser().isHaveNotification());
				response.getProfileUser().setHour(application.getUser().getHour());
				response.getProfileUser().setMinute(application.getUser().getMinute());

				application.setUser(response.getProfileUser());
			}

		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
}
