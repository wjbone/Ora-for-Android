package net.ora.mobile.android.ui;

import android.app.Activity;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;


abstract public class OraAsyncTaskLoader<T> extends DGAsyncTaskLoader<T> {

	private OraLoaderCallbacks<T> callbacks;
	private Activity activity;
	
	public OraAsyncTaskLoader(Activity activity, OraLoaderCallbacks<T> callbacks) {
		super(activity);
		this.activity = activity;
		this.callbacks = callbacks;
	}
	
	@Override
	public void abandon() {
		super.abandon();
		activity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				callbacks.onAbandon(OraAsyncTaskLoader.this);
			}
		});
	}
	
	protected Activity getActivity() {
		return activity;
	}

}
