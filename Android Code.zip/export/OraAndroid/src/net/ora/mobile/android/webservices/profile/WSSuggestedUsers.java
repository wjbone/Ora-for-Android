package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.SuggestedFriendsResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSSuggestedUsers extends MasterService {

	private static final String URL = "suggested_users/";
	private static SuggestedFriendsResponse response;
	
	public static SuggestedFriendsResponse getResponse() {
		return response;
	}
	
	public static void findSuggestions(Context context){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();	
			
			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< SuggestedFriendsResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
