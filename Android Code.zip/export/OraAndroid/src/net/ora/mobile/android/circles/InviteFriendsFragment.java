package net.ora.mobile.android.circles;

import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSFriendsMembership;
import net.ora.mobile.android.webservices.circles.WSInviteToCircle;
import net.ora.mobile.android.webservices.profile.WSFriendsList;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.FriendsMembershipResponse;
import net.ora.mobile.dto.circles.response.InviteToCircleResponse;
import android.app.Activity;
import android.app.DownloadManager.Request;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageSearchFriends;
import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;


public class InviteFriendsFragment extends CachedImageDataFragment {

	private Circle circle;

	private View view;
	private ViewGroup viewMembersList;

	public static InviteFriendsFragment getInstance(Circle circle) {
		InviteFriendsFragment fragment = new InviteFriendsFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments().getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}
	}

	@Override
	protected int getActionBarString() {
		return R.string.inviteMembers_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		// Save
		if (circle == null) {
			return null;
		}

		// Inflate View
		view = inflater.inflate(R.layout.fragment_circles_invite_friends, container, false);

		// Friend List
		viewMembersList = (ViewGroup) view.findViewById(R.id.inviteMembers_layoutList);

		// Return view
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		// Load friend list
		new LoadFriendsActionDialog(getActivity()).init();
	}
	
	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class LoadFriendsActionDialog extends ActionDialog<FriendsMembershipResponse> {

		public LoadFriendsActionDialog(Activity context) {
			super(context);
		}

		@Override
		public FriendsMembershipResponse performAction() {
			// Load list
			return WSFriendsMembership.getFriendsMembership(context, circle.getId());
		}

		@Override
		public void afterAction(FriendsMembershipResponse response) {
			// Validate list
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				popFragment();
				return;
			}

			for (CircleMember friend : response.getUsers()) {

				LayoutInflater inflater = LayoutInflater.from(getActivity());
				View viewFriend = inflater.inflate(R.layout.item_friend_as_circle_member, null);

				TextView tvName = (TextView) viewFriend.findViewById(R.id.tv_item_friend_name);
				tvName.setText(friend.getName());
				
				// Configure Button
				setFriendButton(friend, viewFriend);

				ImageView friendPicture = ((ImageView) viewFriend.findViewById(R.id.iv_item_friend_image));
				pictureImageViewList.add(friendPicture);

				viewMembersList.addView(viewFriend);
			}

//			AsyncDownloadImageSearchFriends async = new AsyncDownloadImageSearchFriends("InviteMembersFragmets", context,
//					InviteFriendsFragment.this);
//			async.setListPictures(pictureImageViewList);
//
//			getAsyncTaskList().add(async);
//
//			async.execute(friends);
		}
	}
	
	public void setFriendButton(CircleMember friend, View viewFriend) {
		Button btnInvite = (Button) viewFriend.findViewById(R.id.b_item_friend_button);
		if(friend.isMember()) {
			btnInvite.setText(R.string.friendsList_btnMember);
		} else if(friend.isInvited()){
			btnInvite.setText(R.string.friendsList_btnInvited);
		} else {
			btnInvite.setOnClickListener(new FriendInviteManager(friend, viewFriend));
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class FriendInviteManager implements OnClickListener {

		protected CircleMember friend;
		protected View viewFriend;

		public FriendInviteManager(CircleMember friend, View viewFriend) {
			this.friend = friend;
			this.viewFriend = viewFriend;
		}

		@Override
		public void onClick(View v) {
			new InviteToFriendActionDialog(getActivity()).init();
		}

		public class InviteToFriendActionDialog extends ActionDialog<InviteToCircleResponse> {

			public InviteToFriendActionDialog(Activity context) {
				super(context);
			}

			@Override
			public InviteToCircleResponse performAction() {
				int userId = friend.getId();
				int circleId = circle.getId();
				return WSInviteToCircle.inviteToCircle(context, userId, circleId);
			}

			@Override
			public void afterAction(InviteToCircleResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				} else {
					
					// Set friends attrs
					friend.setInvited(response.isInvited());
					friend.setMember(response.isMember());
					friend.setRequested(response.isRequested());
					
					// Configure Button
					setFriendButton(friend, viewFriend);
					
					// Acknowledge 
					Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
				}
			}
		}
	}

}
