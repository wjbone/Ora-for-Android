package net.ora.mobile.android.prayers;

public class PrayerViewBuilder {

	
}
