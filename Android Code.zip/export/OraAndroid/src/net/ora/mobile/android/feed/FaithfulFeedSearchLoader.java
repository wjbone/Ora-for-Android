package net.ora.mobile.android.feed;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.feed.WSFaithfulFeedSearch;
import net.ora.mobile.android.webservices.feed.WSPrayersFeedSearch;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.app.Activity;
import android.content.Context;
import android.util.Log;

/**
 * 
 * @author byron
 * 
 */
public class FaithfulFeedSearchLoader extends FeedAsyncTaskLoader {

	private String query = "";
	private int page = 1;

	public FaithfulFeedSearchLoader(Activity activity, FeedLoaderCallbacks<PrayersFeedResponse> callbacks) {
		super(activity, callbacks);
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	@Override
	public PrayersFeedResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			Log.i("Loader", "No more data");
			return PrayersFeedResponse.EMPTY_RESPONSE;
		}

		Context context = getContext();
		PrayersFeedResponse response = WSFaithfulFeedSearch.searchFaithfulFeed(context,
				query, page);

		if (MasterService.isFailedConnection()) {
			showErrorMessage(MasterService.getErrorMessage());
			abandon();
			return null;
		} 
		
		Log.i("Loader", "finish");

		return response;
	}

}
