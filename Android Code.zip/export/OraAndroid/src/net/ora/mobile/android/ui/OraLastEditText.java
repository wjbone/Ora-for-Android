package net.ora.mobile.android.ui;

import com.digitalgeko.mobile.android.ui.DGFragment;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

public class OraLastEditText extends OraEditText {

	public OraLastEditText(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public OraLastEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public OraLastEditText(Context context) {
		super(context);
	}

	@Override
	protected void init(final Context context) {
		super.init(context);

		// Key listener
		setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
					// Hide keyboard
					DGFragment.hideKeyboard(OraLastEditText.this);
					
					// Must return true here to consume event
					return true;
				}
				return false;
			}
		});
	}

}
