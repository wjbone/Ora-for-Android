package net.ora.mobile.android.profile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSFacebookSynchronization;
import net.ora.mobile.android.webservices.profile.WSShareOnFacebook;
import net.ora.mobile.android.webservices.profile.WSSuggestedFriends;
import net.ora.mobile.android.webservices.profile.WSSuggestedUsersV2;
import net.ora.mobile.dto.profile.request.PhoneFacebookContacts;
import net.ora.mobile.dto.profile.response.SugResponse;

import org.json.JSONException;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadFriendsImage;
import com.digitalgeko.mobile.android.objects.RequestFriendUser;
import com.digitalgeko.mobile.android.objects.facebook.FB_Friend;
import com.digitalgeko.mobile.android.objects.profile.PhoneContact;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGListFriendsFragment;
import com.facebook.FacebookException;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.Session.StatusCallback;
import com.facebook.SessionState;
import com.facebook.model.GraphUser;
import com.facebook.widget.InviteFriendsButton;
import com.facebook.widget.InviteFriendsButton.OnErrorListener;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MyContactFriendsFragments extends DGListFriendsFragment {

	public static final String TAG_LOG = "AddFriendsListFragment";

	private static final int GROUP_FRIENDS = Menu.NONE;
	private static final int ITEM_SEARCH = Menu.NONE;

	private ListView oraFriendsListView;
	private ListView facebookFriendListView;
	private LinearLayout facebookButtonLayout;
	private InviteFriendsButton facebookButton;

	private List<FB_Friend> facebookFriendsList;
	private DownloadFriendsImage asyncFacebookFriendsOne, asyncFacebookFriendsTwo, asyncFacebookFriendsThree,
			asyncFacebookFriendsFour, asyncFacebookFriendsFive;

	private List<List<FB_Friend>> friendsBitmapList;
	private List<List<ImageView>> friendsImageDoubleList;

	private Bitmap defaultBitmap;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	protected int getActionBarString() {
		return R.string.friendsList_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.list_friends, container, false);

		oraFriendsListView = (ListView) view.findViewById(R.id.ly_Friends_OraList);
		facebookFriendListView = (ListView) view.findViewById(R.id.ly_Friends_FBList);
		facebookButtonLayout = (LinearLayout) view.findViewById(R.id.ly_Friends_FBbtn);
		facebookButton = (InviteFriendsButton) view.findViewById(R.id.b_Friends_FBConnect);

		Boolean loginFacebook = false;
		if (WSShareOnFacebook.isFacebookLogin()) {
			Session openSession = Session.getActiveSession();
			Log.i("FB ReLogin", "Access Token: " + openSession.getAccessToken());
			facebookButtonLayout.setVisibility(View.GONE);
			loginFacebook = true;
			new AddTwoKindFriendDialog(getSherlockActivity(), openSession).init();
		} else {
			facebookButton.setApplicationId("257685094367122");
			facebookButton.setReadPermissions(Arrays.asList("email", "friends_hometown"));

			facebookButton.setOnErrorListener(new OnErrorListener() {
				@Override
				public void onError(FacebookException error) {
					Log.e(TAG_LOG, "Error " + error.getMessage());
					Toast.makeText(getSherlockActivity(), "Had problems with facebook, try again later.", Toast.LENGTH_SHORT)
							.show();
				}
			});

			facebookButton.setSessionStatusCallback(new StatusCallback() {

				@Override
				public void call(Session session, SessionState state, Exception exception) {
					if (session.isOpened()) {
						facebookButtonLayout.setVisibility(View.GONE);

						Log.i("FBAutentication", "Access Token: " + session.getAccessToken());
						new AddFriendsListInitialDialog(getSherlockActivity(), session).init();
					}

					if (exception != null) {
						Log.e("Facebook Ex", exception.getMessage());
					}
				}

			});
		}

		asyncFacebookFriendsOne = new DownloadFriendsImage("One", getSherlockActivity());
		asyncFacebookFriendsTwo = new DownloadFriendsImage("Two", getSherlockActivity());
		asyncFacebookFriendsThree = new DownloadFriendsImage("Three", getSherlockActivity());
		asyncFacebookFriendsFour = new DownloadFriendsImage("Four", getSherlockActivity());
		asyncFacebookFriendsFive = new DownloadFriendsImage("Five", getSherlockActivity());

		friendsImageDoubleList = new ArrayList<List<ImageView>>();
		friendsBitmapList = new ArrayList<List<FB_Friend>>();

		if (!loginFacebook) {
			new ConsultListContactDialog(getSherlockActivity()).init();
		}

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
		super.onCreateOptionsMenu(menu, menuInflater);

		// Vars
		MenuItem sub;

		// Find circle button
		sub = menu.add(GROUP_FRIENDS, ITEM_SEARCH, Menu.NONE, getString(R.string.friendsList_miSearch));
		sub.setIcon(R.drawable.ic_search);
		sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case ITEM_SEARCH: {
			pushFragment(new AddOraFriendsListFragment());
			return true;
		}
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Session.getActiveSession().onActivityResult(getSherlockActivity(), requestCode, resultCode, data);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		asyncFacebookFriendsOne.cancel(true);
		asyncFacebookFriendsTwo.cancel(true);
		asyncFacebookFriendsThree.cancel(true);
		asyncFacebookFriendsFour.cancel(true);
		asyncFacebookFriendsFive.cancel(true);

		for (List<ImageView> tempList : friendsImageDoubleList) {
			for (ImageView temp : tempList) {
				unbindDrawables(temp);
			}
		}

		for (List<FB_Friend> tempList : friendsBitmapList) {
			for (FB_Friend temp : tempList) {
				temp.freeBitmapMemory();
			}
		}
		System.gc();
	}

	private void addOraFriends(List<RequestFriendUser> users) {
		// Vars
		String strButtonAdd = getString(R.string.friendsList_btnAdd);

		// Set new list data
		MyContactFiendsContactsListAdapter adapter = new MyContactFiendsContactsListAdapter(getActivity(), users, defaultBitmap,
				strButtonAdd);
		oraFriendsListView.setAdapter(adapter);
	}

	private void addFacebookFriends() {
		facebookButtonLayout.setVisibility(View.GONE);

		// New list data
		String strButtonInvite = getString(R.string.friendsList_btnInvite);
		MyContactFiendsFacebookFriendsListAdapter adapter = new MyContactFiendsFacebookFriendsListAdapter(getActivity(),
				facebookFriendsList, defaultBitmap, strButtonInvite);
		facebookFriendListView.setAdapter(adapter);
	}

	/*
	 * 
	 */
	public static List<PhoneContact> getContactList(ContentResolver resolver) {
		Log.i(TAG_LOG, "Begin reading cursor data");

		// Contac list
		List<PhoneContact> contacts = new ArrayList<PhoneContact>();

		// Cursor mCursor =
		Cursor mCursor = resolver.query(Data.CONTENT_URI, new String[] { Contacts._ID, Data.MIMETYPE, Email.DATA, Phone.NUMBER },
				Data.MIMETYPE + "='" + Phone.CONTENT_ITEM_TYPE + "'" + " OR " + Data.MIMETYPE + "='" + Email.CONTENT_ITEM_TYPE
						+ "'", null, null);

		if (mCursor.getCount() > 0) {
			// Optimization vars
			final String emptyEmail = "";
			final Long emptyPhone = 0L;
			// final int indexId = mCursor.getColumnIndex(Contacts._ID);
			final int indexMimeType = mCursor.getColumnIndex(Data.MIMETYPE);
			final int indexPhoneNumber = mCursor.getColumnIndex(Phone.NUMBER);
			final int indexEmail = mCursor.getColumnIndex(Email.DATA);

			// Search in the cursor
			while (mCursor.moveToNext()) {
				// String id = mCursor.getString(indexId);
				String mimeType = mCursor.getString(indexMimeType);
				Long mobile = emptyPhone;
				String email = emptyEmail;

				if (mimeType.equals(Phone.CONTENT_ITEM_TYPE)) {
					mobile = GeneralMethods.parsePhoneNumber(mCursor.getString(indexPhoneNumber));
				} else {
					email = mCursor.getString(indexEmail);
				}

				// Log.i(TAG_LOG, "Contact: " + id + ", " + mimeType + ", " +
				// mobile + ", " + email);
				if (mobile > 0 || email.length() > 0) {
					PhoneContact temp = new PhoneContact();
					temp.setEmail(email);
					temp.setMobile(mobile);
					contacts.add(temp);
				}
			}
			mCursor.close();
		}

		Log.i(TAG_LOG, "Finish parsing cursor data");
		return contacts;
	}

	/*
	 * 
	 */
	public class AddFriendsListInitialDialog extends ActionDialog<List<RequestFriendUser>> {

		private Session session;

		public AddFriendsListInitialDialog(Activity context, Session session) {
			super(context);
			this.session = session;
		}

		@Override
		public List<RequestFriendUser> performAction() {
			String accessToken = session.getAccessToken();
			WSFacebookSynchronization.synchronize(getSherlockActivity(), accessToken);
			if (!WSFacebookSynchronization.isFailedConnection()) {

				// Facebook friends
				Log.i(TAG_LOG, "Access Token: " + session.getAccessToken());
				Request request = Request.newMyFriendsRequest(session, new OnLoadFacebookFriendManager());
				Bundle params = new Bundle();
				params.putString("fields", "id, name, username, picture");
				request.setParameters(params);
				request.executeAndWait();

				// List of facebook friends id's
				String[] tempArray = new String[facebookFriendsList.size()];
				for (int i = 0; i < facebookFriendsList.size(); i++) {
					tempArray[i] = facebookFriendsList.get(i).getId();
				}

				// Get Ora users
				List<RequestFriendUser> tempUsers = WSSuggestedUsersV2.getSuggestedFriends(getContext(), accessToken,
						new ArrayList<PhoneContact>()).getUsers();

				if (!MasterService.isFailedConnection()) {
					// Filter Facebook users
					for (RequestFriendUser tempUser : tempUsers) {
						String fbId = tempUser.getFbId();
						if(fbId != null) {
							for (FB_Friend friend : facebookFriendsList) {
								if (fbId.equals(friend.getId())) {
									facebookFriendsList.remove(friend);
									break;
								}
							}
						
						}
					}

					return tempUsers;
				}
			}

			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (WSFacebookSynchronization.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(WSFacebookSynchronization.getErrorMessage(), context);
			} else {
				facebookButtonLayout.setVisibility(View.GONE);
				friendsImageDoubleList = new ArrayList<List<ImageView>>();

				addFacebookFriends();
				addOraFriends(result);
			}
		}
	}

	/*
	 * 
	 */
	public class AddTwoKindFriendDialog extends ActionDialog<List<RequestFriendUser>> {

		private Session session;

		public AddTwoKindFriendDialog(Activity context, Session session) {
			super(context);
			this.session = session;
		}

		@Override
		public List<RequestFriendUser> performAction() {
			// Contact list
			List<PhoneContact> contacts = MyContactFriendsFragments.getContactList(getSherlockActivity().getContentResolver());

			// Facebook Friends
			String accessToken = session.getAccessToken();
			Log.i(TAG_LOG, "Access Token: " + accessToken);
			Log.i(TAG_LOG, "Begin request from facebook friends.");
			Request request = Request.newMyFriendsRequest(session, new OnLoadFacebookFriendManager());
			Bundle params = new Bundle();
			params.putString("fields", "id, name, username, picture");
			request.setParameters(params);
			request.executeAndWait();

			// List of facebook friends ids
			String[] facebookFriendList = new String[facebookFriendsList.size()];
			for (int i = 0; i < facebookFriendsList.size(); i++) {
				facebookFriendList[i] = facebookFriendsList.get(i).getId();
			}

			// Get Ora users
			List<RequestFriendUser> tempUsers = WSSuggestedUsersV2.getSuggestedFriends(getContext(), accessToken, contacts)
					.getUsers();

			if (!MasterService.isFailedConnection()) {
				// Filter Facebook users
				for (RequestFriendUser tempUser : tempUsers) {
					String fbId = tempUser.getFbId();
					if(fbId != null) {
						for (FB_Friend friend : facebookFriendsList) {
							if (fbId.equals(friend.getId())) {
								facebookFriendsList.remove(friend);
								break;
							}
						}
					
					}
				}

				return tempUsers;
			}

			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (!MasterService.isFailedConnection()) {
				facebookButtonLayout.setVisibility(View.GONE);
				friendsImageDoubleList = new ArrayList<List<ImageView>>();

				Log.i(TAG_LOG, "Begin render views");
				addFacebookFriends();
				addOraFriends(result);
				Log.i(TAG_LOG, "End render views");
			}
		}

	}

	/*
	 * 
	 */
	private class ConsultListContactDialog extends ActionDialog<List<RequestFriendUser>> {

		public ConsultListContactDialog(Activity context) {
			super(context);
		}

		@Override
		public List<RequestFriendUser> performAction() {
			// Load contact list
			List<PhoneContact> contacts = getContactList(getSherlockActivity().getContentResolver());

			// Retrieve info from Ora
			SugResponse response = WSSuggestedUsersV2.getSuggestedFriends(getContext(), "", contacts);

			if (!MasterService.isFailedConnection()) {

				// Return users
				List<RequestFriendUser> tempUsers = response.getUsers();
				return tempUsers;
			}

			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (!MasterService.isFailedConnection()) {
				Log.i(TAG_LOG, "Begin render views");
				addOraFriends(result);
				Log.i(TAG_LOG, "End render views");
			}
		}
	}

	/*
	 * 
	 */
	private class OnLoadFacebookFriendManager implements Request.GraphUserListCallback {

		@Override
		public void onCompleted(List<GraphUser> users, Response response) {
			Log.i(TAG_LOG, "End request from facebook friends.");

			Log.d(TAG_LOG, "Begin parse Friends");
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			try {
				String strList = response.getGraphObject().getInnerJSONObject().getJSONArray("data").toString();
				Log.i(TAG_LOG, strList);
				List<FB_Friend> fbUsers = mapper.readValue(strList, new TypeReference<List<FB_Friend>>() {
				});
				facebookFriendsList = fbUsers;
			} catch (JSONException e) {
				Log.e(TAG_LOG + " - JSONException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (JsonParseException e) {
				Log.e(TAG_LOG + " - JsonParseException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (JsonMappingException e) {
				Log.e(TAG_LOG + " - JsonMappingException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (IOException e) {
				Log.e(TAG_LOG + " - IOException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			}
			Log.d(TAG_LOG, "End parse Friends");
		}

	}

}
