package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.request.PhoneFacebookContacts;
import net.ora.mobile.dto.profile.response.SugResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;
import android.util.Log;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class WSSug extends MasterService {
	
	private final static String TAG_LOG = "WSSug";

	private static final String URL = "sug/";
	private static SugResponse response;
	
	public static SugResponse getResponse(){
		return response;
	}
	
	public static void searchSug(Context context, PhoneFacebookContacts objectRequest){
		try{
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			String jsonRepresentation = "";
			try {
				Log.i(TAG_LOG, "Begin to Json");
				jsonRepresentation = mapper.writeValueAsString(objectRequest);
				Log.i(TAG_LOG, "End to Json");
			} catch (JsonGenerationException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("data", jsonRepresentation));
			
			Log.i(TAG_LOG, "Begin request");
			response = makeRequest(context, CONNECTION_TYPE.POST, 
					URL , request, new TypeReference< SugResponse >() {});
			Log.i(TAG_LOG, "End request");
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
