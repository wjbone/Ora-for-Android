package net.ora.mobile.android.circles;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.city_state.SearchCountryActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCancelCircleRequest;
import net.ora.mobile.android.webservices.circles.WSJoinCircle;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CancelCircleRequestResponse;
import net.ora.mobile.dto.circles.response.CircleSearchResponse;
import net.ora.mobile.dto.circles.response.JoinCircleResponse;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.ScrollViewExt;
import com.digitalgeko.mobile.android.ui.ScrollViewListener;

public class SearchCircleFragment extends FragmentImageData implements ScrollViewListener, LoaderManager.LoaderCallbacks<CircleSearchResponse> {

	public static final int SELECT_PLACE = 3;
	
	private Handler mHandler;
	private boolean showLoading = true;
	
	private int nextPage = 1;
	
	private LinearLayout oraCirclesList;
	private EditText circleName;
	private Button circleCity;
	
	private View loadingView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getActivity().setTitle("Search Circles");
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}
	 
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.list_search_for_add_backup, container, false);
		
//		((ScrollViewExt) view.findViewById(R.id.sv_search_for_add)).setScrollViewListener(this);
		oraCirclesList = (LinearLayout) view.findViewById(R.id.ly_search_friend_list);
		
		circleCity = (Button) view.findViewById(R.id.b_search_friend_city);
		circleCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(getActivity(), SearchCountryActivity.class), SELECT_PLACE);
			}
		});
		
		mHandler = new Handler();
		
		circleName = (EditText) view.findViewById(R.id.et_search_friend_name);
		circleName.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) { }
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
			
			@Override
			public void afterTextChanged(Editable s) {
				mHandler.removeCallbacks(searchForName);
				mHandler.postDelayed(searchForName, 1000);
				if(showLoading){
					setLoading();
					showLoading = false;
				}
				if(s.toString().length() == 0){
					showLoading = true;
				}
			}
		});
	
		return view;
	}
	
	private Runnable searchForName = new Runnable() {
		@Override
		public void run() {
			if(circleName.getText().toString().trim().length() > 0){
				setLoading();
				nextPage = 1;
				getActivity().getSupportLoaderManager().restartLoader(0, null, SearchCircleFragment.this);
			}
		}
	};
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if((requestCode == SELECT_PLACE) && (resultCode == android.app.Activity.RESULT_OK)){
			String response = data.getStringExtra("city_state");
			circleCity.setText(data.getStringExtra("city_state"));
			if(response.length() > 0){
				setLoading();
				nextPage = 1;
				getActivity().getSupportLoaderManager().restartLoader(0, null, SearchCircleFragment.this);
			}
		}else{
			circleCity.setText("");
		}
	}
	
	private View setLoading(){
		oraCirclesList.removeAllViews();
		
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		loadingView = inflater.inflate(R.layout.item_city_loading, null);
		
		oraCirclesList.addView(loadingView);
		
		return loadingView;
	}

	@Override
	public Loader<CircleSearchResponse> onCreateLoader(int arg0, Bundle arg1) {
		SearchCirclesLoader loader = new SearchCirclesLoader(getActivity());
		
		loader.setPage(nextPage);
		loader.setQuery(circleName.getText().toString());
		loader.setCity(circleCity.getText().toString());
		
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<CircleSearchResponse> loader, CircleSearchResponse data) {
		if(data != null){
			addCircles(data);
		}
	}

	@Override
	public void onLoaderReset(Loader<CircleSearchResponse> arg0) { }

	@Override
	public void onScrollBottomReached(ScrollViewExt scrollView) {
		if((nextPage != -1) && (!getActivity().getSupportLoaderManager().hasRunningLoaders())){
			getActivity().getSupportLoaderManager().restartLoader(0, null, this);
		}
	}

	@Override
	public void onScrollTopReached(ScrollViewExt scrollView) { }
	
	private void addCircles(CircleSearchResponse data){
		oraCirclesList.removeView(loadingView);
		
		nextPage = data.getNextPage();
		
		// List of image views
		List<ImageView> pictureViews = new ArrayList<ImageView>();
		List<String> pictureUrls = new ArrayList<String>();
		
		//width of the picture
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
		
		// Load circles
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		for(int i = 0; i < data.getCircles().size(); i++){
			final Circle circle = data.getCircles().get(i);
			
			View viewCircle = inflater.inflate(R.layout.list_item_circle, null);
			viewCircle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					popFragment();
					pushFragment(ViewCircleFragment.getInstance(circle));
				}
			});

			TextView lblName = (TextView) viewCircle.findViewById(R.id.itemCircle_lblName);
			lblName.setText(circle.getName());

			TextView lblType = (TextView) viewCircle.findViewById(R.id.itemCircle_tvType);
			lblType.setText(circle.getSecurityLevelId());


			TextView lblCity = (TextView) viewCircle.findViewById(R.id.itemCircle_lblCity);
			lblCity.setText(circle.getCity());

			ImageView imgPicture = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivImage);
			imgPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			((ImageView) viewCircle.findViewById(R.id.itemCircle_ivCheck)).setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			if (circle.getPicture() != null && circle.getPicture().length() > 0) {
				pictureViews.add(imgPicture);
				pictureUrls.add(circle.getPicture());
			}

			oraCirclesList.addView(viewCircle);
			oraCirclesList.addView(inflater.inflate(R.layout.item_separator, null));
			
			// Set buttons
			setActionButtons(circle, viewCircle);
		}
		
		if(nextPage != -1) {
			oraCirclesList.addView(loadingView);
		}
	}
	
	private void setActionButtons(Circle circle, View viewCircle) {
		// Set up the image
		ImageView imgCheckGreen = (ImageView) viewCircle
				.findViewById(R.id.ib_item_accepted);
		ImageView imgPending = (ImageView) viewCircle
				.findViewById(R.id.ib_item_pending);
		ImageView imgAdd = (ImageView) viewCircle
				.findViewById(R.id.ib_item_add);
		
		if (circle.isOwner() || circle.isMember()) {
			// Is member
			imgCheckGreen.setVisibility(View.VISIBLE);
			imgPending.setVisibility(View.GONE);
			imgAdd.setVisibility(View.GONE);
		} else {
			if (circle.isRequested()) {
				// Pending
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.VISIBLE);
				imgAdd.setVisibility(View.GONE);

				// Set listener
				imgPending.setOnClickListener(
						new CancelCircleRequestManager(circle, viewCircle));
			} else {
				// Unknown
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.GONE);
				imgAdd.setVisibility(View.VISIBLE);

				// Set listener
				imgAdd.setOnClickListener(
						new JoinCircleManager(circle, viewCircle));
			}
		}
	}
	
	
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class JoinCircleManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public JoinCircleManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new JoinCircleActionDialog(getActivity()).init();
		}
		
		/**
		 */
		public class JoinCircleActionDialog extends
			ActionDialog<JoinCircleResponse> {
	
			public JoinCircleActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public JoinCircleResponse performAction() {
				int circleId = circle.getId();
				return WSJoinCircle.joinCircle(context, circleId);
			}
		
			@Override
			public void afterAction(JoinCircleResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
					return;
				}
		
				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();

				// Configure circle
				circle.setMember(response.isMember());
				circle.setRequested(response.isRequested());
				
				// Set circle view
				setActionButtons(circle, viewCircle);
				
				// Show message
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class CancelCircleRequestManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public CancelCircleRequestManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new CancelCircleRequestActionDialog(getActivity()).init();
		}
		
		public class CancelCircleRequestActionDialog extends
				ActionDialog<CancelCircleRequestResponse> {
		
			public CancelCircleRequestActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public CancelCircleRequestResponse performAction() {
				int circleId = circle.getId();
				return WSCancelCircleRequest.cancelCircleRequest(context, circleId);
			}
		
			@Override
			public void afterAction(CancelCircleRequestResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
				} else {
					// Mark circle list for reload
					OraConfiguration configuration = new OraConfiguration(getContext());
					configuration.setFirstTimeLoadingCircles(true);
					configuration.close();
					
					// Configure circle
					circle.setMember(response.isMember());
					circle.setRequested(response.isRequested());
					
					// Set circle view
					setActionButtons(circle, viewCircle);
					
					// Show message
					Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
							.show();
				}
			}
		
		}
	}

}
