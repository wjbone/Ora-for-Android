package net.ora.mobile.android.help;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.widget.ImageView;

public class PromotionGestureDetector extends SimpleOnGestureListener {

	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 30;
	
	private ImageView mImageView;
	private List<Drawable> mImagesList;
	private int mPhoto;
	
	public PromotionGestureDetector(ImageView imageView, List<Drawable> imageList){
		mImageView = imageView;
		mImagesList = imageList;
		mPhoto = 0;
		setFirstImage();
//		imageView.setImageDrawable(mImagesList.get(mPhoto));
	}
	
	public void changeImageList(List<Drawable> imageList){
		mImagesList = imageList;
		mPhoto = 0;
		setFirstImage();
//		mImageView.setImageDrawable(mImagesList.get(mPhoto));
	}
	
	private void setFirstImage(){
		if(mPhoto < mImagesList.size())
			mImageView.setImageDrawable(mImagesList.get(mPhoto));
	}
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY){
		try {
            if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                return false;
            if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                mPhoto = (mPhoto + 1) % mImagesList.size();
                mImageView.setImageDrawable(mImagesList.get(mPhoto));
            } else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                mPhoto = (mPhoto - 1) % mImagesList.size();
                if (mPhoto < 0) {
                    mPhoto = 0;
                }
                mImageView.setImageDrawable(mImagesList.get(mPhoto));
            }
        } catch (Exception e) {
            Log.e("SwypeImagesActivity", "error on gesture detector");
        }
        return false;
	}

}
