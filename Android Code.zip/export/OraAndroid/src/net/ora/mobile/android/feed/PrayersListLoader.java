package net.ora.mobile.android.feed;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.feed.WSPrayerList;
import net.ora.mobile.android.webservices.feed.WSPrayersFeed;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;

public class PrayersListLoader extends FeedAsyncTaskLoader {

	private int page;
	private String lastDateAdded;

	public PrayersListLoader(Activity activity, FeedLoaderCallbacks<PrayersFeedResponse> callbacks) {
		super(activity, callbacks);
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getLastDateAdded() {
		return lastDateAdded;
	}

	public void setLastDateAdded(String lastDateAdded) {
		this.lastDateAdded = lastDateAdded;
	}

	@Override
	public PrayersFeedResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			Log.i("Loader", "No more data");
			return PrayersFeedResponse.EMPTY_RESPONSE;
		}

		Context context = getContext();
		PrayersFeedResponse response = WSPrayerList.getPrayersList(context, lastDateAdded, page);

		if (MasterService.isFailedConnection()) {
			showErrorMessage(MasterService.getErrorMessage());
			return null;
		}
		this.page = response.getNextPage();

		Log.i("Loader", "finish");

		return response;
	}

}
