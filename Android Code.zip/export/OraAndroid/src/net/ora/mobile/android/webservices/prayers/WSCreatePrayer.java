package net.ora.mobile.android.webservices.prayers;

import java.util.List;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.CreatePrayerResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCreatePrayer extends MasterService {

	private static final String URL = "create_prayer/";

	public static Prayer createPrayer(Context context, List<Circle> circles, String text) {

		try {
			// Validate
			validateRequired(context, text, R.string.WSCreatePrayer_errorText);
			
			String strCircles = "";
			for(Circle circle : circles) {
				strCircles += circle.getId() + ",";
			}
			if(strCircles.length() > 0) {
				strCircles = strCircles.substring(0, strCircles.length() - 1);
			}
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("circles", strCircles));
			request.add(new BasicNameValuePair("text", text));

			// Make request
			CreatePrayerResponse response = makeRequest(context,
					CONNECTION_TYPE.POST, URL, request,
					new TypeReference<CreatePrayerResponse>() {});

			return response.getPrayer();
			
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.WSCreatePrayer_error);
		}

		return null;
	}
}
