package net.ora.mobile.android.friends;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraSherlockFragmentActivity;
import net.ora.mobile.dto.prayers.Prayer;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.MenuItem;

public class PrayerDetailActivity extends OraSherlockFragmentActivity {
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		ActionBar _actionBar = getSupportActionBar();

		_actionBar.setDisplayHomeAsUpEnabled(true);
		_actionBar.setDisplayShowTitleEnabled(false);
		_actionBar.setDisplayShowCustomEnabled(true);

		// Save action bar title view
		_actionBar.setCustomView(R.layout.custom_action_layout);
		View customView = _actionBar.getCustomView();

		Prayer prayer = (Prayer) ((OraApplication) getApplication()).getParam("prayer_friends");
		
		String name = prayer.getUser().getRealName();
		int index = name.indexOf(" ");
		((TextView) customView.findViewById(R.id.action_custom_title)).setText(name.substring(0, ((index != -1 ? index : name.length()))) + "'s Prayer");

		setContentView(R.layout.friend_prayer_detail);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;
		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}

	public void onPrayerDetailAddCommentClick(View view) { }

}
