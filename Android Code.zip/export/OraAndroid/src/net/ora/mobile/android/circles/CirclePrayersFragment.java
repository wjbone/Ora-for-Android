package net.ora.mobile.android.circles;

import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.prayers.PrayedUsersForPrayerFragment;
import net.ora.mobile.android.prayers.PrayerCirclesFragment;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.ui.OraLoaderCallbacks;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CirclePrayersResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.Loader;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ScrollViewExt;
import com.digitalgeko.mobile.android.ui.ScrollViewListener;

public class CirclePrayersFragment extends CachedImageDataFragment implements ScrollViewListener,
		OraLoaderCallbacks<CirclePrayersResponse> {

	public static final int LOADER_ID_CIRCLE_PRAYERS = 10;

	private Circle circle;
	private int page = 1;

	private View view;
	private ViewGroup viewCirclePrayers;
	private View viewProgressBar;

	public static CirclePrayersFragment getInstance(Circle circle) {
		CirclePrayersFragment fragment = new CirclePrayersFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments().getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}
	}

	@Override
	protected int getActionBarString() {
		return R.string.circlePrayers_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Save
		if (circle == null) {
			return null;
		}
		page = 1;

		// Inflate view
		view = inflater.inflate(R.layout.fragment_circles_circle_prayers, container, false);

		// Progress bar
		viewProgressBar = inflater.inflate(R.layout.item_loading, null);

		// Scroll set up
		((ScrollViewExt) view.findViewById(R.id.circlePrayers_svPrayers)).setScrollViewListener(this);

		// Prayers list view group
		viewCirclePrayers = (ViewGroup) view.findViewById(R.id.circlePrayers_lstPrayers);

		getActivity().getSupportLoaderManager().initLoader(LOADER_ID_CIRCLE_PRAYERS, null, this);

		// Return
		return view;
	}

	@Override
	public void onStop() {
		super.onStop();
		getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID_CIRCLE_PRAYERS);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	@SuppressWarnings("unchecked")
	public void onLoadComplete(List<Prayer> data) {

		Log.i("onLoadComplete", "init");

		// Progress bar
		hideProgressBar();

		if (data == null) {
			return;
		}

		// Inflate views
		LayoutInflater inflater = LayoutInflater.from(getActivity());

		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
		Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[data.size()];
		int i = 0;

		for (final Prayer prayer : data) {

			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);

			// Set listeners
			TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
			descriptionView.setOnClickListener(new GoPrayerDetailManager(prayer, false));
			if (prayer.isLikeAvailable()) {
				View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
				ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
				btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer, containerView));
			} else {
				View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
				btnPray.setVisibility(View.GONE);
			}
			viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments)
					.setOnClickListener(new GoPrayerDetailManager(prayer, true));
			if (prayer.getUser().equals(((OraApplication) getActivity().getApplication()).getUser())) {
				// Can see prays list only in is the owner of the pray
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(new GoPrayerPraysManager(prayer));
			}
			OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);

			// Set info
			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
			// Prayer User View
			TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
			prayerUserTextView.setText(prayer.getUser().getName());
			prayerUserTextView.setOnClickListener(goToProfileListener);

			// Go to user profile
			ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
			friendPicture.setOnClickListener(goToProfileListener);

			// Set circle
			ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

			friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			pictureImageViewList.add(friendPicture);
			circleImageViewList.add(circlePicture);

			// Save user/image view info
			usersImagesViewsPairs[i++] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);

			// Circles
			int circlesCount = prayer.getCircles().size();
			String strCircles = "";
			if (circlesCount == 0) {
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
			} else {
				// Set listener
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(new GoPrayerCirclesManager(prayer));

				for (Circle circle : prayer.getCircles())
					strCircles += circle.getName() + ", ";
				strCircles = strCircles.substring(0, strCircles.length() - 2);
				// Set circles string
				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);
			}

			// Set prayer likes count
			TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
			likesCount.setText(Integer.toString(prayer.getLikesCount()));

			// Set prayer comments count
			TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
			commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
			// Set prayer time
			TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
			timeCount.setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));

			// ViewGroup viewPrayer = (ViewGroup)inflater.inflate(R.layout.item_feed_prayer,
			// null);
			//
			// // Set listeners
			// viewPrayer.setOnClickListener(new GoPrayerDetailManager(prayer));
			// if (prayer.isLikeAvailable()) {
			// viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer,
			// viewPrayer));
			// } else {
			// View imgGrabber = viewPrayer
			// .findViewById(R.id.feedPrayer_imGrabber);
			// imgGrabber.setVisibility(View.GONE);
			// }
			//
			// // Set info
			// ((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer))
			// .setText(prayer.getText());
			//
			// ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer))
			// .setText(prayer.getUser().getName());
			//
			// // Go to user profile
			// ImageView friendPicture = (ImageView) viewPrayer
			// .findViewById(R.id.iv_profile_image_prayer);
			// friendPicture.setOnClickListener(new View.OnClickListener() {
			// @Override
			// public void onClick(View v) {
			// getActivity().startActivity(
			// new Intent(getActivity(),
			// ProfileFriendActivity.class).putExtra(
			// "friend_id", prayer.getUser().getId()));
			// }
			// });
			//
			// // Save user/image view info
			// usersImagesViewsPairs[i++] = new Pair<User, ImageView>(
			// prayer.getUser(), friendPicture);
			//
			// // Circles
			// int circlesCount = prayer.getCircles().size();
			// String firstCircle = "";
			// if (circlesCount >= 1)
			// firstCircle = prayer.getCircles().get(0).getName();
			// String strCircles = getResources().getQuantityString(
			// R.plurals.viewCircle_lblItemPrayer_circles, circlesCount,
			// firstCircle, circlesCount - 1);
			// // Set circles string
			// ((TextView) viewPrayer
			// .findViewById(R.id.tv_profile_circles_prayer))
			// .setText(strCircles);
			//
			// // Set prayer likes count
			// ((TextView) viewPrayer
			// .findViewById(R.id.tv_profile_prayers_prayer))
			// .setText(Integer.toString(prayer.getLikesCount()));
			//
			// // Set prayer comments count
			// ((TextView) viewPrayer
			// .findViewById(R.id.tv_profile_comments_prayer))
			// .setText(Integer.toString(prayer.getCommentsCount()));
			//
			// // Set prayer time
			// ((TextView) viewPrayer.findViewById(R.id.tv_pray_time))
			// .setText(GeneralMethods.fromDate(GeneralMethods
			// .parseStringToDate(prayer.getDateCreated())));

			// Add view
			viewCirclePrayers.addView(viewPrayer);
			viewCirclePrayers.invalidate();
		}

		// Start loading pictures
		AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayersFeedFragmets", getActivity(), this);
		asyncTaskList.add(async);
		async.execute(usersImagesViewsPairs);

		Log.i("onLoadComplete", "finish");
	}

	@Override
	public void onScrollTopReached(ScrollViewExt scrollView) {
	}

	@Override
	public void onScrollBottomReached(ScrollViewExt scrollView) {
		// Load next page of the circle's prayers
		if (!getActivity().getSupportLoaderManager().hasRunningLoaders())
			getActivity().getSupportLoaderManager().restartLoader(LOADER_ID_CIRCLE_PRAYERS, null, this);
	}

	@Override
	public Loader<CirclePrayersResponse> onCreateLoader(int id, Bundle args) {
		// Progress bar
		showProgressBar();

		CirclePrayersLoader loader = new CirclePrayersLoader(getActivity(), this);
		loader.setCircleId(circle.getId());
		loader.setPage(page);
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<CirclePrayersResponse> loader, CirclePrayersResponse data) {
		// Progress bar
		hideProgressBar();

		page = data.getNextPage();
		onLoadComplete(data.getPrayers());
	}

	@Override
	public void onLoaderReset(Loader<CirclePrayersResponse> loader) {

	}

	@Override
	public void onAbandon(Loader<CirclePrayersResponse> loader) {
		hideProgressBar();
	}

	private void showProgressBar() {
		if (page == 1) {
			if (view != null) {
				view.findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
			}
		} else {
			viewCirclePrayers.addView(viewProgressBar);
		}
	}

	private void hideProgressBar() {
		if (page == 1) {
			if (view != null) {
				view.findViewById(R.id.pbLoading).setVisibility(View.GONE);
			}
		} else {
			viewCirclePrayers.removeView(viewProgressBar);
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, boolean showOnlyComments) {
			this.prayer = prayer;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			pushFragment(PrayerDetailFragment.getInstance(prayer, showOnlyComments));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			getActivity().startActivity(
					new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerPraysManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerCirclesManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
				pushFragment(ViewCircleFragment.getInstance(circle));
			} else {
				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}
}
