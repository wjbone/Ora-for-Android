package net.ora.mobile.android.feed;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.ViewCircleFragment;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.prayers.PrayedUsersForPrayerFragment;
import net.ora.mobile.android.prayers.PrayerCirclesFragment;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.ui.DBAccessFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCirclePrayers;
import net.ora.mobile.android.webservices.feed.WSFaithfulFeed;
import net.ora.mobile.android.webservices.feed.WSPrayerList;
import net.ora.mobile.android.webservices.feed.WSPrayersFeed;
import net.ora.mobile.android.webservices.prayers.WSRatePrayer;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.feed.Inspiration;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.RatePrayerResponse;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.OraPullToRefreshScrollView;
import com.digitalgeko.mobile.android.ui.ScrollViewExt;
import com.digitalgeko.mobile.android.ui.ScrollViewListener;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;

public class PrayersFeedFragment extends DBAccessFragment implements ScrollViewListener,
		FeedLoaderCallbacks<PrayersFeedResponse>, OnCheckedChangeListener {

	public static final int LOADER_ID_PRAYERS_FEED = 20;
	public static final int LOADER_ID_MY_LIST = 21;
	public static final int LOADER_ID_FAITHFUL = 22;
	public static final int LOADER_ID_PRAYERS_FEED_SEARCH = 23;
	public static final int LOADER_ID_FAITHFUL_SEARCH = 24;

	public static final String TAG_TYPE = "type";
	public static final int TYPE_FEED = 0;
	public static final int TYPE_MY_LIST = 1;
	public static final int TYPE_FAITHFUL = 2;
	public static final int TYPE_FEED_SEARCH = 3;
	public static final int TYPE_FAITHFUL_SEARCH = 4;

	private int loaderType = TYPE_FEED;
	private int loaderId = LOADER_ID_PRAYERS_FEED;
	private int page = 1;
	private int prayersFeedTime = WSPrayersFeed.TIME_ALL_TIME_PRAYRS;
	private int prayersFeedPrayerId = WSCirclePrayers.PRAYER_ID_ALL_PRAYERS;
	private String myListLastDateAdded = WSPrayerList.LAST_DATE_ADDED_ALL;
	private int faithfulRating = WSFaithfulFeed.RATING_ALL_NON_FAVORITE_ANSWERED_AND_FAVORITES_OWN_PRAYERS;
	private int faithfulFilter = WSFaithfulFeed.FILTER_ALL_ANSWERED_OWN_PRAYERS_AND_ANSWERED_PRAYERS_I_HAVE_LIKED_FOR;
	private int faithfulPrayerId = WSFaithfulFeed.PRAYER_ID_ALL_PRAYERS;

	private View view;
	private RadioGroup viewRgFeedOptions;
	private ViewGroup viewFaithfulContainerRgOptions;
	private RadioGroup viewFaithfulRgOptions;
	private ViewGroup viewPrayersFeed;
	private View viewProgressBar;

	// Search
	private EditText viewSearchBox;
	private boolean showSearchBox;

	public static PrayersFeedFragment getInstance(int type) {
		PrayersFeedFragment fragment = new PrayersFeedFragment();

		Bundle args = new Bundle();
		args.putInt(TAG_TYPE, type);
		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			loaderType = getArguments().getInt(TAG_TYPE);
		}
	}

	private OraPullToRefreshScrollView scrollView;
	private boolean isRefreshing;

	private boolean isRefreshing() {
		return isRefreshing;
	}

	private void setRefreshing(boolean isRefreshing) {
		this.isRefreshing = isRefreshing;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Load again pages
		page = 1;

		// Inflate view
		view = inflater.inflate(R.layout.fragment_feed_prayers, container, false);

		// Progress bar
		viewProgressBar = inflater.inflate(R.layout.item_loading, null);

		// Scroll set up
		scrollView = ((OraPullToRefreshScrollView) view.findViewById(R.id.feedPrayers_svPrayers));
		scrollView.setScrollViewListener(this);
		scrollView.setOnRefreshListener(new OnRefreshListener<ScrollView>() {
			@Override
			public void onRefresh(PullToRefreshBase<ScrollView> refreshView) {
				if (!getActivity().getSupportLoaderManager().hasRunningLoaders()) {
					setRefreshing(true);
					buildFeed();
				} else {
					scrollView.onRefreshComplete();
				}
			}
		});

		// Faithful Options View
		viewRgFeedOptions = (RadioGroup) view.findViewById(R.id.feed_rgFeedOptions);
		viewRgFeedOptions.setOnCheckedChangeListener(this);
		// Faithful Options View
		viewFaithfulContainerRgOptions = (ViewGroup) view.findViewById(R.id.feed_faithful_containerRgOptions);
		viewFaithfulRgOptions = (RadioGroup) view.findViewById(R.id.feed_faithful_rgOptions);
		viewFaithfulRgOptions.setOnCheckedChangeListener(this);
		// Searchbox
		viewSearchBox = (EditText) view.findViewById(R.id.et_search);
		viewSearchBox.addTextChangedListener(new SearchFeedManager(viewSearchBox));
		// Prayers list view group
		viewPrayersFeed = (ViewGroup) view.findViewById(R.id.feedPrayers_lstPrayers);

		// Select current loader type
		switch (loaderType) {
		case TYPE_FEED:
			viewRgFeedOptions.check(R.id.feed_rbtnPrayers);
			break;
		case TYPE_MY_LIST:
			viewRgFeedOptions.check(R.id.feed_rbtnMyList);
			break;

		case TYPE_FAITHFUL:
			viewRgFeedOptions.check(R.id.feed_rbtnFaithful);
			break;
		}

		// Return
		return view;
	}

	@Override
	protected boolean isShowKeyboard() {
		return false;
	}

	@Override
	public void onStop() {
		super.onStop();
		getActivity().getSupportLoaderManager().destroyLoader(loaderId);
	}
	
	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		if (group.getId() == viewRgFeedOptions.getId()) {
			// Feed option change
			switch (checkedId) {
			case R.id.feed_rbtnPrayers:
				loaderType = TYPE_FEED;
				break;
			case R.id.feed_rbtnMyList:
				loaderType = TYPE_MY_LIST;
				break;
			case R.id.feed_rbtnFaithful:
				loaderType = TYPE_FAITHFUL;
				break;
			}
		} else {
			// Faithful options changed
			switch (checkedId) {
			case R.id.feed_faithful_rbtnAll:
				faithfulFilter = WSFaithfulFeed.FILTER_ALL_ANSWERED_OWN_PRAYERS_AND_ANSWERED_PRAYERS_I_HAVE_LIKED_FOR;
				break;
			case R.id.feed_faithful_rbtnMine:
				faithfulFilter = WSFaithfulFeed.FILTER_ALL_ANSWERED_OWN_PRAYERS;
				break;
			case R.id.feed_faithful_rbtnFavorites:
				faithfulFilter = WSFaithfulFeed.FILTER_ALL_FAVORITE_PRAYERS;
				break;
			}

		}
		// Start loading
		buildFeed();
	}

	@Override
	public Loader<PrayersFeedResponse> onCreateLoader(int id, Bundle args) {
		// Progress bar
		showProgressBar();

		// Set reload
		int page = this.page;
		if (isRefreshing()) {
			page = 1;
		}

		switch (id) {
		case LOADER_ID_MY_LIST: {
			PrayersListLoader loader = new PrayersListLoader(getActivity(), this);
			loader.setPage(page);
			loader.setLastDateAdded(myListLastDateAdded);
			return loader;
		}
		case LOADER_ID_FAITHFUL: {
			FaithfulFeedLoader loader = new FaithfulFeedLoader(getActivity(), this);
			loader.setPage(page);
			loader.setPrayerId(faithfulPrayerId);
			loader.setRating(faithfulRating);
			loader.setFilter(faithfulFilter);
			return loader;

		}
		case LOADER_ID_FAITHFUL_SEARCH: {
			FaithfulFeedSearchLoader loader = new FaithfulFeedSearchLoader(getActivity(), this);
			loader.setPage(page);
			loader.setQuery(viewSearchBox.getText().toString());

			return loader;
		}
		case LOADER_ID_PRAYERS_FEED_SEARCH: {
			PrayersFeedSearchLoader loader = new PrayersFeedSearchLoader(getActivity(), this);
			loader.setPage(page);
			loader.setQuery(viewSearchBox.getText().toString());

			return loader;
		}
		case LOADER_ID_PRAYERS_FEED:
		default: {
			PrayersFeedLoader loader = new PrayersFeedLoader(getActivity(), this, getHelper());
			loader.setPage(page);
			loader.setPrayerId(prayersFeedPrayerId);
			loader.setTime(prayersFeedTime);

			// Look for reload
			OraConfiguration configuration = new OraConfiguration(getActivity());
			loader.setReload(isRefreshing() || configuration.isFirstTimeLoadingFeed());
			configuration.close();

			return loader;
		}
		}
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private static void executeTask(LoadInspirationAsyncTask task, Inspiration inspiration) {
		if(Build.VERSION.SDK_INT > 11) {
			task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, inspiration);
		} else {
			task.execute(inspiration);
		}
	}

	@SuppressLint("NewApi")
	@Override
	public void onLoadFinished(Loader<PrayersFeedResponse> loader, PrayersFeedResponse response) {

		Log.i("onLoadComplete", "init");

		// Visual configuration
		hideProgressBar();
		if (isRefreshing()) {
			scrollView.onRefreshComplete();
			setRefreshing(false);
			viewPrayersFeed.removeAllViews();
		}

		if (response == null) {
			return;
		}

		// Save next page
		page = response.getNextPage();

		// Save
		if (loader.getId() == LOADER_ID_PRAYERS_FEED) {
			OraConfiguration configuration = new OraConfiguration(getActivity());
			configuration.setFirstTimeLoadingFeed(false);
			configuration.close();
		}

		// Load Daily Inspiration Image
		if (response.getInspiration() != null && response.getInspiration().getImage() != null) {
			LoadInspirationAsyncTask task = new LoadInspirationAsyncTask();
			getAsyncTaskList().add(task);
			if(Build.VERSION.SDK_INT > 11) {
				task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, response.getInspiration());
			} else {
				task.execute(response.getInspiration());
			}
			
			Log.i("Inspiration", "Loading: " + response.getInspiration().getImage());
		}

		// Set vars
		int width = GeneralMethods.getProfileImageWidth(getActivity());

		// Inflate views
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[response.getPrayers().size()];
		int i = 0;
		for (final Prayer prayer : response.getPrayers()) {

			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);

			// Set listeners
			TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
			descriptionView.setOnClickListener(new GoPrayerDetailManager(prayer, false));
			if (prayer.isLikeAvailable()) {
				View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
				ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
				btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer, containerView));
			} else {
				View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
				btnPray.setVisibility(View.GONE);
			}
			viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments)
					.setOnClickListener(new GoPrayerDetailManager(prayer, true));
			if (prayer.getUser().equals(((OraApplication) getActivity().getApplication()).getUser())) {
				// Can see prays list only in is the owner of the pray
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(new GoPrayerPraysManager(prayer));
			}
			OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);
			if (loader.getId() == LOADER_ID_FAITHFUL) {
				ImageView viewFavorite = (ImageView) viewPrayer.findViewById(R.id.prayer_ivFavorite);
				viewFavorite.setVisibility(View.VISIBLE);
				viewFavorite.setOnClickListener(new PrayerAndFavoritesManager(prayer, viewFavorite));

				if (prayer.isFavorite()) {
					viewFavorite.setImageResource(R.drawable.banner_favorite_active);
				}
			}
			setRefreshing(false);

			// Set info
			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
			// Prayer User View
			TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
			prayerUserTextView.setText(prayer.getUser().getName());
			prayerUserTextView.setOnClickListener(goToProfileListener);

			// Go to user profile
			ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
			friendPicture.setOnClickListener(goToProfileListener);

			// Set circle
			ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

			friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			pictureImageViewList.add(friendPicture);
			circleImageViewList.add(circlePicture);

			// Save user/image view info
			usersImagesViewsPairs[i++] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);

			// Circles
			int circlesCount = prayer.getCircles().size();
			String strCircles = "";
			if (circlesCount == 0) {
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
			} else {
				// Set listener
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(new GoPrayerCirclesManager(prayer));

				for (Circle circle : prayer.getCircles())
					strCircles += circle.getName() + ", ";
				strCircles = strCircles.substring(0, strCircles.length() - 2);
				// Set circles string
				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);
			}

			// Set prayer likes count
			TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
			likesCount.setText(Integer.toString(prayer.getLikesCount()));

			// Set prayer comments count
			TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
			commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
			// Set prayer time
			TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
			timeCount.setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));

			// Add view
			viewPrayersFeed.addView(viewPrayer);
			viewPrayersFeed.invalidate();
		}

		AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayersFeedFragmets", getActivity(), this);
		asyncTaskList.add(async);
		async.execute(usersImagesViewsPairs);

		Log.i("onLoadComplete", "finish");
	}

	@Override
	public void onAbandon(Loader<PrayersFeedResponse> loader) {
		hideProgressBar();
	}

	@Override
	public void onLoaderReset(Loader<PrayersFeedResponse> loader) {
	}

	private void showProgressBar() {
		if (page == 1 && !isRefreshing()) {
			view.findViewById(R.id.feedPrayers_pbLoading).setVisibility(View.VISIBLE);
		} else if (page > 1) {
			viewPrayersFeed.addView(viewProgressBar);
		}
	}

	private void hideProgressBar() {
		if (page == 1) {
			if (getView() != null)
				getView().findViewById(R.id.feedPrayers_pbLoading).setVisibility(View.GONE);
		} else {
			viewPrayersFeed.removeView(viewProgressBar);
		}
	}

	@Override
	public void onScrollBottomReached(ScrollViewExt scrollView) {
		if (!getActivity().getSupportLoaderManager().hasRunningLoaders())
			getActivity().getSupportLoaderManager().restartLoader(loaderId, null, this);
	}

	@Override
	public void onScrollTopReached(ScrollViewExt scrollView) {
		setSearchBox(false);
	}

	private void setSearchBox(boolean change) {
		if (change) {
			if (loaderType != TYPE_FEED_SEARCH && loaderType != TYPE_FAITHFUL_SEARCH) {
				view.findViewById(R.id.feedPrayers_lySearch).setVisibility(View.GONE);
				showSearchBox = false;
			}
		} else if (!showSearchBox || (loaderId == LOADER_ID_PRAYERS_FEED || loaderId == LOADER_ID_FAITHFUL)) {
			view.findViewById(R.id.feedPrayers_lySearch).setVisibility(View.VISIBLE);
			showSearchBox = true;
		}
	}

	private void buildFeed() {
		// Stop current loader (if any)
		if (getActivity().getSupportLoaderManager().hasRunningLoaders())
			getActivity().getSupportLoaderManager().destroyLoader(loaderId);

		page = 1;
		if (!isRefreshing()) {
			viewPrayersFeed.removeAllViews();
			view.findViewById(R.id.feed_prayers_lyInspiration).setVisibility(View.GONE);
		}
		// Search configuration
		setSearchBox(true);

		switch (loaderType) {
		case TYPE_FEED:
			viewFaithfulContainerRgOptions.setVisibility(View.GONE);
			loaderId = LOADER_ID_PRAYERS_FEED;
			viewSearchBox.setText("");
			break;
		case TYPE_FEED_SEARCH:
			viewFaithfulContainerRgOptions.setVisibility(View.GONE);
			loaderId = LOADER_ID_PRAYERS_FEED_SEARCH;
			break;
		case TYPE_MY_LIST:
			viewFaithfulContainerRgOptions.setVisibility(View.GONE);
			loaderId = LOADER_ID_MY_LIST;
			viewSearchBox.setText("");
			break;
		case TYPE_FAITHFUL:
			viewFaithfulContainerRgOptions.setVisibility(View.VISIBLE);
			loaderId = LOADER_ID_FAITHFUL;
			viewSearchBox.setText("");
			break;
		case TYPE_FAITHFUL_SEARCH:
			viewFaithfulContainerRgOptions.setVisibility(View.VISIBLE);
			loaderId = LOADER_ID_FAITHFUL_SEARCH;
			break;
		}

		// Activate loader
		getActivity().getSupportLoaderManager().restartLoader(loaderId, null, this);
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, boolean showOnlyComments) {
			this.prayer = prayer;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			pushFragment(PrayerDetailFragment.getInstance(prayer, showOnlyComments));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			getActivity().startActivity(
					new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerPraysManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerCirclesManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
				pushFragment(ViewCircleFragment.getInstance(circle));
			} else {
				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class PrayerAndFavoritesManager implements OnClickListener {

		private Prayer prayer;
		private ImageView ivFavorite;

		public PrayerAndFavoritesManager(Prayer prayer, ImageView ivFavorite) {
			this.prayer = prayer;
			this.ivFavorite = ivFavorite;
		}

		@Override
		public void onClick(View v) {
			new RatePrayerActionDialog(getActivity()).init();
		}

		public class RatePrayerActionDialog extends ActionDialog<RatePrayerResponse> {

			public RatePrayerActionDialog(Activity context) {
				super(context);
			}

			@Override
			public RatePrayerResponse performAction() {
				return WSRatePrayer.ratePrayer(context, prayer);
			}

			@Override
			public void afterAction(RatePrayerResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
					return;
				}

				// Save data
				prayer.setRating(response.getRating());

				// Change icon
				String message = response.getMessage();
				if (prayer.isFavorite()) {
					ivFavorite.setImageResource(R.drawable.banner_favorite_active);
					message = context.getString(R.string.prayer_msgAddToFavorites);
				} else {
					ivFavorite.setImageResource(R.drawable.banner_favorite);
					message = context.getString(R.string.prayer_msgRemovedFromFavorites);
				}

				// Show message
				Toast.makeText(context, message, Toast.LENGTH_SHORT).show();

			}
		}
	}

	/*
	 * 
	 */
	public class SearchFeedManager implements TextWatcher {

		private Handler mHandler;
		private EditText etSearch;

		public SearchFeedManager(EditText text) {
			this.etSearch = text;
			mHandler = new Handler();
		}

		private Runnable searchRunnable = new Runnable() {
			@Override
			public void run() {
				mHandler.removeCallbacks(searchRunnable);
				if (etSearch.getText().toString().trim().length() > 0) {
					if (loaderType == TYPE_FEED) {
						loaderType = TYPE_FEED_SEARCH;
					} else if (loaderType == TYPE_FAITHFUL) {
						loaderType = TYPE_FAITHFUL_SEARCH;
					}
				} else {
					if (loaderType == TYPE_FEED_SEARCH) {
						loaderType = TYPE_FEED;
					} else if (loaderType == TYPE_FAITHFUL_SEARCH) {
						loaderType = TYPE_FAITHFUL;
					}
				}
				buildFeed();
			}
		};

		@Override
		public void afterTextChanged(Editable s) {
			mHandler.removeCallbacks(searchRunnable);
			if (s.length() > 0) {
				mHandler.postDelayed(searchRunnable, 1000);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class LoadInspirationAsyncTask extends AsyncTask<Inspiration, Void, InspirationHolder> {

		@Override
		protected InspirationHolder doInBackground(Inspiration... params) {
			String imageUrl = params[0].getImage();

			try {
				Bitmap base = ImageManager.downloadCachedImage(getActivity(), imageUrl, 0L).getBitmap();

				InspirationHolder holder = new InspirationHolder();
				holder.bitmap = base;
				holder.inspiration = params[0];
				return holder;
			} catch (Exception e) {
				cancel(true);
			}
			return null;
		}

		@Override
		protected void onPostExecute(InspirationHolder result) {
			super.onPostExecute(result);

			switch (loaderType) {
			case TYPE_FEED:
				View view = getView();
				if (view != null) {
					View layoutInspiration = view.findViewById(R.id.feed_prayers_lyInspiration);
					layoutInspiration.setVisibility(View.VISIBLE);
					layoutInspiration.setOnClickListener(onInspirationClickListener);
					ImageView inspirationView = (ImageView) view.findViewById(R.id.iv_prayers_inspiration);
					inspirationView.setTag(result.inspiration);
					inspirationView.setImageBitmap(result.bitmap);
				}
			}
		}
	}

	public static class InspirationHolder {
		public Bitmap bitmap;
		public Inspiration inspiration;
	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	protected OnClickListener onInspirationClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (getFragmentManager().findFragmentByTag(InspirationDialogFragment.TAG) == null) {
				ImageView iv = (ImageView) v.findViewById(R.id.iv_prayers_inspiration);
				Bitmap inspirationImage = ((BitmapDrawable) iv.getDrawable()).getBitmap();
				InspirationDialogFragment dialog = new InspirationDialogFragment();
				dialog.setInspirationImage(inspirationImage);
				dialog.setInspiration((Inspiration) iv.getTag());
				dialog.show(getFragmentManager(), InspirationDialogFragment.TAG);
			}
		}
	};
}
