package net.ora.mobile.android.webservices.profile;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.ServiceResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSFacebookSynchronization extends MasterService {
	
	private static String URL = "fb_sync/";
	
	public static void synchronize(Activity context, String access_token){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("access_token", access_token));
			
			makeRequest(context, CONNECTION_TYPE.POST, URL, request, new TypeReference< ServiceResponse >() {});
		} catch (Exception e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}

}
