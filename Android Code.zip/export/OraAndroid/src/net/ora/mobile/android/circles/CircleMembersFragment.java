package net.ora.mobile.android.circles;

import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.activity.WSCancelRequest;
import net.ora.mobile.android.webservices.circles.WSCircleMembers;
import net.ora.mobile.android.webservices.profile.WSRequestFriend;
import net.ora.mobile.dto.activity.response.CancelRequestResponse;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class CircleMembersFragment extends CachedImageDataFragment {

	private Circle circle;

	private View view;
	private ViewGroup viewMembers;

	public static CircleMembersFragment getInstance(Circle circle) {
		CircleMembersFragment fragment = new CircleMembersFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments()
					.getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}
	}

	@Override
	protected int getActionBarString() {
		return R.string.circleMembers_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		// Save
		if (circle == null) {
			return null;
		}

		// Inflate View
		view = (ViewGroup) inflater.inflate(
				R.layout.fragment_circles_circle_members, container, false);

		// Inflate View
		viewMembers = (ViewGroup) view
				.findViewById(R.id.circleMembers_lstMembers);

		// Load members
		new LoadCircleMembersActionDialog(getActivity()).init();

		// Return
		return view;
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class LoadCircleMembersActionDialog extends
			ActionDialog<List<CircleMember>> {

		public LoadCircleMembersActionDialog(Activity context) {
			super(context);
		}

		@Override
		public List<CircleMember> performAction() {
			int circleId = circle.getId();
			return WSCircleMembers.getCircleMembers(context, circleId);
		}

		@SuppressWarnings("unchecked")
		@Override
		public void afterAction(List<CircleMember> members) {
			// Validate result
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
						context);
				popFragment();
				return;
			}

			int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
			
			Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[members.size()];
			int i = 0;
			for (int index = 0; index < members.size(); index++) {
				final CircleMember member = members.get(index);

				LayoutInflater inflater = LayoutInflater.from(context);
				View viewMember = inflater.inflate(
						R.layout.list_circles_member, null);

				// Set member name
				TextView temp = (TextView) viewMember
						.findViewById(R.id.tv_item_circle_member_name);
				temp.setText(member.getName());

				// Configure buttons
				setBotonsActions(member, viewMember);

				// Click on the item (go to profile)
				viewMember.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						getActivity().startActivity(
								new Intent(getActivity(),ProfileFriendActivity.class).putExtra("friend_id", member.getId()));
					}
				});
				
				// Save user/image view info
				ImageView friendPicture = (ImageView) viewMember.findViewById(R.id.iv_item_circle_member_image);
				ImageView circlePicture = (ImageView) viewMember.findViewById(R.id.iv_item_circle_member_Cirle);
				
				friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
				circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
				
				usersImagesViewsPairs[i++] = new Pair<User, ImageView>(member, friendPicture);

				// Add view and separator
				viewMembers.addView(viewMember);
				if (index != members.size() - 1) {
					View viewSeparator = inflater.inflate(
							R.layout.item_separator, null);
					viewMembers.addView(viewSeparator);
				}
			}

			AsyncDownloadImageUser async = new AsyncDownloadImageUser(
					"PrayersFeedFragmets", getActivity(), CircleMembersFragment.this);
			asyncTaskList.add(async);
			async.setShouldResize(false);
			async.execute(usersImagesViewsPairs);
		}
	}

	private void setBotonsActions(CircleMember member, View viewMember) {
		// Set up the image
		ImageView imgCheckGreen = (ImageView) viewMember
				.findViewById(R.id.ib_item_circle_member_accepted);
		ImageView imgPendingFriend = (ImageView) viewMember
				.findViewById(R.id.ib_item_circle_member_pending);
		ImageView imgAddFriend = (ImageView) viewMember
				.findViewById(R.id.ib_item_circle_member_add);
		User user = ((OraApplication) getActivity().getApplication()).getUser();
		if (member.getId() == user.getId()) {
			// Same user
			imgCheckGreen.setVisibility(View.GONE);
			imgPendingFriend.setVisibility(View.GONE);
			imgAddFriend.setVisibility(View.GONE);
		} else {
			if (member.isFriend()) {
				// Is frined
				imgCheckGreen.setVisibility(View.VISIBLE);
				imgPendingFriend.setVisibility(View.GONE);
				imgAddFriend.setVisibility(View.GONE);
			} else {
				if (member.isRequested()) {
					// Pending
					imgCheckGreen.setVisibility(View.GONE);
					imgPendingFriend.setVisibility(View.VISIBLE);
					imgAddFriend.setVisibility(View.GONE);

					// Set listener
					imgPendingFriend
							.setOnClickListener(new RemoveRequestManager(
									member, viewMember));
				} else {
					// Unknown
					imgCheckGreen.setVisibility(View.GONE);
					imgPendingFriend.setVisibility(View.GONE);
					imgAddFriend.setVisibility(View.VISIBLE);

					// Set listener
					imgAddFriend.setOnClickListener(new AddFriendManager(
							member, viewMember));
				}
			}
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class RemoveRequestManager implements OnClickListener {

		protected CircleMember member;
		protected View viewMember;

		public RemoveRequestManager(CircleMember member, View viewMember) {
			this.member = member;
			this.viewMember = viewMember;
		}

		@Override
		public void onClick(View v) {
			GeneralMethods.showDialogYesNo(
					getString(R.string.circleMembers_askRemoveRequestFriend,
							member.getName()), getActivity(), getActivity(),
					new Runnable() {
						@Override
						public void run() {
							new CancelRequestActionDialog(getActivity()).init();
						}
					});
		}

		/**
		 * 
		 * @author Byron
		 * 
		 */
		public class CancelRequestActionDialog extends
				ActionDialog<CancelRequestResponse> {

			public CancelRequestActionDialog(Activity context) {
				super(context);
			}

			@Override
			public CancelRequestResponse performAction() {
				WSCancelRequest.cancelRequest(context,
						Integer.toString(member.getId()));
				return WSCancelRequest.getResponse();
			}

			@Override
			public void afterAction(CancelRequestResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(
							MasterService.getErrorMessage(), context);
				} else {

					// Set new info
					member.setFriend(response.isFriend());
					member.setRequested(response.isRequest());
					setBotonsActions(member, viewMember);
				}
			}

		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class AddFriendManager implements OnClickListener {

		protected CircleMember member;
		protected View viewMember;

		public AddFriendManager(CircleMember member, View viewMember) {
			this.member = member;
			this.viewMember = viewMember;
		}

		@Override
		public void onClick(View v) {
			new RequestFriendActionDialog(getActivity()).init();
		}

		public class RequestFriendActionDialog extends
				ActionDialog<RequestFriendResponse> {

			public RequestFriendActionDialog(Activity context) {
				super(context);
			}

			@Override
			public RequestFriendResponse performAction() {
				int userId = member.getId();
				return WSRequestFriend.requestFriend(context, userId);
			}

			@Override
			public void afterAction(RequestFriendResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(
							MasterService.getErrorMessage(), context);
				} else {
					Toast.makeText(context, response.getMessage(),
							Toast.LENGTH_SHORT).show();

					// Set new info
					member.setFriend(response.isFriend());
					member.setRequested(response.isRequested());
					setBotonsActions(member, viewMember);
				}
			}

		}
	}
}
