package net.ora.mobile.android.webservices.prayers;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.RatePrayerResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSRatePrayer extends MasterService {

	private static final String URL = "rate_prayer/";

	public static RatePrayerResponse ratePrayer(Context context, Prayer prayer) {

		try {
			int rate = (!prayer.isFavorite()) ? 1 : 0;
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("prayer_id", Integer.toString(prayer.getId())));
			request.add(new BasicNameValuePair("rating", Integer.toString(rate)));

			// Make request
			RatePrayerResponse response = makeRequest(context,
					CONNECTION_TYPE.POST, URL, request,
					new TypeReference<RatePrayerResponse>() {});

			return response;
			
		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}

		return null;
	}
}
