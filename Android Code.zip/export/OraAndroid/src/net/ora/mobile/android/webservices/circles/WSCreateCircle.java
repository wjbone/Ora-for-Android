package net.ora.mobile.android.webservices.circles;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.util.ParseImageHttpEntityBuilder;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CreateCircleResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCreateCircle extends MasterService {

	private static final String URL = "circle_create_v2/";

	public static Circle createCircle(Context context, String name, boolean isLite, String about, String city, boolean isPrivate,
			boolean approvesMembers, String picturePath) {

		try {
			// Validates
			validateRequired(context, name, R.string.wsCreateCircle_errorName);

			String strIsLite = (isLite ? "1" : "0");

			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("name", name));
			request.add(new BasicNameValuePair("is_lite", strIsLite));
			request.add(new BasicNameValuePair("about", about));
			request.add(new BasicNameValuePair("city", city));
			request.add(new BasicNameValuePair("private", Boolean.toString(isPrivate)));
			request.add(new BasicNameValuePair("approves_members", Boolean.toString(approvesMembers)));
			if(picturePath != null && picturePath.length() > 0)
				request.add(new BasicNameValuePair("picture", picturePath));

			// Make request
			CreateCircleResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, request,
					new ParseImageHttpEntityBuilder("picture"), new TypeReference<CreateCircleResponse>() {
					});

			return response.getCircle();
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsCreateCircle_error);
		}

		return null;
	}
}
