package net.ora.mobile.android.feed;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.profile.WSShareOnFacebook;
import net.ora.mobile.dto.feed.Inspiration;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;

/**
 * @author bmorales
 * 
 */
public class InspirationDialogFragment extends DialogFragment {
	
	public static final String TAG = "inspiration_dialog_fragment";

	private Inspiration inspiration;

	private Bitmap inspirationImage;

	public void setInspirationImage(Bitmap inspirationImage) {
		this.inspirationImage = inspirationImage;
	}

	public Inspiration getInspiration() {
		return inspiration;
	}

	public void setInspiration(Inspiration inspiration) {
		this.inspiration = inspiration;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// The only reason you might override this method when using onCreateView() is
		// to modify any dialog characteristics. For example, the dialog includes a
		// title by default, but your custom layout might not need it. So here you can
		// remove the dialog title, but you must call the superclass to get the Dialog.
		Dialog dialog = super.onCreateDialog(savedInstanceState);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setCanceledOnTouchOutside(false);
		return dialog;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.dialog_daily_inspiration, container, false);

		// Set inspiration image
		((ImageView) view.findViewById(R.id.iv_prayers_inspiration)).setImageBitmap(inspirationImage);
		// close button
		view.findViewById(R.id.iv_close).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dismiss();
			}
		});
		// Share to Facebook
		View facebookView = view.findViewById(R.id.iv_facebook);
		if (WSShareOnFacebook.isFacebookLogin()) {
			facebookView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					AskShareOnFacebookDialogFragment dialog = new AskShareOnFacebookDialogFragment();
					dialog.setInspirationImage(inspirationImage);
					dialog.show(getFragmentManager(), "AskShareOnFacebookDialogFragment");
				}
			});
		} else {
			facebookView.setVisibility(View.INVISIBLE);
		}

		return view;
	}

	public static class AskShareOnFacebookDialogFragment extends DialogFragment {

		private Bitmap inspirationImage;

		public void setInspirationImage(Bitmap inspirationImage) {
			this.inspirationImage = inspirationImage;
		}

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

			// null should be your on click listener
			builder.setMessage(getString(R.string.feed_prayers_dailyInspiration__askShareOnFacebook));
			builder.setPositiveButton(getString(R.string.feed_prayers_dailyInspiration__btnShare), dialogClickListener);
			builder.setNegativeButton(getString(R.string.feed_prayers_dailyInspiration__btnCancel), dialogClickListener);

			return builder.create();
		}

		private DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case DialogInterface.BUTTON_POSITIVE:
					// Share button clicked

					Dialog progressDialog = ProgressDialog.show(getActivity(), "",
							getString(R.string.feed_prayers_dailyInspiration__msgSharingOnFacebook));

					WSShareOnFacebook.shareImage(getActivity(),
							getString(R.string.feed_prayers_dailyInspiration__msgInspirationTextForFacebook), inspirationImage,
							progressDialog);

				case DialogInterface.BUTTON_NEGATIVE:
					// No button clicked
					dismiss();
					break;
				}
			}
		};
	}
}
