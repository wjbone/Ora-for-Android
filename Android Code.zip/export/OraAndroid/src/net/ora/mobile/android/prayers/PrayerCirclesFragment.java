package net.ora.mobile.android.prayers;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.MyCirclesFragment;
import net.ora.mobile.android.circles.ViewCircleFragment;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCancelCircleRequest;
import net.ora.mobile.android.webservices.circles.WSJoinCircle;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CancelCircleRequestResponse;
import net.ora.mobile.dto.circles.response.JoinCircleResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadAnyImage;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class PrayerCirclesFragment extends CachedImageDataFragment {

	private static final String TAG_PRAYER = "prayer";
	public static final int LOADER_ID_SEARCH_CIRCLES = 100;

	public static final int GROUP_CIRCLES = 1;
	
	private Prayer prayer;

	private ViewGroup viewMyCircles;
	
	
	public static PrayerCirclesFragment getInstance(Prayer prayer) {
		PrayerCirclesFragment fragment = new PrayerCirclesFragment();
		
		Bundle args = new Bundle();
		args.putParcelable(TAG_PRAYER, prayer);
		
		fragment.setArguments(args);
		
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if (getArguments() != null)
			prayer = getArguments().getParcelable(TAG_PRAYER);
	}
	
	protected int getActionBarString() {
		return R.string.viewPrayerCircles_title;
	};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (prayer == null)
			return super.onCreateView(inflater, container, savedInstanceState);

		View v = inflater.inflate(R.layout.fragment_circles_my_circles,
				container, false);

		viewMyCircles = (ViewGroup) v.findViewById(R.id.myCircles_lstCircles);

		// 
		loadCirclesViews(prayer.getCircles(), viewMyCircles, true);
		
		// Load circles list
		return v;
	}

	private <T extends Circle> void loadCirclesViews(List<T> circles,
			ViewGroup viewGroup, final boolean sendCircle) {
		// List of image views
		List<ImageView> pictureViews = new ArrayList<ImageView>();
		List<String> pictureUrls = new ArrayList<String>();

		//width of the picture
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
		
		// Load circles
		for (int i = 0; i < circles.size(); i++) {
			final Circle circle = circles.get(i);

			LayoutInflater inflater = LayoutInflater.from(getActivity());
			View viewCircle = inflater.inflate(R.layout.list_item_circle, null);

			viewCircle.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					pushFragment(ViewCircleFragment.getInstance(circle));
				}
			});

			TextView lblName = (TextView) viewCircle
					.findViewById(R.id.itemCircle_lblName);
			lblName.setText(circle.getName());

			TextView lblType = (TextView) viewCircle
					.findViewById(R.id.itemCircle_tvType);
			lblType.setText(circle.getSecurityLevelId());

			TextView lblCity = (TextView) viewCircle
					.findViewById(R.id.itemCircle_lblCity);
			lblCity.setText(circle.getCity());

			ImageView imgPicture = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivImage);
			imgPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			((ImageView) viewCircle.findViewById(R.id.itemCircle_ivCheck)).setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			if (circle.getPicture() != null && circle.getPicture().length() > 0) {
				pictureViews.add(imgPicture);
				pictureUrls.add(circle.getPicture());
			}

			viewGroup.addView(viewCircle);
			if (i != circles.size() - 1) {
				View viewSeparator = inflater.inflate(R.layout.item_separator,
						null);
				viewGroup.addView(viewSeparator);
			}
			
			// Configure buttons
			setActionButtons(circle, viewCircle);
		}

		// Load images
		DownloadAnyImage asyncLoadCirclesPictures = new DownloadAnyImage(
				"Load circles' pictures", getActivity());
		asyncLoadCirclesPictures.setListPictures(pictureViews);
		asyncLoadCirclesPictures
				.execute(MyCirclesFragment.toArray(pictureUrls));
	}
	
	private void setActionButtons(Circle circle, View viewCircle) {
		// Set up the image
		ImageView imgCheckGreen = (ImageView) viewCircle
				.findViewById(R.id.ib_item_accepted);
		ImageView imgPending = (ImageView) viewCircle
				.findViewById(R.id.ib_item_pending);
		ImageView imgAdd = (ImageView) viewCircle
				.findViewById(R.id.ib_item_add);
		
		if (circle.isOwner() || circle.isMember()) {
			// Is member
			imgCheckGreen.setVisibility(View.VISIBLE);
			imgPending.setVisibility(View.GONE);
			imgAdd.setVisibility(View.GONE);
		} else {
			if (circle.isRequested()) {
				// Pending
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.VISIBLE);
				imgAdd.setVisibility(View.GONE);

				// Set listener
				imgPending.setOnClickListener(
						new CancelCircleRequestManager(circle, viewCircle));
			} else {
				// Unknown
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.GONE);
				imgAdd.setVisibility(View.VISIBLE);

				// Set listener
				imgAdd.setOnClickListener(
						new JoinCircleManager(circle, viewCircle));
			}
		}
	}
	
	
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class JoinCircleManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public JoinCircleManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new JoinCircleActionDialog(getActivity()).init();
		}
		
		/**
		 */
		public class JoinCircleActionDialog extends
			ActionDialog<JoinCircleResponse> {
	
			public JoinCircleActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public JoinCircleResponse performAction() {
				int circleId = circle.getId();
				return WSJoinCircle.joinCircle(context, circleId);
			}
		
			@Override
			public void afterAction(JoinCircleResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
					return;
				}
		
				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();
				
				// Configure circle
				circle.setMember(response.isMember());
				circle.setRequested(response.isRequested());
				
				// Set circle view
				setActionButtons(circle, viewCircle);
				
				// Show message
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class CancelCircleRequestManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public CancelCircleRequestManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new CancelCircleRequestActionDialog(getActivity()).init();
		}
		
		public class CancelCircleRequestActionDialog extends
				ActionDialog<CancelCircleRequestResponse> {
		
			public CancelCircleRequestActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public CancelCircleRequestResponse performAction() {
				int circleId = circle.getId();
				return WSCancelCircleRequest.cancelCircleRequest(context, circleId);
			}
		
			@Override
			public void afterAction(CancelCircleRequestResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
				} else {
					// Mark circle list for reload
					OraConfiguration configuration = new OraConfiguration(getContext());
					configuration.setFirstTimeLoadingCircles(true);
					configuration.close();
					
					// Configure circle
					circle.setMember(response.isMember());
					circle.setRequested(response.isRequested());
					
					// Set circle view
					setActionButtons(circle, viewCircle);
					
					// Show message
					Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
							.show();
				}
			}
		
		}
	}

	public static String[] toArray(List<String> strings) {
		String[] values = new String[strings.size()];
		for (int i = 0; i < strings.size(); i++) {
			values[i] = strings.get(i);
		}

		return values;
	}
}