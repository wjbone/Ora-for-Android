package net.ora.mobile.android.ui;

import com.j256.ormlite.android.apptools.OpenHelperManager;

import net.ora.mobile.dao.FeedDBHelper;

public class DBAccessFragment extends CachedImageDataFragment {

	private FeedDBHelper helper;
	 
    protected FeedDBHelper getHelper() {
        if (helper == null) {
        	helper = OpenHelperManager.
        			getHelper(getActivity(), FeedDBHelper.class);
        }
        return helper;
    }
 
    @Override
	public void onDestroy() {
        super.onDestroy();
        if (helper != null) {
            OpenHelperManager.releaseHelper();
            helper = null;
        }
    }

}
