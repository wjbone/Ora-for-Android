package net.ora.mobile.android.webservices.feed;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import net.ora.mobile.dto.feed.response.PrayersFeedSearchResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSPrayersFeedSearch extends MasterService {

	private static final String URL = "prayers_feed_search/";

	public static PrayersFeedResponse searchPrayersFeed(Context context, String query, int page) {
		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("query", query));
			request.add(new BasicNameValuePair("page", Integer.toString(page)));

			// Make request
			PrayersFeedSearchResponse response = makeRequest(context,
					CONNECTION_TYPE.GET, URL, request,
					new TypeReference<PrayersFeedSearchResponse>() {
					});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsRelatedCircles_error);
		}

		return null;
	}

}
