package net.ora.mobile.android.webservices.feed;

import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;

public class WSFaithfulFeed extends MasterService {

	public static final int RATING_ALL_ANSWERED_OWN_PRAYERS = -1;
	public static final int RATING_ALL_NON_FAVORITE_ANSWERED_AND_FAVORITES_OWN_PRAYERS = 0;
	public static final int RATING_ALL_FAVORITE_ANSWERED_OWN_PRAYERS = 1;
	public static final int RATING_ALL_OWN_PRAYERS = 2;

	public static final int FILTER_ALL_ANSWERED_OWN_PRAYERS_AND_ANSWERED_PRAYERS_I_HAVE_LIKED_FOR = 1;
	public static final int FILTER_ALL_ANSWERED_OWN_PRAYERS = 2;
	public static final int FILTER_ALL_FAVORITE_PRAYERS = 3;
	
	public static final int PRAYER_ID_ALL_PRAYERS = -1;

	private static final String URL = "faithful_feed/";

	public static PrayersFeedResponse getFaithfulFeed(Context context,
			int rating, int filter, int page, int prayerId) {

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("rating", Integer.toString(rating)));
			request.add(new BasicNameValuePair("filter", Integer
					.toString(filter)));
			request.add(new BasicNameValuePair("page", Integer.toString(page)));
			request.add(new BasicNameValuePair("prayer_id", Integer
					.toString(prayerId)));
			request.add(new BasicNameValuePair("last_date_answered", Integer
					.toString(prayerId)));

			// Make request
			PrayersFeedResponse response = makeRequest(context,
					CONNECTION_TYPE.GET, URL, request,
					new TypeReference<PrayersFeedResponse>() {
					});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsRelatedCircles_error);
		}

		return null;
	}

}
