package net.ora.mobile.android.prayers;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSAnswerPrayer;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.AnswerPrayerResponse;
import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGFragment;

public class PrayerAnswerFragment extends DGFragment {

	public static final String TAG_PRAYER = "prayer";
	public static final int LOADER_ID_PRAYER_COMMENTS = 30;

	private Prayer prayer;

	private ViewGroup view;

	public static PrayerAnswerFragment getInstance(Prayer prayer) {
		PrayerAnswerFragment fragment = new PrayerAnswerFragment();

		Bundle args = new Bundle();
		args.putParcelable(TAG_PRAYER, prayer);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	protected int getActionBarString() {
		return R.string.answerPrayer_title;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null)
			prayer = getArguments().getParcelable(TAG_PRAYER);

		// Action bar icons
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if (prayer == null)
			return super.onCreateView(inflater, container, savedInstanceState);

		view = (ViewGroup) inflater.inflate(R.layout.fragment_prayer_answer, container, false);

		return view;
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

		inflater.inflate(R.menu.prayer_answer_menu, menu);

		final MenuItem item = menu.findItem(R.id.prayerAnswer_miDone);
		item.getActionView().findViewById(R.id.menu__prayer_answer__btn_done).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onOptionsItemSelected(item);
			}
		});

		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.prayerAnswer_miDone:
			AnswerPrayerActionDialog dialog = new AnswerPrayerActionDialog(getActivity());
			dialog.init();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	class AnswerPrayerActionDialog extends ActionDialog<AnswerPrayerResponse> {

		public AnswerPrayerActionDialog(Activity context) {
			super(context);
		}

		@Override
		public AnswerPrayerResponse performAction() {
			String answer = ((TextView) view.findViewById(R.id.prayerAnswer_txtAnswer)).getText().toString();
			return WSAnswerPrayer.answerPrayer((OraApplication) getActivity().getApplication(), getContext(), prayer, answer);
		}

		@Override
		public void afterAction(AnswerPrayerResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Set prayer
			prayer.setPrayer(response.getPrayer());

			// Confirmation
			Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();

			// Exit
			popFragment();
		}

	}
}
