package net.ora.mobile.android.help;

import net.ora.mobile.android.R;
import android.util.Log;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.widget.ImageView;

public class MyGestureDetector extends SimpleOnGestureListener {

	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 30;
	
	private ImageView mImageView;
	private Integer[] mImagesList = { R.drawable.tutorial__learning_ora_overlay__page_1,
			R.drawable.tutorial__learning_ora_overlay__page_2, R.drawable.tutorial__learning_ora_overlay__page_3, 
			R.drawable.tutorial__learning_ora_overlay__page_4, R.drawable.tutorial__learning_ora_overlay__page_5 };
	private int mPhoto;
	private boolean isLast, isSwipe;
	
	public MyGestureDetector(ImageView imageView){
		mImageView = imageView;
		mPhoto = 0;
		imageView.setImageResource(mImagesList[mPhoto]);
	}
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY){
		Log.i("Swipe detector", "swiping");
		try {
            if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                return false;
            if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                mPhoto = (mPhoto + 1) % mImagesList.length;
                mImageView.setImageResource(mImagesList[mPhoto]);
            } else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                mPhoto = (mPhoto - 1) % mImagesList.length;
                if (mPhoto < 0) {
                    mPhoto = 0;
                }
                mImageView.setImageResource(mImagesList[mPhoto]);
            }
            if(mPhoto == (mImagesList.length - 1)){
            	isLast = true;
            	isSwipe = true;
            }else{
            	isLast = false;
            	isSwipe = false;
            }
        } catch (Exception e) {
            Log.e("SwypeImagesActivity", "error on gesture detector");
        }
        return false;
	}

	public int getmPhoto() {
		return mPhoto;
	}

	public boolean isLast() {
		return isLast;
	}

	public boolean isSwipe() {
		return isSwipe;
	}

	public void setSwipe(boolean isSwipe) {
		this.isSwipe = isSwipe;
	}
	
}
