package net.ora.mobile.android.friends;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.MyCirclesFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCancelCircleRequest;
import net.ora.mobile.android.webservices.circles.WSJoinCircle;
import net.ora.mobile.android.webservices.circles.WSRelatedCircles;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CancelCircleRequestResponse;
import net.ora.mobile.dto.circles.response.JoinCircleResponse;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadAnyImage;
import com.digitalgeko.mobile.android.objects.friends.ActivityImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class CirclesListFriendActivity extends ActivityImageData {

	public static final int LOADER_ID_SEARCH_CIRCLES = 100;

	private int friend_id;
	
	public static final int GROUP_CIRCLES = 1;

	private ViewGroup viewMyCircles;
	//private ViewGroup viewSearchCircles;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_circles_my_circles);
		
		setTitle("Related Circles");
		setDownloadFlag(true);
		friend_id = getIntent().getExtras().getInt("friend_id");
		
		viewMyCircles = (ViewGroup) findViewById(R.id.myCircles_lstCircles);
		//viewSearchCircles = (ViewGroup) findViewById(R.id.myCircles_lstSearchCircles);
		
		new RelatedCirclesActionDialog(this).init();
	}
	
	private <T extends Circle> void loadCirclesViews(List<T> circles,
			ViewGroup viewGroup, final boolean sendCircle) {
		// List of image views
		List<ImageView> pictureViews = new ArrayList<ImageView>();
		List<String> pictureUrls = new ArrayList<String>();
		
		//width of the picture
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(this);
		
		// Load circles
		for (int i = 0; i < circles.size(); i++) {
			final Circle circle = circles.get(i);

			LayoutInflater inflater = LayoutInflater.from(this);
			View viewCircle = inflater.inflate(R.layout.list_item_circle, null);

			viewCircle.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(CirclesListFriendActivity.this, ViewFriendCircleActivity.class);
					intent.putExtra("about", circle.getAbout());
					intent.putExtra("approvesMembers", circle.isApprovesMembers());
					intent.putExtra("city", circle.getCity());
					intent.putExtra("id", circle.getId());
					intent.putExtra("isEnterprise", circle.isCommunity());
					intent.putExtra("isLite", circle.isLite());
					intent.putExtra("isMember", circle.isMember());
					intent.putExtra("isOwner", circle.isOwner());
					intent.putExtra("isPrivate", circle.isPrivate());
					intent.putExtra("isRequested", circle.isRequested());
					intent.putExtra("name", circle.getName());
					intent.putExtra("picture", circle.getPicture());
					
					startActivity(intent);
					
				}
			});

			TextView lblName = (TextView) viewCircle
					.findViewById(R.id.itemCircle_lblName);
			lblName.setText(circle.getName());

			TextView lblType = (TextView) viewCircle
					.findViewById(R.id.itemCircle_tvType);
			lblType.setText(circle.getSecurityLevelId());

			TextView lblCity = (TextView) viewCircle
					.findViewById(R.id.itemCircle_lblCity);
			lblCity.setText(circle.getCity());

			ImageView imgPicture = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivImage);
			imgPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			((ImageView) viewCircle.findViewById(R.id.itemCircle_ivCheck)).setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			
			if (circle.getPicture() != null
					&& circle.getPicture().length() > 0) {
				pictureViews.add(imgPicture);
				pictureUrls.add(circle.getPicture());
			}

			viewGroup.addView(viewCircle);
			if (i != circles.size() - 1) {
				View viewSeparator = inflater.inflate(R.layout.item_separator,
						null);
				viewGroup.addView(viewSeparator);
			}
			
			// Configure buttons
			setActionButtons(circle, viewCircle);
		}

		// Load images
		DownloadAnyImage asyncLoadCirclesPictures = new DownloadAnyImage("Load circles' pictures", this);
		asyncLoadCirclesPictures.setListPictures(pictureViews);
		asyncLoadCirclesPictures.execute(MyCirclesFragment.toArray(pictureUrls));
	}
	
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class RelatedCirclesActionDialog extends ActionDialog<List<Circle>> {

		public RelatedCirclesActionDialog(Activity context) {
			super(context);
		}
		
		@Override
		public List<Circle> performAction() {
			return WSRelatedCircles.getRelatedCirclesFromServer(context, Integer.toString(friend_id));
		}
		
		@Override
		public void afterAction(List<Circle> circles) {
			if (MasterService.isFailedConnection()) {
				Toast.makeText(context, MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
			} else {
				loadCirclesViews(circles, viewMyCircles, false);
			}
		}
		
	}
	
	
	private void setActionButtons(Circle circle, View viewCircle) {
		// Set up the image
		ImageView imgCheckGreen = (ImageView) viewCircle
				.findViewById(R.id.ib_item_accepted);
		ImageView imgPending = (ImageView) viewCircle
				.findViewById(R.id.ib_item_pending);
		ImageView imgAdd = (ImageView) viewCircle
				.findViewById(R.id.ib_item_add);
		
		if (circle.isOwner() || circle.isMember()) {
			// Is member
			imgCheckGreen.setVisibility(View.VISIBLE);
			imgPending.setVisibility(View.GONE);
			imgAdd.setVisibility(View.GONE);
		} else {
			if (circle.isRequested()) {
				// Pending
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.VISIBLE);
				imgAdd.setVisibility(View.GONE);

				// Set listener
				imgPending.setOnClickListener(
						new CancelCircleRequestManager(circle, viewCircle));
			} else {
				// Unknown
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.GONE);
				imgAdd.setVisibility(View.VISIBLE);

				// Set listener
				imgAdd.setOnClickListener(
						new JoinCircleManager(circle, viewCircle));
			}
		}
	}
	
	
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class JoinCircleManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public JoinCircleManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new JoinCircleActionDialog(CirclesListFriendActivity.this).init();
		}
		
		/**
		 */
		public class JoinCircleActionDialog extends
			ActionDialog<JoinCircleResponse> {
	
			public JoinCircleActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public JoinCircleResponse performAction() {
				int circleId = circle.getId();
				return WSJoinCircle.joinCircle(context, circleId);
			}
		
			@Override
			public void afterAction(JoinCircleResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
					return;
				}
		
				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();
				
				// Configure circle
				circle.setMember(response.isMember());
				circle.setRequested(response.isRequested());
				
				// Set circle view
				setActionButtons(circle, viewCircle);
				
				// Show message
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	class CancelCircleRequestManager implements OnClickListener {
		
		private Circle circle;
		private View viewCircle;
		
		public CancelCircleRequestManager(Circle circle, View viewCircle) {
			this.circle = circle;
			this.viewCircle = viewCircle;
		}
		
		@Override
		public void onClick(View v) {
			new CancelCircleRequestActionDialog(CirclesListFriendActivity.this).init();
		}
		
		public class CancelCircleRequestActionDialog extends
				ActionDialog<CancelCircleRequestResponse> {
		
			public CancelCircleRequestActionDialog(Activity context) {
				super(context);
			}
		
			@Override
			public CancelCircleRequestResponse performAction() {
				int circleId = circle.getId();
				return WSCancelCircleRequest.cancelCircleRequest(context, circleId);
			}
		
			@Override
			public void afterAction(CancelCircleRequestResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
							context);
				} else {
					
					// Mark circle list for reload
					OraConfiguration configuration = new OraConfiguration(getContext());
					configuration.setFirstTimeLoadingCircles(true);
					configuration.close();
					
					// Configure circle
					circle.setMember(response.isMember());
					circle.setRequested(response.isRequested());
					
					// Set circle view
					setActionButtons(circle, viewCircle);
					
					// Show message
					Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT)
							.show();
				}
			}
		
		}
	}
}
