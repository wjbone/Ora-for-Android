package net.ora.mobile.android.ui;

import com.digitalgeko.mobile.android.ui.DGFragment;

public class OraFragment extends DGFragment {
	
	
	
}
