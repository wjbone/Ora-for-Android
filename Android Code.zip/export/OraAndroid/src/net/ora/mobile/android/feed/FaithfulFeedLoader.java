package net.ora.mobile.android.feed;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.feed.WSFaithfulFeed;
import net.ora.mobile.android.webservices.feed.WSPrayersFeed;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.app.Activity;
import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

/**
 * 
 * @author byron
 * 
 */
public class FaithfulFeedLoader extends FeedAsyncTaskLoader {

	private int rating = WSFaithfulFeed.RATING_ALL_NON_FAVORITE_ANSWERED_AND_FAVORITES_OWN_PRAYERS;
	private int filter = WSPrayersFeed.PRIVATE_TYPE_PRAYERS_FRIENDS_AND_CIRCLES;
	private int page = 1;
	private int prayerId = 0;

	public FaithfulFeedLoader(Activity activity, 
			FeedLoaderCallbacks<PrayersFeedResponse> callbacks) {
		super(activity, callbacks);
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getFilter() {
		return filter;
	}

	public void setFilter(int filter) {
		this.filter = filter;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPrayerId() {
		return prayerId;
	}

	public void setPrayerId(int prayerId) {
		this.prayerId = prayerId;
	}
	
	@Override
	public PrayersFeedResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			Log.i("Loader", "No more data");
			return PrayersFeedResponse.EMPTY_RESPONSE;
		}

		Context context = getContext();
		PrayersFeedResponse response = WSFaithfulFeed.getFaithfulFeed(context,
				rating, filter, page, prayerId);

		if (MasterService.isFailedConnection()) {
			showErrorMessage(MasterService.getErrorMessage());
			abandon();
			return null;
		}
		this.page = response.getNextPage();

		Log.i("Loader", "finish");

		return response;
	}
}
