package net.ora.mobile.android.friends.fragment;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.PrayerDetailActivity;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.friends.ViewFriendCircleActivity;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadSamePicture;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.profile.FriendPrayerLoader;
import com.digitalgeko.mobile.android.objects.profile.PrayerView;
import com.digitalgeko.mobile.android.ui.ScrollViewExt;
import com.digitalgeko.mobile.android.ui.ScrollViewListener;

public class FriendsPrayersFragment extends BaseFriendsFragment implements ScrollViewListener, LoaderManager.LoaderCallbacks<RequestPrayersResponse>{

	public static final String TAG_FRIEND = "friend";
	
	private int nextPage = 1;
	private User friend;
//	private int friend_id;
//	private String name, picture;
	
	private LinearLayout prayerList;
	private View loadingView = null;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.profile_list_all_prayers, container, false);
		
		setDownloadFlag(true);
//		friend_id = (Integer)  ((OraApplication) getActivity().getApplication()).getParam("friend_id_PLFA");
//		name = (String)  ((OraApplication) getActivity().getApplication()).getParam("name_PLFA");
//		picture = (String)  ((OraApplication) getActivity().getApplication()).getParam("picture_PLFA");
		
		((ScrollViewExt) view.findViewById(R.id.sv_allPrayers)).setScrollViewListener(this);
		
		prayerList = (LinearLayout) view.findViewById(R.id.ly_allPrayers);
		
////		if(WSFriendPrayers.getResponse() == null){
//			loadingView = inflater.inflate(R.layout.item_loading, null);
//			
//			prayerList.addView(loadingView);
//			prayerList.invalidate();
//			
//			getActivity().getSupportLoaderManager().restartLoader(0, null, this);
////		}else{
////			addPrays(WSFriendPrayers.getResponse());
////		}
		
		return view;
	}
	
	public void setFriend(User friend) {
		this.friend = friend;
		
		LayoutInflater inflater = getActivity().getLayoutInflater();
		loadingView = inflater.inflate(R.layout.item_loading, null);
		
		prayerList.addView(loadingView);
		prayerList.invalidate();
		
		getActivity().getSupportLoaderManager().restartLoader(0, null, this);
	}

	@Override
	public void onStop() {
		super.onStop();
		getLoaderManager().destroyLoader(0);
	}
	
	@Override
	public Loader<RequestPrayersResponse> onCreateLoader(int arg0, Bundle arg1) {
		FriendPrayerLoader loader = new FriendPrayerLoader(getActivity(), Integer.toString(nextPage), friend);
		return loader;
	}
	
	@Override
	public void onLoadFinished(Loader<RequestPrayersResponse> loader, RequestPrayersResponse data) {
		if(data != null){
			addPrays(data);
		}
	}
	
	@Override
	public void onLoaderReset(Loader<RequestPrayersResponse> arg0) { }
	
	@Override
	public void onScrollBottomReached(ScrollViewExt scrollView) { 
		if((nextPage != -1) && (!getActivity().getSupportLoaderManager().hasRunningLoaders())){
			getActivity().getSupportLoaderManager().restartLoader(0, null, this);
		}
	}
	
	@Override
	public void onScrollTopReached(ScrollViewExt scrollView) { }

	private void addPrays(RequestPrayersResponse data){
		if(loadingView != null){
			prayerList.removeView(loadingView);
		}
		
		nextPage = data.getNext_page();
		
		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods
				.getProfileImageWidth(getActivity());
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		List<ImageView> pictures = new ArrayList<ImageView>();
		
		for(Prayer prayer : data.getPrayers()){
			if(prayer.getUser() == null) {
				prayer.setUser(((OraApplication)getActivity().getApplication()).getUser());
			}
			
			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(
					R.layout.item_feed_prayer, null);
			OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);
			
			// Set info
			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer))
					.setText(prayer.getText());
			// Prayer User View
			TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
			prayerUserTextView.setText(prayer.getUser().getName());
			prayerUserTextView.setOnClickListener(goToProfileListener);

			// Go to user profile
			ImageView friendPicture = (ImageView) viewPrayer
					.findViewById(R.id.iv_profile_image_prayer);
			friendPicture.setOnClickListener(goToProfileListener);
			
			// Set circle
			ImageView circlePicture = (ImageView) viewPrayer
					.findViewById(R.id.iv_profile_circle_prayer);

			friendPicture
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
							width, width));
			circlePicture
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
							width, width));

			pictureImageViewList.add(friendPicture);
			circleImageViewList.add(circlePicture);
			
			// Save user/image view info
			pictures.add(friendPicture);

			// Circles
			int circlesCount = prayer.getCircles().size();
			String strCircles = "";
			if (circlesCount == 0) {
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
			} else {
				// Set listener
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(
						new GoPrayerCirclesManager(prayer));
				
				for(Circle circle : prayer.getCircles())
					strCircles += circle.getName() + ", ";
				strCircles = strCircles.substring(0, strCircles.length() - 2);
				// Set circles string
				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer))
						.setText(strCircles);
			}

			// Set prayer likes count
			TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
			likesCount.setText(Integer.toString(prayer.getLikesCount()));

			// Set prayer comments count
			TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
			commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
			// Set prayer time
			TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
			timeCount.setText(GeneralMethods.fromDate(
							GeneralMethods.parseStringToDate(prayer.getDateCreated())));
			
			// Set listeners
			TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
			View btnPray = viewPrayer
					.findViewById(R.id.feedPrayer_btnPray);
			descriptionView.setOnClickListener(
					new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray, false));
			if (prayer.isLikeAvailable()) {
				ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
				btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer,
						containerView));
			} else {
				btnPray.setVisibility(View.GONE);
			}
			viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments).setOnClickListener(
					new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray, true));
			if(prayer.getUser().equals( ((OraApplication)getActivity().getApplication()).getUser())) {
				// Can see prays list only in is the owner of the pray
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(
						new GoPrayerPraysManager(prayer));
			}
			
			
//			final Prayer temp_prayer = prayer;
//			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);
//			
//			View imgGrabber = viewPrayer.findViewById(R.id.feedPrayer_imGrabber);
//			final View grabber = imgGrabber;
//			
//			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
//			((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(
//					String.format(getString(R.string.prayer_item_frends), prayer.getCircles().size()));
//			
//			((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer)).setText(Integer.toString(prayer.getLikesCount()));
//			final TextView prayersCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
//			
//			((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer)).setText(Integer.toString(prayer.getCommentsCount()));
//			final TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
//			
//			((TextView) viewPrayer.findViewById(R.id.tv_pray_time)).setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));
//			final TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
//			
//			viewPrayer.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					PrayerView prayerView = new PrayerView(temp_prayer, prayersCount, commentsCount, timeCount, grabber);
//					
//					((OraApplication) getActivity().getApplication()).addParam("prayer_view", prayerView);
//					((OraApplication) getActivity().getApplication()).addParam("prayer_friends", temp_prayer);
//					
//					getActivity().startActivity(new Intent(getActivity(), PrayerDetailActivity.class));
//				}
//			});
//			
//			if (prayer.isLikeAvailable()) {
//				viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer, viewPrayer));
//			} else {
//				imgGrabber.setVisibility(View.GONE);
//			}
//			
//			((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer)).setText(name);
//			
//			ImageView picture = ((ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer));
//			pictures.add(picture);
//			
//			getPictureImageViewList().add(picture);
//			getCircleImageViewList().add(((ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer)));
//			
			prayerList.addView(viewPrayer);
			prayerList.invalidate();
		}
		
		String picture = friend.getProfilePicture();
		if(picture .trim().length() > 0){
			DownloadSamePicture asyncJob = new DownloadSamePicture(getActivity(), this, pictures, "MyPrayersListFragment Prayers");
			getAsyncTaskList().add(asyncJob);
			asyncJob.execute(picture.trim());
		}
		
		if(nextPage != -1){
			loadingView = inflater.inflate(R.layout.item_loading, null);
			prayerList.addView(loadingView);
			prayerList.invalidate();
		}else{
			loadingView = null;
		}
		
	}
	
	
	
	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private TextView prayersCount, commentsCount, timeCount;	
		private View grabber;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, TextView prayersCount, TextView commentsCount, TextView timeCount, View grabber, boolean showOnlyComments) {
			this.prayer = prayer;
			this.prayersCount = prayersCount;
			this.commentsCount = commentsCount;
			this.timeCount = timeCount;
			this.grabber = grabber;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			PrayerView prayerView = new PrayerView(prayer, prayersCount, commentsCount, timeCount, grabber);
			
			((OraApplication) getActivity().getApplication()).addParam("prayer_view", prayerView);
			((OraApplication) getActivity().getApplication()).addParam("prayer_friends", prayer);
			
			getActivity().startActivity(new Intent(getActivity(), PrayerDetailActivity.class));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			getActivity().startActivity(new Intent(getActivity(), ProfileFriendActivity.class)
			.putExtra("friend_id", prayer.getUser().getId()));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerPraysManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			// TODO ORA
//			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerCirclesManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			if(prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
				Intent intent = new Intent(getActivity(), ViewFriendCircleActivity.class);
				intent.putExtra("about", circle.getAbout());
				intent.putExtra("approvesMembers", circle.isApprovesMembers());
				intent.putExtra("city", circle.getCity());
				intent.putExtra("id", circle.getId());
				intent.putExtra("isEnterprise", circle.isCommunity());
				intent.putExtra("isLite", circle.isLite());
				intent.putExtra("isMember", circle.isMember());
				intent.putExtra("isOwner", circle.isOwner());
				intent.putExtra("isPrivate", circle.isPrivate());
				intent.putExtra("isRequested", circle.isRequested());
				intent.putExtra("name", circle.getName());
				intent.putExtra("picture", circle.getPicture());
				
				startActivity(intent);
			} else {
				// TODO ORA 
//				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}
}
