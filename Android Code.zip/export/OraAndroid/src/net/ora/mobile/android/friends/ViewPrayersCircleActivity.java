package net.ora.mobile.android.friends;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraSherlockFragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.MenuItem;

public class ViewPrayersCircleActivity extends OraSherlockFragmentActivity {
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		ActionBar _actionBar = getSupportActionBar();

		_actionBar.setDisplayHomeAsUpEnabled(true);
		_actionBar.setDisplayShowTitleEnabled(false);
		_actionBar.setDisplayShowCustomEnabled(true);

		// Save action bar title view
		_actionBar.setCustomView(R.layout.custom_action_layout);
		View customView = _actionBar.getCustomView();
		((TextView) customView.findViewById(R.id.action_custom_title)).setText("Circle Prayers");
		
		((OraApplication) getApplication()).addParam("circle_id_VPCA", getIntent().getExtras().getInt("circle_id"));

		setContentView(R.layout.view_prayers_circle);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;
		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}
	
}
