package net.ora.mobile.android.feed;

import java.sql.SQLException;
import java.util.List;

import net.ora.mobile.dao.FeedDBHelper;
import net.ora.mobile.dao.configuration.BaseConfiguration;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.app.Activity;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.QueryBuilder;

public abstract class DbFeedAsyncTaskLoader extends FeedAsyncTaskLoader {

	private FeedDBHelper helper;

	public DbFeedAsyncTaskLoader(Activity activity, FeedLoaderCallbacks<PrayersFeedResponse> callbacks, FeedDBHelper helper) {
		super(activity, callbacks);

		this.helper = helper;
	}

	protected FeedDBHelper getHelper() {
		return helper;
	}

	protected boolean isFirstTime() {
		Dao<BaseConfiguration, ?> configurationDao;
		try {
			configurationDao = getHelper().getConfigurationDao();
			QueryBuilder<BaseConfiguration, ?> builder = configurationDao.queryBuilder();
			builder.limit(1L);
			List<BaseConfiguration> configurations = builder.query();
			if (configurations.size() == 0) {
				return true;
			} else {
				BaseConfiguration configuration = configurations.get(0);
				return configuration.getLoadCircles();
			}
		} catch (SQLException e) {
		}

		return true;
	}

	protected void saveConfiguration(boolean loadCircles) {
		Dao<BaseConfiguration, ?> configurationDao;
		try {
			configurationDao = getHelper().getConfigurationDao();
			QueryBuilder<BaseConfiguration, ?> builder = configurationDao.queryBuilder();
			builder.limit(1L);
			List<BaseConfiguration> configurations = builder.query();

			BaseConfiguration configuration;
			if (configurations.size() == 0) {
				configuration = new BaseConfiguration();
			} else {
				configuration = configurations.get(0);
			}

			// Save
			configuration.setLoadCircles(loadCircles);
			configurationDao.createOrUpdate(configuration);
		} catch (SQLException e) {
		}
	}

}
