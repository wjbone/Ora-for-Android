package net.ora.mobile.android.feed;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSAddLike;
import net.ora.mobile.android.webservices.prayers.WSPrayerListAdd;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.AddLikeResponse;
import net.ora.mobile.dto.prayers.response.PrayerListAddResponse;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.internal.nineoldandroids.animation.ValueAnimator;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;

/**
 * 
 * @author Byron
 * 
 */
public class SwipeToPrayDetector implements OnTouchListener {

	public static enum Action {
		None, // when no action was detected
		Click, Dragging
	}

	private static final long SPEED = 5;
	private static final long MAX_DURATION = 500;
	private static final String logTag = "SwipeDetector";
	private static final int MIN_DISTANCE = 15;

	private float downX, upX, currX, prevX;
	private Action mSwipeDetected = Action.None;

	private Prayer prayer;

	private ViewGroup viewPrayer;
	private View viewPrayerSwipeInfo;
	private View viewPray;
	private ValueAnimator anim;
	private TextView tvSwypingText;
	private ViewGroup layoutSwiping;
	private ViewGroup layoutSwiped;
	private View pgLoading;
	private Handler mainHandler;

	private float startAcceptanceZone = -1;
	private float relaseZone = -1;
	private float leftPadding = 0;

	private String strPullToPray;
	private String strReleaseToPray;

	public SwipeToPrayDetector(Prayer prayer, ViewGroup viewPrayer) {
		// Set objects
		this.prayer = prayer;

		// Set components
		this.viewPrayer = viewPrayer;
		this.viewPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);
		this.viewPrayerSwipeInfo = viewPrayer
				.findViewById(R.id.feedPrayer_vgPrayInfo);
		this.tvSwypingText = (TextView) viewPrayer
				.findViewById(R.id.prayer_tvSwypingText);
		this.layoutSwiping = (ViewGroup) viewPrayer
				.findViewById(R.id.prayer_layoutSwyping);
		this.layoutSwiped = (ViewGroup) viewPrayer
				.findViewById(R.id.prayer_layoutSwyped);
		this.pgLoading = viewPrayer.findViewById(R.id.prayer_pbLoading);

		// Set string
		strPullToPray = viewPrayer.getContext().getString(
				R.string.prayer_lblPullToPray);
		strReleaseToPray = viewPrayer.getContext().getString(
				R.string.prayer_lblReleaseToPray);

		// Set add to my list button click listener
		viewPrayer.findViewById(R.id.prayer_btnAddToMyList).setOnClickListener(
				new AddToMyListManager());

		// Create handler
		mainHandler = new Handler(viewPrayer.getContext().getMainLooper());
	}

	public boolean swipeDetected() {
		return mSwipeDetected != Action.None;
	}

	public Action getAction() {
		return mSwipeDetected;
	}

	public boolean onTouch(View v, MotionEvent event) {
		if (startAcceptanceZone == -1) {
			int width = viewPrayer.getWidth();
			int zoneByWith = (int) (0.78f * width);
			int zoneByButton = width - viewPray.getWidth();
			startAcceptanceZone = Math.min(zoneByWith, zoneByButton);
			relaseZone = viewPrayer.getWidth();
			leftPadding = viewPrayer.getLeft();
		}
		Log.i("startAcceptanceZone", startAcceptanceZone + "");

		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN: {
			downX = event.getRawX() - leftPadding;

//			if (downX <= (0.2 * viewPrayer.getWidth())) {
				Log.i(logTag, "Dragging");
				mSwipeDetected = Action.Dragging;
				dragView(downX, false);

				// Set up scroll view
				viewPrayer.requestDisallowInterceptTouchEvent(true);
				prevX = downX;
				return true;
//			} else {
//				mSwipeDetected = Action.None;
//			}
//			break;
		}
		case MotionEvent.ACTION_MOVE: {
			if(mSwipeDetected.equals(Action.Dragging)) {
				currX = event.getRawX() - leftPadding;

				float deltaX = Math.abs(currX - prevX);
				if (deltaX >= MIN_DISTANCE) {
					Log.i(logTag, "Make dragging " + currX);
					dragView(currX, false);
					prevX = currX;
				}
				return true;
			}
			break;
		}
		case MotionEvent.ACTION_UP: {
			upX = event.getRawX() - leftPadding;

			if (mSwipeDetected.equals(Action.Dragging)) {
				Log.i(logTag, "Stop dragging");
				if (upX >= startAcceptanceZone) {
					Log.i(logTag, "Let's pray");
					dragView(relaseZone, true);
				} else {
					Log.i(logTag, "Npray");
					dragView(0, false);
				}

				// Set up scroll view;
				viewPrayer.requestDisallowInterceptTouchEvent(false);

				return true;
			}
			break;
		}
		}
		return false;
	}

	private void dragView(float x, final boolean verifyEnd)  {
		if(x == 0 || (x == relaseZone)) {
			drawViewWithAnimation(x, verifyEnd);
		} else {
			drawViewWithoutAnimation(x, verifyEnd);
		}
	}
		
	private void drawViewWithAnimation(float x, final boolean verifyEnd) {
		if (anim != null && anim.isRunning()) {
			// anim.cancel();
			anim.end();
		}
		
		// Calc values
//		x = Math.min(startAcceptanceZone, x);
		int widthSwipeInfo = viewPrayerSwipeInfo.getMeasuredWidth();
		long totalDistance = Math.abs((long) (x) - widthSwipeInfo);
		long timeForAnimation = totalDistance / SPEED;
		timeForAnimation = Math.min(timeForAnimation, MAX_DURATION);
		
		// Set animation
		anim = ValueAnimator.ofFloat(widthSwipeInfo, x);
		anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
			@Override
			public void onAnimationUpdate(ValueAnimator valueAnimator) {
				float value = (Float) valueAnimator.getAnimatedValue();
				drawViewWithoutAnimation(value, verifyEnd);
			}
		});
		anim.setDuration(timeForAnimation);
		anim.start();
	}
	
	private void drawViewWithoutAnimation(float value, final boolean verifyEnd) {
		int val = (int) value;
		
		ViewGroup.LayoutParams layoutParams = viewPrayerSwipeInfo
				.getLayoutParams();
		layoutParams.width = val;
		viewPrayerSwipeInfo.setLayoutParams(layoutParams);

		if (verifyEnd) {
			if (value == relaseZone) {
				new AddLikeToPrayerAsyncTask().execute((Void) null);
			}
		} else {
			// Set text
			if (value >= startAcceptanceZone) {
				tvSwypingText.setText(strReleaseToPray);
			} else {
				tvSwypingText.setText(strPullToPray);
			}
			
			if(value == 0) {
				layoutSwiping.setVisibility(View.VISIBLE);
				layoutSwiped.setVisibility(View.INVISIBLE);
				pgLoading.setVisibility(View.INVISIBLE);						
			}
		}

	}

	private Runnable closeSwipedViewGroupRunnable = new Runnable() {
		@Override
		public void run() {
			viewPray.setVisibility(View.GONE);
			viewPrayer.setOnTouchListener(null);
			dragView(0, false);
		}
	};

	/**
	 * 
	 * @author Byron
	 * 
	 */
	class AddLikeToPrayerAsyncTask extends
			AsyncTask<Void, Void, AddLikeResponse> {
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			layoutSwiping.setVisibility(View.INVISIBLE);
			layoutSwiped.setVisibility(View.INVISIBLE);
			pgLoading.setVisibility(View.VISIBLE);
		}

		@Override
		protected AddLikeResponse doInBackground(Void... params) {

			AddLikeResponse response = WSAddLike.addLike(
					viewPrayer.getContext(), prayer.getId());

			if (MasterService.isFailedConnection()) {
				cancel(true);
			}

			return response;
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();

			Toast.makeText(viewPrayer.getContext(),
					MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();

			layoutSwiping.setVisibility(View.VISIBLE);
			layoutSwiped.setVisibility(View.INVISIBLE);
			pgLoading.setVisibility(View.INVISIBLE);
			dragView(0, false);
		}

		@Override
		protected void onPostExecute(AddLikeResponse response) {

//			ViewGroup layoutSwiped = (ViewGroup) viewPrayer
//					.findViewById(R.id.prayer_layoutSwyped);
//			View pgLoading = viewPrayer.findViewById(R.id.prayer_pbLoading);
			
			if (response.isLiked()) {
				
				if(prayer.isInMyList()) {
					layoutSwiped.findViewById(R.id.prayer_lblAlreadyOnMyList).setVisibility(View.VISIBLE);
					layoutSwiped.findViewById(R.id.prayer_btnAddToMyList).setVisibility(View.GONE);
				} else {
					layoutSwiped.findViewById(R.id.prayer_lblAlreadyOnMyList).setVisibility(View.GONE);
					layoutSwiped.findViewById(R.id.prayer_btnAddToMyList).setVisibility(View.VISIBLE);
				}
				
				pgLoading.setVisibility(View.INVISIBLE);
				layoutSwiped.setVisibility(View.VISIBLE);

				// Set prayer likes count
				prayer.setLikesCount(response.getPrayer().getLikesCount());
				prayer.setLikeAvailable(response.getPrayer().isLikeAvailable());
				prayer.setLiked(response.getPrayer().isLiked());
				if (prayer.isLikeAvailable()) {
					viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer,
							viewPrayer));
				} else {
					viewPrayer.setOnTouchListener(null);
					viewPray.setVisibility(View.GONE);
				} 
				// Set prayer likes count
				((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer))
						.setText(Integer.toString(prayer.getLikesCount()));
				
				// Start countdown
				mainHandler.postDelayed(closeSwipedViewGroupRunnable,
						15000);
			} else {
				Toast.makeText(viewPrayer.getContext(),
						response.getMessage(), Toast.LENGTH_SHORT).show();
				
				layoutSwiping.setVisibility(View.VISIBLE);
				layoutSwiped.setVisibility(View.INVISIBLE);
				pgLoading.setVisibility(View.INVISIBLE);
				dragView(0, false);
			}
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class AddToMyListManager implements OnClickListener {

		@Override
		public void onClick(View v) {
			mainHandler.removeCallbacks(closeSwipedViewGroupRunnable);
			// Add new
			new AddToMyListActionDialog((Activity) viewPrayer.getContext())
					.init();
		}
	}

	public class AddToMyListActionDialog extends
			ActionDialog<PrayerListAddResponse> {

		public AddToMyListActionDialog(Activity context) {
			super(context);
		}

		@Override
		public PrayerListAddResponse performAction() {
			return WSPrayerListAdd.addToPrayerList(context, prayer.getId());
		}

		@Override
		public void afterAction(PrayerListAddResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
						context);
				mainHandler.postDelayed(closeSwipedViewGroupRunnable,
						15000);
				return;
			}

			// Show success message
			Toast.makeText(context,
					context.getString(R.string.prayer_msgAddToMyList),
					Toast.LENGTH_SHORT).show();
			prayer.setInMyList(!response.isInMyList());
			viewPray.setVisibility(View.GONE);
			viewPrayer.setOnTouchListener(null);
			dragView(0, false);
		}

	}
}