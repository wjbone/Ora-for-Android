package net.ora.mobile.android.profile;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.OraButton;
import net.ora.mobile.android.util.ImageDownloader;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSRequestFriend;
import net.ora.mobile.android.webservices.profile.WSSug;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;
import android.app.Activity;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.RequestFriendUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class MyContactFiendsContactsListAdapter extends BaseAdapter {

	private static final String TAG_LOG = "MyContactFiendsContactsListAdapter";

	private Activity context;
	private List<RequestFriendUser> users;
	private int width;
	private String strButton;
	private ImageDownloader imageDownloader;

	public MyContactFiendsContactsListAdapter(Activity context, List<RequestFriendUser> users, Bitmap defaultBitmap,
			String strButton) {
		this.context = context;
		this.strButton = strButton;
		// Filter users list
		this.users = filterUsersList(users);

		// Set up instance data
		width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(context);
		imageDownloader = new ImageDownloader(context, context.getResources(), defaultBitmap);
	}

	private List<RequestFriendUser> filterUsersList(List<RequestFriendUser> users) {
		List<RequestFriendUser> filteredUsers = new ArrayList<RequestFriendUser>();

		User currentUser = ((OraApplication) context.getApplication()).getUser();
		if (users != null) {
			for (final RequestFriendUser user : users) {
				// Make filter
				if ((!user.isFriend()) && (!user.isRequested()) && (!user.equals(currentUser))) {
					filteredUsers.add(user);
				}
			}
		}
		
		return filteredUsers;
	}

	@Override
	public int getCount() {
		int count = 0;
		if (users != null) {
			count = users.size();
		}
		return count;
	}

	@Override
	public Object getItem(int position) {
		return users.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		RequestFriendUserViewHolder holder;

		if (view == null) {
			LayoutInflater inflater = LayoutInflater.from(parent.getContext());

			view = inflater.inflate(R.layout.item_friend, null);

			holder = new RequestFriendUserViewHolder();
			holder.friendPicture = ((ImageView) view.findViewById(R.id.iv_item_friend_image));
			holder.circlePicture = (ImageView) view.findViewById(R.id.iv_friends_Cirle);
			holder.tvName = ((TextView) view.findViewById(R.id.tv_item_friend_name));
			holder.button = ((OraButton) view.findViewById(R.id.b_item_friend_button));

			// Configure views
			holder.friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.button.setText(strButton);

			// Save holder for later
			view.setTag(holder);

		} else {
			holder = (RequestFriendUserViewHolder) view.getTag();

			if (holder.position == position) {
				return view;
			}
		}

		// Set data
		RequestFriendUser user = users.get(position);
		holder.tvName.setText(user.getName());
		holder.button.setOnClickListener(new AddFriendViewManager(user));
		// Profile picture
		if (user.getPicture() != null) {
			Log.i(TAG_LOG, user.getPicture());
			imageDownloader.download(user.getPicture(), holder.friendPicture);
		}

		// Return
		return view;
	}

	/*
	 * 
	 */
	public static class RequestFriendUserViewHolder {
		public int position;
		public ImageView friendPicture;
		public ImageView circlePicture;
		public TextView tvName;
		public OraButton button;

	}

	/*
	 * 
	 */
	public class AddFriendViewManager implements OnClickListener {

		private RequestFriendUser user;

		public AddFriendViewManager(RequestFriendUser user) {
			this.user = user;
		}

		@Override
		public void onClick(View v) {
			if ((!user.isFriend()) && (!user.isRequested())) {
				new RequestFriendDialog(context, user).init();
			}
		}
	}

	/*
	 * 
	 */
	public class RequestFriendDialog extends ActionDialog<RequestFriendResponse> {

		private RequestFriendUser user;

		public RequestFriendDialog(Activity context, RequestFriendUser user) {
			super(context);
			this.user = user;
		}

		@Override
		public RequestFriendResponse performAction() {
			return WSRequestFriend.requestFriend(context, user.getId());
		}

		@Override
		public void afterAction(RequestFriendResponse result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				users.remove(user);
				notifyDataSetChanged();
			}
		}

	}
}
