package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.FriendListResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSFriendsList extends MasterService {

	private static final String URL = "friends_list/";
	private static FriendListResponse response;
	
	public static FriendListResponse getResponse() {
		return response;
	}
	
	public static void findFriends(Context context, String user_id){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("user_id", user_id));
			
			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< FriendListResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
