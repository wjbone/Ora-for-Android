package net.ora.mobile.android.webservices.circles;

import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.GetCircleProfileResponse;

public class WSEditCircleProfile extends MasterService {

	
private static final String URL = "edit_circle_profile/";
	
	public static Circle editCircleProfile(Context context, int circleId, String name, String picture) {

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("circle_id", Integer
					.toString(circleId)));
			request.add(new BasicNameValuePair("name", name));
			request.add(new BasicNameValuePair("picture", picture));

			// Make request
			GetCircleProfileResponse response = makeRequest(context,
					CONNECTION_TYPE.POST, URL, request,
					new TypeReference<GetCircleProfileResponse>() {
					});

			 return response.getCircle();
		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}

		return null;
	}
}
