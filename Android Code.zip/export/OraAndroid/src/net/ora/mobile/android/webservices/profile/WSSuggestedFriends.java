package net.ora.mobile.android.webservices.profile;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.request.PhoneFacebookContacts;

import android.content.Context;

import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.RequestFriendUser;

public class WSSuggestedFriends {

	public static List<RequestFriendUser> getSuggestedFriend(Context context, PhoneFacebookContacts contactsRequest) {
		// Get Ora users
		WSSug.searchSug(context, contactsRequest);

		if (!MasterService.isFailedConnection()) {
			// Master Service
			WSSuggestedUsers.findSuggestions(context);

			if (!MasterService.isFailedConnection()) {
				List<RequestFriendUser> tempUsers = new ArrayList<RequestFriendUser>();
				for (RequestFriendUser tempUser : WSSug.getResponse().getUsers()) {
					tempUsers.add(tempUser);
				}
				for (FriendUser tempUser : WSSuggestedUsers.getResponse().getFriendsList()) {
					tempUsers.add(new RequestFriendUser(tempUser));
				}

				// Return list of friends
				return tempUsers;
			}
		}

		return null;
	}
}
