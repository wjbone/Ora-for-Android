package net.ora.mobile.android.webservices.friends;

import java.io.IOException;
import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.FriendListResponse;
import android.content.Context;

public class WSFriendsFriendList extends MasterService {

	private static final String URL = "friends_list/";
	
	public static FriendListResponse findFriendsFriend(Context context, String user_id){
		FriendListResponse result = null;
		
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("user_id", user_id));
			
			result = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< FriendListResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
		
		return result;
	}

}
