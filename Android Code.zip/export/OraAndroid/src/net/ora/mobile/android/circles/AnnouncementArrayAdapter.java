package net.ora.mobile.android.circles;

import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.dto.prayers.Prayer;
import android.content.Context;
import android.text.Html;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImage;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

public class AnnouncementArrayAdapter extends ArrayAdapter<Prayer> {

	public static final String TAG = "AnnouncementArrayAdapter";
	private static final int MAX_CHARS_PER_ANNOUNCEMENT = 200;

	private BaseImageData fragment;
	private int width;

	public AnnouncementArrayAdapter(Context context, BaseImageData fragment, List<Prayer> notifications) {
		super(context, 0, notifications);

		// Instance data
		this.fragment = fragment;
		width = GeneralMethods.getProfileImageWidth(getContext());
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		final Prayer prayer = getItem(position);
		ViewHolder holder;

		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(getContext());
			convertView = inflater.inflate(R.layout.item_announcement, null);

			holder = new ViewHolder();
			convertView.setTag(holder);

			// References to the views
			holder.friendPicture = ((ImageView) convertView.findViewById(R.id.iv_profile));
			holder.circlePicture = (ImageView) convertView.findViewById(R.id.iv_profile_overlay);
			holder.tvProfileName = (TextView) convertView.findViewById(R.id.tv_profile_name_prayer);
			holder.tvDateCreated = (TextView) convertView.findViewById(R.id.tv_pray_time);
			holder.tvText = (TextView) convertView.findViewById(R.id.tv_profile_text_prayer);
			holder.tvComments = (TextView) convertView.findViewById(R.id.tv_profile_comments_prayer);

			// Set profile image size
			holder.friendPicture.setLayoutParams(new FrameLayout.LayoutParams(width, width));
			holder.circlePicture.setLayoutParams(new FrameLayout.LayoutParams(width, width));
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		// Build text
		String text = prayer.getText();

		// Set text and images
		holder.tvProfileName.setText(prayer.getCircles().get(0).getName());
		holder.tvDateCreated.setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));
		if (text.length() <= MAX_CHARS_PER_ANNOUNCEMENT) {
			holder.tvText.setText(text);
		} else {
			holder.tvText.setText(Html.fromHtml(getContext().getString(R.string.announcement_msgTextCropped,
					text.substring(0, MAX_CHARS_PER_ANNOUNCEMENT))));
		}
		holder.tvComments.setText(Integer.toString(prayer.getCommentsCount()));

		// Load image task
		AsyncDownloadImage async = new AsyncDownloadImage(TAG, getContext(), fragment);
		fragment.getAsyncTaskList().add(async);
		String url = prayer.getCircles().get(0).getPicture();
		holder.friendPicture.setTag(url);
		async.execute(new Pair<String, ImageView>(url, holder.friendPicture));

		// Return view
		return convertView;
	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class ViewHolder {
		public ImageView friendPicture;
		public ImageView circlePicture;
		public TextView tvProfileName;
		public TextView tvDateCreated;
		public TextView tvText;
		public TextView tvComments;
	}
}
