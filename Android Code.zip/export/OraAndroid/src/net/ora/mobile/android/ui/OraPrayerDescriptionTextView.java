package net.ora.mobile.android.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;

/**
 * 
 * @author byron
 * 
 */
public class OraPrayerDescriptionTextView extends OraTextView {

	public static final int MAX_LINES = 5;

	public OraPrayerDescriptionTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public OraPrayerDescriptionTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public OraPrayerDescriptionTextView(Context context) {
		super(context);
	}

	@Override
	protected void init(Context context) {
		// Super
		super.init(context);

		// Add Listener For Lines
		ViewTreeObserver vto = getViewTreeObserver();
		vto.addOnGlobalLayoutListener(new OraPrayerDescriptionOnGlobalLayoutListener());

	}

	public class OraPrayerDescriptionOnGlobalLayoutListener implements OnGlobalLayoutListener {
		@Override
		public void onGlobalLayout() {
			// Verify lines count
			if (getLineCount() > MAX_LINES) {
				Log.d("", "Line[" + getLineCount() + "]" + getText());
				int lineEndIndex = getLayout().getLineEnd(MAX_LINES - 1);
				String text = getText().subSequence(0, lineEndIndex - 3) + "...";
				setText(text);
				Log.d("", "NewText:" + text);
			}
			
			// Clear the global listener
//			clearLayoutListener();
		}

		public void clearLayoutListener() {
			if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
				clearLayoutListenerBeforeJellyBean();
			} else {
				clearLayoutListenerSinceJellyBean();
			}
		}

		@SuppressWarnings("deprecation")
		public void clearLayoutListenerBeforeJellyBean() {
			ViewTreeObserver obs = getViewTreeObserver();
			obs.removeGlobalOnLayoutListener(this);
		}

		@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
		public void clearLayoutListenerSinceJellyBean() {
			ViewTreeObserver obs = getViewTreeObserver();
			obs.removeOnGlobalLayoutListener(this);
		}
	}
}