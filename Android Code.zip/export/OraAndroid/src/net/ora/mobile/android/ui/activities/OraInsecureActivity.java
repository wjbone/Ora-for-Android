package net.ora.mobile.android.ui.activities;

import net.ora.mobile.android.InitialActivity;
import net.ora.mobile.android.R;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockActivity;
import com.actionbarsherlock.view.MenuItem;

public class OraInsecureActivity extends SherlockActivity {
	
	private TextView titleView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActionBar _actionBar = getSupportActionBar();

		_actionBar.setDisplayHomeAsUpEnabled(true);
		_actionBar.setDisplayShowTitleEnabled(false);
		_actionBar.setDisplayShowCustomEnabled(true);

		// Save action bar title view
		_actionBar.setCustomView(R.layout.custom_action_layout);
		View customView = _actionBar.getCustomView();
		titleView = (TextView) customView
				.findViewById(R.id.action_custom_title);
	}

	@Override
	protected void onResume() {
		super.onResume();

		// Facebook tracking
		com.facebook.Settings.publishInstallAsync(this, getString(R.string.applicationId));
	}
	
	@Override
	public void setTitle(int titleId) {
		super.setTitle(titleId);
		titleView.setText(titleId);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;
		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}
	
	@Override
	public void finish() {
		Intent intent = new Intent(this, InitialActivity.class);
		startActivity(intent);
		super.finish();
	}
	
	public void close() {
		super.finish();
	}
}
