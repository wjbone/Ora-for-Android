package net.ora.mobile.android.webservices.activity;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.activity.response.CircleInviteAcceptResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCircleInviteAccept extends MasterService {

	public static final String URL = "circle_invite_accept/";
	private static CircleInviteAcceptResponse response;

	public static CircleInviteAcceptResponse getResponse() {
		return response;
	}
	
	public static void acceptInvitation(Context context, String circleId){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("circle_id", circleId));
			
			response = makeRequest(context, CONNECTION_TYPE.POST, URL, request, 
					new TypeReference< CircleInviteAcceptResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
