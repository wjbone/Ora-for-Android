package net.ora.mobile.android.profile;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSFriendsList;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageSearchFriends;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class MyFriendsListFragments extends FragmentImageData {
	
	private LinearLayout friendsList;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		
		String name = ((OraApplication) getActivity().getApplication()).getUser().getName();
		if((name == null) || (name.trim().length() == 0)){
			name = ((OraApplication) getActivity().getApplication()).getUser().getUsername();
		}
		int index = name.indexOf(" ");
		getActivity().setTitle(name.substring(0, ((index != -1 ? index : name.length()))) + "'s Friends");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.list_friend_list, container, false);
		
		friendsList = (LinearLayout) view.findViewById(R.id.ly_list_friends_list);
		new LoadFriendsActionDialog(getActivity()).init();
		
		return view;
	}
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		
		SubMenu sub = menu.addSubMenu(0, 0, Menu.NONE, "Add Friends");
		sub.setIcon(R.drawable.ic_add);
		sub.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		super.onOptionsItemSelected(item);
		pushFragment(new MyContactFriendsFragments());
		return false;
	}
	
	public class LoadFriendsActionDialog extends ActionDialog<Void> {
		
		public LoadFriendsActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			Log.i("consult", "frineds");
			WSFriendsList.findFriends(getActivity(), Integer.toString(((OraApplication) getActivity().getApplication()).getUser().getId()));
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
				
				LayoutInflater inflater = LayoutInflater.from(getActivity());
				
				for(final FriendUser temp : WSFriendsList.getResponse().getFriendsList()){
					final View convertView = inflater.inflate(R.layout.item_friend_list, null);
					final TextView div = GeneralMethods.createLine(R.color.friends_div_line, getActivity());
					
					ImageView friendPicture = ((ImageView) convertView.findViewById(R.id.iv_item_friend_image));
					ImageView circlePicture = (ImageView) convertView.findViewById(R.id.iv_friends_Cirle);
					
					friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					
					pictureImageViewList.add(friendPicture);
					circleImageViewList.add(circlePicture);
					
					((TextView) convertView.findViewById(R.id.tv_item_friend_name)).setText(temp.getName());
					
					ImageButton button = ((ImageButton) convertView.findViewById(R.id.b_item_friend_button));
					if(temp.isFriend()){
						button.setImageResource(R.drawable.ic_check_green);
					}else if(temp.isRequested()){
						button.setImageResource(R.drawable.ic_check_gray_pending);
					}else{
						button.setImageResource(R.drawable.ic_add_request);
					}
					
					convertView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(getActivity(), ProfileFriendActivity.class);
							intent.putExtra("friend_id", temp.getId());
							getActivity().startActivity(intent);
						}
					});
					
					friendsList.addView(convertView);
					friendsList.addView(div);
					friendsList.invalidate();
				}
				
				AsyncDownloadImageSearchFriends async = new AsyncDownloadImageSearchFriends("MyFriendsListFragmets", context, MyFriendsListFragments.this);
				async.setListPictures(pictureImageViewList);
				
				asyncTaskList.add(async);
				
				async.execute(WSFriendsList.getResponse().getFriendsList());
			}
		}
		
	}
	
}
