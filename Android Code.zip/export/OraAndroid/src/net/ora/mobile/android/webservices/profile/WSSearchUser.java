package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.SearchUserResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSSearchUser extends MasterService {

	private static final String URL = "search_u/";
	private static SearchUserResponse response;
	
	public static SearchUserResponse getResponse(){
		return response;
	}
	
	public static void searchForUser(Context context, String name, String city, String page){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("q", name));
			request.add(new BasicNameValuePair("page", page));
			request.add(new BasicNameValuePair("city", city));

			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< SearchUserResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
