package net.ora.mobile.android.friends;

import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.fragment.FriendsPrayersFragment;
import net.ora.mobile.android.ui.OraTextView;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.friends.WSGetFriendProfile;
import net.ora.mobile.dto.friend.response.GetFriendProfileResponse;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.asynctask.ObtainProfilePrayersAsync;
import com.digitalgeko.mobile.android.helpers.profile.ProfileGestureDetector;
import com.digitalgeko.mobile.android.objects.friends.ActivityImageData;
import com.digitalgeko.mobile.android.objects.friends.BlockUserDialog;
import com.digitalgeko.mobile.android.objects.friends.BreakFriendshipDialog;
import com.digitalgeko.mobile.android.objects.friends.CancelFriendRequestDialog;
import com.digitalgeko.mobile.android.objects.friends.RequestFriendsDialog;
import com.digitalgeko.mobile.android.objects.friends.UnblockUserDialog;
import com.digitalgeko.mobile.android.ui.ActionDialog;

@SuppressWarnings("deprecation")
public class ProfileFriendActivity extends ActivityImageData {

	private int friend_id;
	private GetFriendProfileResponse response = null;

	private List<View> headersList;
	private ImageView imageBackgroundPicture, userPicture, imageBackgroundAbout;
	private LinearLayout pictureMargin, prayersList, profileSwitch;
	private OraTextView prayersCount, friendsCount, circlesCount, aboutText, cityText;
	private Button kindFriend;
	private GestureDetector mGestureDetector;
	private View.OnTouchListener mGestureListener;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile_main);

		setDownloadFlag(true);
		friend_id = getIntent().getExtras().getInt("friend_id");

		if (friend_id != ((OraApplication) getApplication()).getUser().getId()) {
			((LinearLayout) findViewById(R.id.ly_btn_friend)).setVisibility(View.VISIBLE);
		}

		int background_heigth = GeneralMethods.getProfileBackgroundWidth(this);
		int picture_width = (int) (background_heigth * 0.75);

		kindFriend = (Button) findViewById(R.id.btn_add_reject_friend);

		profileSwitch = (LinearLayout) findViewById(R.id.ly_profile_swype);
		prayersList = (LinearLayout) findViewById(R.id.ly_profile_prayers_list);

		prayersCount = (OraTextView) findViewById(R.id.tv_Count_Prayers);
		friendsCount = (OraTextView) findViewById(R.id.tv_Count_Friends);
		circlesCount = (OraTextView) findViewById(R.id.tv_Count_Circles);

		((LinearLayout) findViewById(R.id.layoutPrayers)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				goToAllPrayers();
			}
		});

		((LinearLayout) findViewById(R.id.layoutFriends)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(ProfileFriendActivity.this, FriendsListFriendActivity.class);
				intent.putExtra("friend_id", response.getProfileUser().getId());
				intent.putExtra("friend_name", response.getProfileUser().getRealName());
				startActivity(intent);
			}
		});

		((LinearLayout) findViewById(R.id.layoutCircles)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(ProfileFriendActivity.this, CirclesListFriendActivity.class);
				intent.putExtra("friend_id", response.getProfileUser().getId());
				startActivity(intent);
			}
		});

		LayoutInflater inflater = LayoutInflater.from(this);

		/* ***********************************************************************************************************************
		 * obtaining the profile picture view
		 * **********************************************************************************************************************
		 */

		View headerPictureView = inflater.inflate(R.layout.profile_header_image, null);

		imageBackgroundPicture = (ImageView) headerPictureView.findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		userPicture = (ImageView) headerPictureView.findViewById(R.id.iv_Profile_Picture);
		userPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		pictureMargin = (LinearLayout) headerPictureView.findViewById(R.id.ly_Profile_Margin_Picture);
		pictureMargin.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		/* ***********************************************************************************************************************
		 * obtaining the profile information view
		 * **********************************************************************************************************************
		 */

		View headerDescriptionView = inflater.inflate(R.layout.profile_header_description, null);

		imageBackgroundAbout = (ImageView) headerDescriptionView.findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundAbout.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		aboutText = (OraTextView) headerDescriptionView.findViewById(R.id.tv_profile_about);
		cityText = (OraTextView) headerDescriptionView.findViewById(R.id.tv_profile_city);

		/* ***********************************************************************************************************************
		 * Setting the Gesture Detector for Swipe
		 * **********************************************************************************************************************
		 */

		headersList = Arrays.asList(headerPictureView, headerDescriptionView);

		mGestureDetector = new GestureDetector(new ProfileGestureDetector(profileSwitch, headersList));
		mGestureListener = new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				return mGestureDetector.onTouchEvent(event);
			}
		};

		profileSwitch.setOnTouchListener(mGestureListener);
		profileSwitch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// to detect the swipe.
			}
		});

		/* ***********************************************************************************************************************
		 * Connecting with the server
		 * **********************************************************************************************************************
		 */

		new LoadProfileActionDialog(this).init();
	}

	private Menu menu;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		if (friend_id != ((OraApplication) getApplication()).getUser().getId()) {
			getSupportMenuInflater().inflate(R.menu.friends_menu, menu);
		}
		this.menu = menu;
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		if (item.getItemId() == R.id.blockUser) {

			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("Are you sure?");

			if (response.getProfileUser().isBlocked()) {
				builder.setTitle(getString(R.string.profile_friend_unblock));
			} else {
				builder.setTitle(getString(R.string.profile_friend_block));
			}

			builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
					if (response.getProfileUser().isBlocked()) {
						new UnblockUserDialog(ProfileFriendActivity.this, menu, response.getProfileUser()).init();
					} else {
						new BlockUserDialog(ProfileFriendActivity.this, menu, response.getProfileUser()).init();
					}
				}
			});

			builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
				}
			});

			builder.create().show();

		}
		return true;
	}

	@Override
	public void onPause() {
		super.onPause();

	}

	@Override
	public void onResume() {
		super.onResume();

	}

	@Override
	public void goToAllPrayers() {
		Intent intent = new Intent(ProfileFriendActivity.this, PrayersListFriendActivity.class);
		intent.putExtra("friend_id", response.getProfileUser().getId());
		intent.putExtra("friend_name", response.getProfileUser().getRealName());
		intent.putExtra("friend_picture", response.getProfileUser().getProfilePicture());
		intent.putExtra(FriendsPrayersFragment.TAG_FRIEND, response.getProfileUser());
		startActivity(intent);
	}

	/* ***********************************************************************************************************************
	 * My Own Methods
	 * **********************************************************************************************************************
	 */

	public void addRejectFriendClick(View v) {
		if (response.getProfileUser().isFriend()) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);

			builder.setTitle("Are you sure?");
			builder.setMessage("This will remove " + response.getProfileUser().getRealName() + " from your friends list");

			builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
					new BreakFriendshipDialog(ProfileFriendActivity.this, kindFriend, response.getProfileUser()).init();
				}
			});

			builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
				}
			});

			builder.create().show();
		} else if (response.getProfileUser().isRequested()) {
			new CancelFriendRequestDialog(this, kindFriend, response.getProfileUser()).init();
		} else {
			new RequestFriendsDialog(this, kindFriend, response.getProfileUser()).init();
		}
	}

	/* ***********************************************************************************************************************
	 * ActionDialogs
	 * **********************************************************************************************************************
	 */

	public class LoadProfileActionDialog extends ActionDialog<GetFriendProfileResponse> {

		public LoadProfileActionDialog(Activity context) {
			super(context);
		}

		@Override
		public GetFriendProfileResponse performAction() {
			return WSGetFriendProfile.getFriendProfile(context, Integer.toString(friend_id));
		}

		@Override
		public void afterAction(GetFriendProfileResponse result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				response = result;
				if (result.getProfileUser() != null) {
					setTitle(result.getProfileUser().getRealName());

					if (result.getProfileUser().isFriend()) {
						kindFriend.setText(getString(R.string.profile_friend_is));
					} else if (result.getProfileUser().isRequested()) {
						kindFriend.setText(getString(R.string.profile_friend_pending));
					} else {
						kindFriend.setText(getString(R.string.profile_friend_add));
					}

					if (friend_id != ((OraApplication) getApplication()).getUser().getId()) {
						if (result.getProfileUser().isBlocked()) {
							menu.findItem(R.id.blockUser).setTitle(getString(R.string.profile_friend_unblock));
						} else {
							menu.findItem(R.id.blockUser).setTitle(getString(R.string.profile_friend_block));
						}
					}

					prayersCount.setText(Integer.toString(result.getProfileUser().getPrayersCount()));
					friendsCount.setText(Integer.toString(result.getProfileUser().getFriendsCount()));
					// circlesCount.setText(Integer.toString(result.getProfileUser().getCirclesUsed()));
					circlesCount.setText(Integer.toString(result.getProfileUser().getRelatedCirclesCount()));
					aboutText.setText(result.getProfileUser().getAbout());
					cityText.setText(result.getProfileUser().getCity());

					if (result.getProfileUser().getProfilePicture().trim().length() > 0) {
						List<ImageView> pictures = Arrays.asList(userPicture);
						List<ImageView> picturesFaded = Arrays.asList(imageBackgroundPicture, imageBackgroundAbout);

						DownloadProfilePicture asyncJob = new DownloadProfilePicture(ProfileFriendActivity.this,
								ProfileFriendActivity.this, pictures, picturesFaded, "ProfileFriendActivity Profile");
						ProfileFriendActivity.this.getAsyncTaskList().add(asyncJob);
						asyncJob.execute(result.getProfileUser().getProfilePicture().trim());

						userPicture.setVisibility(View.VISIBLE);
						pictureMargin.setBackgroundResource(R.drawable.profile_image_margin);
						pictureMargin.invalidate();
					}

					if (result.getProfileUser().getPrayersCount() > 0) {
						LayoutInflater inflater = LayoutInflater.from(context);
						prayersList.addView(inflater.inflate(R.layout.item_loading, null));

						ObtainProfilePrayersAsync asyncJob = new ObtainProfilePrayersAsync((OraApplication) getApplication(),
								getContext(), prayersList, ProfileFriendActivity.this, result.getProfileUser(), true);
						getAsyncTaskList().add(asyncJob);
						asyncJob.execute(new Void[] { null });
					}
				} else {
					GeneralMethods.crearDialogoOk(result.getMessage(), context);
				}
			}
		}

	}

}
