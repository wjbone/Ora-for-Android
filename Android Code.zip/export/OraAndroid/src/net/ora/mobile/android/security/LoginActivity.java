package net.ora.mobile.android.security;

import net.ora.mobile.android.MainActivity;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraInsecureActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.security.WSLogin;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class LoginActivity extends OraInsecureActivity {

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.activity_login);
		setTitle(R.string.login_title);
	}
	
	public void onLoginClick(View view) {
		new LoginActionDialog(this).init();
	}
	
	public void onGoToResetPasswordClick(View view) {
		Intent intent = new Intent(this, ResetPasswordActivity.class);
		
		String username = ((TextView) findViewById(R.id.login_txtEmail)).getText().toString();
		intent.putExtra(ResetPasswordActivity.TAG_EMAIL, username);
		
		startActivity(intent);
	}
	
	public class LoginActionDialog extends ActionDialog<User> {

		public LoginActionDialog(Activity context) {
			super(context);
		}

		@Override
		public User performAction() {
			String username = ((TextView) findViewById(R.id.login_txtEmail)).getText().toString();
			String password = ((TextView) findViewById(R.id.login_txtPassword)).getText().toString();
			
			return WSLogin.auth((OraApplication) getApplication(), getContext(), username, password);
		}

		@Override
		public void afterAction(User user) {
			if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				// Save user data
				((OraApplication)getApplication()).setUser(user);
				
				// Load main activity
				startActivity(new Intent(context, MainActivity.class));
				//startActivity(new Intent(context, RegisterContactFriendsActivity.class));
				close();
			}
		}
	}
	
}
