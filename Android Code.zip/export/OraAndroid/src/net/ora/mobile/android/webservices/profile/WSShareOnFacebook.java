package net.ora.mobile.android.webservices.profile;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Toast;

import com.facebook.FacebookRequestError;
import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.RequestAsyncTask;
import com.facebook.Response;
import com.facebook.Session;

public final class WSShareOnFacebook {

	public static final String TAG = "WSShareOnFacebok";
	private static final String MY_PHOTOS = "me/photos";
	private static final String PICTURE_PARAM = "picture";

	private static final List<String> PERMISSIONS = Arrays.asList("publish_actions", "publish_stream", "publish_checkins");

	public static boolean isFacebookLogin() {
		boolean result = false;
		Session session = Session.getActiveSession();
		if (session != null) {
			result = session.isOpened();
		}
		return result;
	}

	public static void share(final Activity activity, String prayer) {
		Session session = Session.getActiveSession();

		List<String> permissions = session.getPermissions();
		if (!isSubsetOf(PERMISSIONS, permissions)) {
			// pendingPublishReauthorization = true;
			Session.NewPermissionsRequest newPermissionsRequest = new Session.NewPermissionsRequest(activity, PERMISSIONS);
			session.requestNewPublishPermissions(newPermissionsRequest);
			return;
		}

		Bundle postParams = new Bundle();
		postParams.putString("message", prayer);

		Request.Callback callback = new Request.Callback() {
			public void onCompleted(Response response) {
				/*
				 * String postId = null; if(response.getGraphObject() != null){ JSONObject graphResponse =
				 * response.getGraphObject().getInnerJSONObject(); try { postId = graphResponse.getString("id"); } catch
				 * (JSONException e) { Log.i(TAG, "JSON error "+ e.getMessage()); } }
				 */
				FacebookRequestError error = response.getError();
				if (error != null) {
					Toast.makeText(activity.getApplicationContext(), "An error has occurred", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(activity.getApplicationContext(), "Successful share on Facebook", Toast.LENGTH_LONG).show();
				}
			}
		};

		Request request = new Request(session, "feed", postParams, HttpMethod.POST, callback);

		RequestAsyncTask task = new RequestAsyncTask(request);
		task.execute();
	}

	public static void shareImage(final Activity context, String message, Bitmap image, final Dialog dialog) {
		Session session = Session.getActiveSession();

		List<String> permissions = session.getPermissions();
		if (!isSubsetOf(PERMISSIONS, permissions)) {
			Session.NewPermissionsRequest newPermissionsRequest = new Session.NewPermissionsRequest(context, PERMISSIONS);
			session.requestNewPublishPermissions(newPermissionsRequest);
			return;
		}
		
		Bundle postParams = new Bundle();
		postParams.putString("message", message);
		postParams.putParcelable(PICTURE_PARAM, image);

		Request.Callback callback = new Request.Callback() {
			public void onCompleted(Response response) {
				// Hide progress dialog (if any)
				if(dialog != null) {
					dialog.dismiss();
				}
				
				FacebookRequestError error = response.getError();
				if (error != null) {
					Toast.makeText(context.getApplicationContext(), "An error has occurred", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(context.getApplicationContext(), "Successfully shared on Facebook", Toast.LENGTH_LONG).show();
				}
			}
		};

//		Request request = Request.newUploadPhotoRequest(session, image, callback);
		Request request = new Request(session, MY_PHOTOS, postParams, HttpMethod.POST, callback);

		RequestAsyncTask task = new RequestAsyncTask(request);
		task.execute();
	}

	private static boolean isSubsetOf(Collection<String> subset, Collection<String> superset) {
		for (String string : subset) {
			if (!superset.contains(string)) {
				return false;
			}
		}
		return true;
	}

}
