package net.ora.mobile.android.circles;

import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.util.ImageDownloader;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSInviteToCircle;
import net.ora.mobile.android.webservices.circles.WSSearchCircleUsers;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.InviteToCircleResponse;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class InviteMembersFragment extends CachedImageDataFragment {

	private Circle circle;

	private View view;
	private EditText etSearchBox;
	private View viewProgressBar;
	// private ViewGroup viewMembersList;
	private ListView viewListMembers;
	private SearchCircleMembersAdapter adapterSearchMembers;

	public static InviteMembersFragment getInstance(Circle circle) {
		InviteMembersFragment fragment = new InviteMembersFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);

		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments().getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}
	}

	@Override
	protected int getActionBarString() {
		return R.string.inviteMembers_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		// Save
		if (circle == null) {
			return null;
		}

		// Inflate View
		view = inflater.inflate(R.layout.fragment_circles_invite_members, container, false);

		// // Friend List
		// viewMembersList = (ViewGroup) view
		// .findViewById(R.id.inviteMembers_layoutList);

		// New List
		viewListMembers = (ListView) view.findViewById(R.id.inviteMembers_lvList);
		adapterSearchMembers = new SearchCircleMembersAdapter();
		viewListMembers.setAdapter(adapterSearchMembers);

		// Progress bar
		viewProgressBar = view.findViewById(R.id.feedPrayers_pbLoading);

		// Search box
		etSearchBox = (EditText) view.findViewById(R.id.et_search);
		etSearchBox.addTextChangedListener(new SearchFeedManager(etSearchBox));

		// Return view
		return view;
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class LoadFriendsTask extends AsyncTask<Void, Void, List<CircleMember>> {

		private Activity context;

		public LoadFriendsTask(Activity context) {
			super();
			this.context = context;
		}

		public Activity getContext() {
			return context;
		}

		@Override
		protected List<CircleMember> doInBackground(Void... params) {
			// Load list
			return WSSearchCircleUsers.getUsers(context, circle.getId(), etSearchBox.getText().toString());
		}

		@Override
		protected void onPostExecute(List<CircleMember> users) {
			viewProgressBar.setVisibility(View.GONE);

			// Validate list
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Users
			adapterSearchMembers = new SearchCircleMembersAdapter();
			adapterSearchMembers.setUsers(users);
			viewListMembers.setAdapter(adapterSearchMembers);
			viewListMembers.setVisibility(View.VISIBLE);

			// AsyncDownloadImageSearchFriends async = new
			// AsyncDownloadImageSearchFriends(
			// "InviteMembersFragmets", getContext(),s
			// InviteMembersFragment.this);
			// async.setListPictures(pictureImageViewList);
			//
			// asyntTaskList.add(async);

			// async.execute(friends);
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class FriendInviteManager implements OnClickListener {

		protected User friend;
		protected View viewFriend;

		public FriendInviteManager(User friend, View viewFriend) {
			this.friend = friend;
			this.viewFriend = viewFriend;
		}

		@Override
		public void onClick(View v) {
			new InviteToFriendActionDialog(getActivity()).init();
		}

		public class InviteToFriendActionDialog extends ActionDialog<InviteToCircleResponse> {

			public InviteToFriendActionDialog(Activity context) {
				super(context);
			}

			@Override
			public InviteToCircleResponse performAction() {
				int userId = friend.getId();
				int circleId = circle.getId();
				return WSInviteToCircle.inviteToCircle(context, userId, circleId);
			}

			@Override
			public void afterAction(InviteToCircleResponse response) {
				if (MasterService.isFailedConnection()) {
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				} else {
					Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
					if (response.isInvited() || response.isRequested() || response.isMember()) {
						// viewMembersList.removeView(viewFriend);

						// adapterSearchMembers = new
						// SearchCircleMembersAdapter();
						// viewListMembers.setAdapter(adapterSearchMembers);
					}
				}
			}
		}
	}

	/*
	 * 
	 */
	public class SearchFeedManager implements TextWatcher {

		private Handler mHandler;
		private EditText etSearch;
		private LoadFriendsTask task;

		public SearchFeedManager(EditText text) {
			this.etSearch = text;
			mHandler = new Handler();
		}

		private Runnable searchRunnable = new Runnable() {
			@Override
			public void run() {
				mHandler.removeCallbacks(searchRunnable);
				if (etSearch.getText().toString().trim().length() > 0) {
					task = new LoadFriendsTask(getActivity());
					asyncTaskList.add(task);
					execute(task);
				}
			}
			
			private void execute(LoadFriendsTask task) {
				if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					executeSinceHoneycomb(task);
				} else {
					task.execute(new Void[0]);
				}
				
			}
			
		    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
			private void executeSinceHoneycomb(LoadFriendsTask task) {
		    	task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
		    }
			
		};

		@Override
		public void afterTextChanged(Editable s) {
			// Stop
			mHandler.removeCallbacks(searchRunnable);
			if (task != null)
				task.cancel(true);

			// Visual
			viewListMembers.setVisibility(View.GONE);

			if (s.length() > 0) {
				viewProgressBar.setVisibility(View.VISIBLE);
				mHandler.postDelayed(searchRunnable, 1000);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}

	public class SearchCircleMembersAdapter extends BaseAdapter {

		private List<CircleMember> users;
		private ImageDownloader imageDownloader;

		public SearchCircleMembersAdapter() {
			Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
			imageDownloader = new ImageDownloader(getActivity(), getResources(), defaultBitmap);
		}

		public void setUsers(List<CircleMember> users) {
			this.users = users;
		}

		@Override
		public int getCount() {
			if (users == null)
				return 0;
			return users.size();
		}

		@Override
		public Object getItem(int arg0) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View view, ViewGroup parent) {
			CircleMember user = users.get(position);

			CircleMemberViewHolder holder;
			View viewMember = view;

			if (view == null) {
				LayoutInflater inflater = LayoutInflater.from(parent.getContext());
				View viewFriend = inflater.inflate(R.layout.item_friend, null);
				viewMember = viewFriend;

				// Holder
				holder = new CircleMemberViewHolder();
				holder.tvName = (TextView) viewFriend.findViewById(R.id.tv_item_friend_name);
				holder.btnInvite = (Button) viewFriend.findViewById(R.id.b_item_friend_button);
				holder.friendPicture = ((ImageView) viewFriend.findViewById(R.id.iv_item_friend_image));
				viewFriend.setTag(holder);
			} else {
				holder = (CircleMemberViewHolder) view.getTag();
			}

			// Name
			holder.tvName.setText(user.getName());

			// Button
			if (user.isMember() || user.isInvited()) {
				holder.btnInvite.setVisibility(View.GONE);
			} else {
				holder.btnInvite.setOnClickListener(new FriendInviteManager(user, viewMember));
			}

			// Profile picture
			// pictureImageViewList.add(friendPicture);
			if (user.getProfilePicture() != null) {
				Log.i("InviteMembersFragment", user.getProfilePicture());
				imageDownloader.download(user.getProfilePicture(), holder.friendPicture);
			}

			// Return
			return viewMember;
		}

	}

	public static class CircleMemberViewHolder {
		public int position;
		public TextView tvName;
		public Button btnInvite;
		public ImageView friendPicture;
	}
}
