package net.ora.mobile.android.webservices.security;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.security.response.AuthResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSLogin extends MasterService {

	private static String URL = "auth/";

	public static User auth(OraApplication application, Context context, String username, String password) {
		try {
			// Validates
			validateRequired(context, username, R.string.wsLogin_errorUsarname);
			validateRequired(context, password, R.string.wsLogin_errorPassword);

			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("version", getVersion(context)));
			request.add(new BasicNameValuePair("username", username));
			request.add(new BasicNameValuePair("password", password));

			// Make request
			AuthResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, request, new TypeReference<AuthResponse>() {
			});

			if (response.getUser() != null) {
				MasterService.setUsuario(response.getUser());
				application.setUser(response.getUser());
			}
			return response.getUser();
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsLogin_error);
		}

		return null;
	}
}
