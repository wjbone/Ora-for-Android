package net.ora.mobile.android.security;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraInsecureActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.security.WSResetPassword;
import net.ora.mobile.dto.ServiceResponse;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class ResetPasswordActivity extends OraInsecureActivity {
	
	public static final String TAG_EMAIL = "email";

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_reset_password);
		
		// Set email if present
		String email = getIntent().getStringExtra(ResetPasswordActivity.TAG_EMAIL);
		if(email != null) {
			TextView txtEmail = (TextView)findViewById(R.id.resetPassword_txtEmail);
			txtEmail.setText(email);
		}
		
		setTitle(R.string.resetPassword_title);
	}
	
	public void onResetPasswordClick(View view) {
		new ResetPassowordActionDialog(this).init();
	}
	
	@Override
	public void finish() {
		super.close();
	}
	
	public class ResetPassowordActionDialog extends ActionDialog<ServiceResponse> {

		public ResetPassowordActionDialog(Activity context) {
			super(context);
		}

		@Override
		public ServiceResponse performAction() {
			String username = ((TextView) findViewById(R.id.resetPassword_txtEmail)).getText().toString();
			
			return WSResetPassword.resetPassword(context, username);
		}

		@Override
		public void afterAction(ServiceResponse response) {
			if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
				close();
			}
		}
	}
	
}
