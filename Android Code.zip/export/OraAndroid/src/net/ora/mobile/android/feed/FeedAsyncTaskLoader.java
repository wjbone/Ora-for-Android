package net.ora.mobile.android.feed;

import net.ora.mobile.android.ui.OraAsyncTaskLoader;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import android.app.Activity;


abstract public class FeedAsyncTaskLoader extends OraAsyncTaskLoader<PrayersFeedResponse> {
	
	public FeedAsyncTaskLoader(Activity activity, FeedLoaderCallbacks<PrayersFeedResponse> callbacks) {
		super(activity, callbacks);
	}
}
