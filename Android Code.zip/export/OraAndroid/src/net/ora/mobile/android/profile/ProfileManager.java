package net.ora.mobile.android.profile;

public class ProfileManager {

	protected boolean goToProfileSettings = false;
	
	protected boolean logout = false;
	
	public boolean isGoToProfileSettings() {
		return goToProfileSettings;
	}

	public void setGoToProfileSettings(boolean goToProfileSettings) {
		this.goToProfileSettings = goToProfileSettings;
	}

	public boolean isLogout() {
		return logout;
	}

	public void setLogout(boolean logout) {
		this.logout = logout;
	}
}
