package net.ora.mobile.android.ui;

import java.io.File;
import java.util.Date;

import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;

public class CachedImageDataFragment extends FragmentImageData {

	protected Date baseTime;
	
	public CachedImageDataFragment() {
		super();
		baseTime = new Date();
	}
	
	public long getBaseTime() {
		return baseTime.getTime();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		deleteUsedFiles();
	}
	
	protected void deleteUsedFiles() {
		
		String suffix = getBaseTime() + "";
		File baseDirectory = getActivity().getFilesDir();
		for (File file : baseDirectory.listFiles()) {
			// Contains this fragment timestamp
			if (file.getName().contains(suffix)) {
				file.delete();
			}
		}
	}

}
