package net.ora.mobile.android.webservices;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.dto.ServiceResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper;
import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CustomHttpEntityBuilder;
import com.digitalgeko.mobile.android.models.BaseRequest;
import com.digitalgeko.mobile.android.models.BaseResponse;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MasterService {

	// TEST SERVER
	public static final boolean IS_PRODUCTION_SERVER = true;
	private static final String SERVER_URL_DEV = "https://dev.ora.net/";
	private static final String SERVER_URL_PROD = "https://apis.ora.net/";

	/** General Tags */
	protected static final String TAG_DEVICE = "device";
	protected static final String TAG_TOKEN = "token";
	protected static final String TAG_ERROR = "error";

	protected static final String DEVICE = "android";

	protected static String token = null;
	protected static String errorMessage;
	protected static boolean failedConnection;
	protected static User usuario;

	private static List<Activity> pilaActividades = new ArrayList<Activity>();

	static {
		token = null;
		errorMessage = null;
		failedConnection = false;
		pilaActividades = new ArrayList<Activity>();
		usuario = null;
	}

	public static void initParameters() {
		token = null;
		errorMessage = null;
		failedConnection = false;
		pilaActividades = new ArrayList<Activity>();
	}

	public static void genericResponse(BaseResponse response) {
		setToken(response.getToken());
		setErrorMessage(response.getErrorMessage());
	}

	protected static <T extends ServiceResponse> T makeRequest(Context context, CONNECTION_TYPE type, String url,
			Vector<NameValuePair> vars, TypeReference<T> returnType) throws ClientProtocolException, IOException {
		return makeRequest(context, type, url, vars, null, returnType);
	}

	protected static <T extends ServiceResponse> T makeRequest(Context context, CONNECTION_TYPE type, String url,
			Vector<NameValuePair> vars, CustomHttpEntityBuilder customHttpEntityBuilder, TypeReference<T> returnType)
			throws ClientProtocolException, IOException {

		T response = null;

		// Make request
		String strResponse = connectWithServer(context, url, type, vars, customHttpEntityBuilder);

		// Build parameters
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		response = mapper.readValue(strResponse, returnType);

		// Validate response
		if (!response.isStatus()) {
			setFailedConnection(true);
			if (response.getErrors() != null) {
				setErrorMessage(response.getErrors());
			} else {
				setErrorMessage(response.getMessage());
			}
		} else {
			setFailedConnection(false);
			setErrorMessage(null);
		}
		return response;
	}

	protected static void buildRequest(BaseRequest request, Context context) throws NameNotFoundException {
		// Obtain Unique Id
		SharedPreferences myPrefs = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE);
		String uniqueId = myPrefs.getString("uniqueId", "");
		if (uniqueId.length() == 0) {
			UUID uniqueKey = UUID.randomUUID();
			uniqueId = uniqueKey.toString();

			// Save it
			SharedPreferences.Editor e = myPrefs.edit();
			e.putString("uniqueId", uniqueId); // add or overwrite someValue
			e.commit(); // this saves to disk and notifies observers
		}
		// Obtain Version
		String version = getVersion(context);

		// Set params
		request.setUniqueIdentifier(uniqueId);
		request.setDevice(DEVICE);
		request.setVersion(version);
		if (token != null) {
			request.setToken(token);
		}
	}

	protected static String connectWithServer(Context context, String url, CONNECTION_TYPE type, Vector<NameValuePair> vars,
			CustomHttpEntityBuilder customHttpEntityBuilder) throws ClientProtocolException, IOException {

		setFailedConnection(false);

		return ConnectionHelper.getJsonObject(context, IS_PRODUCTION_SERVER ? SERVER_URL_PROD : SERVER_URL_DEV, url, type, vars,
				customHttpEntityBuilder);
	}

	public static String getVersion(Context context) throws NameNotFoundException {
		PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
		String version = pInfo.versionName;
		return version;
	}

	protected static void highlightError(Context context, Exception e, int errorMessageId) {
		if (context != null)
			highlightError(e, context.getString(errorMessageId));
	}

	protected static void highlightError(Exception e, String errorMessage) {
		// Log.e(e.getClass().getSimpleName(),
		// new Object(){}.getClass().getEnclosingClass().getSimpleName() + ": " + e.getMessage());
		Log.e(e.getClass().getSimpleName(), getStackTraceString(e));
		setFailedConnection(true);
		setErrorMessage(errorMessage);
	}

	protected static void clearServices() {
		setFailedConnection(false);
	}

	public static List<Activity> getPilaActividades() {
		return pilaActividades;
	}

	public static int getActivityCount() {
		return pilaActividades.size();
	}

	public static Activity getActivityPos(int location) {
		return pilaActividades.get(location);
	}

	public static void addActivity(Activity newActivity) {
		pilaActividades.add(newActivity);
	}

	public static void deleteActivity(Activity lastActivity) {
		pilaActividades.remove(lastActivity);
	}

	public static void resetPile() {
		for (Activity temp : pilaActividades) {
			temp.finish();
		}
		pilaActividades.clear();
	}

	public static void finishActivities(int cant) {
		for (int i = 0; i < cant; i++) {
			Activity temp = pilaActividades.get(pilaActividades.size() - 1);
			pilaActividades.remove(temp);
			temp.finish();
		}
	}

	public static void setPilaActividades(List<Activity> pilaActividades) {
		MasterService.pilaActividades = pilaActividades;
	}

	public static String getToken() {
		return token;
	}

	public static void setToken(String token) {
		MasterService.token = token;
	}

	public static boolean isLoggin() {
		return token != null && token.length() > 0;
	}

	public static String getErrorMessage() {
		clearServices();
		return errorMessage;
	}

	public static void setErrorMessage(String errorMessage) {
		MasterService.errorMessage = errorMessage;
	}

	public static boolean isFailedConnection() {
		return failedConnection;
	}

	public static void setFailedConnection(boolean failedConnection) {
		MasterService.failedConnection = failedConnection;
	}

	public static String getDevice() {
		return DEVICE;
	}

	/*
	 * Validators
	 */

	protected static void validateRequired(Context context, String value, int errorMessageId) throws ValidationException {
		// Validate
		if (value != null && value.length() != 0) {
			return;
		}

		// Show error
		throw new ValidationException(context.getString(errorMessageId));
	}

	protected static void validateLength(Context context, String value, int length, int errorMessageId)
			throws ValidationException {
		// Validate
		if (value != null && value.length() == length) {
			return;
		}

		// Show error
		throw new ValidationException(context.getString(errorMessageId));
	}

	protected static void validateLength(Context context, String value, int[] lengths, int errorMessageId)
			throws ValidationException {
		// Validate
		for (int i = 0; i < lengths.length; i++) {
			if (value.length() == lengths[i]) {
				return;
			}
		}

		// Show error
		throw new ValidationException(context.getString(errorMessageId));
	}

	protected static void validateConfirmation(Context context, Object value, Object valueConfirmation, int errorMessageId)
			throws ValidationException {

		// Validate
		if (valueConfirmation.equals(value)) {
			return;
		}

		// Show error
		throw new ValidationException(context.getString(errorMessageId));
	}

	protected static void validateAmounts(Context context, BigDecimal value, BigDecimal otherValue, int errorMessageId)
			throws ValidationException {

		// Validate
		if (otherValue.compareTo(value) < 0) {
			return;
		}

		// Show error
		throw new ValidationException(context.getString(errorMessageId));
	}

	public static User getUsuario() {
		return usuario;
	}

	public static void setUsuario(User usuario) {
		MasterService.usuario = usuario;
	}

	/*
	 * 
	 */
	public static String getStackTraceString(Throwable throwable) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		throwable.printStackTrace(pw);
		return sw.toString();
	}
}
