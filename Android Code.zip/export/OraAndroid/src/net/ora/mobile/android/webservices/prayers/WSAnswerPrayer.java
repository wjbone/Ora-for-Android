package net.ora.mobile.android.webservices.prayers;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.response.AnswerPrayerResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSAnswerPrayer extends MasterService {

	private static final String URL = "answer_prayer/";

	public static AnswerPrayerResponse answerPrayer(OraApplication application, Context context, Prayer prayer, String answer) {

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("prayer_id", Integer.toString(prayer.getId())));
			request.add(new BasicNameValuePair("answer", answer));

			// Make request
			AnswerPrayerResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, request,
					new TypeReference<AnswerPrayerResponse>() {
					});
			// Set prayer
			if (!isFailedConnection() && response.getPrayer().getUser() == null) {
				response.getPrayer().setUser(application.getUser());
			}

			return response;

		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}

		return null;
	}
}
