package net.ora.mobile.android.circles;

import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCircleSearch;
import net.ora.mobile.dto.circles.response.CircleSearchResponse;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.digitalgeko.mobile.android.ui.DGAsyncTaskLoader;

/**
 * 
 * @author byron
 * 
 */
public class SearchCirclesLoader extends
		DGAsyncTaskLoader<CircleSearchResponse> {

	private int page = 1;
	private String query;
	private String city;
	private Activity activity;

	public SearchCirclesLoader(Activity context) {
		super(context);
		activity = context;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public CircleSearchResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			abandon();
			Log.i("Loader", "abandon");
			return null;
		}

		final Context context = getContext();
		CircleSearchResponse response = WSCircleSearch.searchCircles(context,
				query, city, page);

		if (MasterService.isFailedConnection()) {
			activity.runOnUiThread(new Runnable(){
				public void run() {
					Toast.makeText(context, MasterService.getErrorMessage(),
							Toast.LENGTH_SHORT).show();
				}
			});
			abandon();
			return null;
		}
		this.page = response.getNextPage();

		Log.i("Loader", "finish");

		return response;
	}
	
}
