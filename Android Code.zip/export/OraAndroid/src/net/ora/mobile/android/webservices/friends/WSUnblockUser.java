package net.ora.mobile.android.webservices.friends;

import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.ServiceResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSUnblockUser extends MasterService {

	private static final String URL = "unblock_user/";
	
	public static ServiceResponse unblockUser(Context context, int userId) {
		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("user_id", Integer.toString(userId)));

			// Make request
			ServiceResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, 
					request, new TypeReference<ServiceResponse>() {});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}
		
		return null;
	}

}
