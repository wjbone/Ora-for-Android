package net.ora.mobile.android.circles;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCircleAnnouncements;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CircleAnnouncementsResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

public class CirclesAnnouncementsFragment extends CachedImageDataFragment {

	private Circle circle;

	private List<Prayer> announcements;
	private boolean announcementsFirstTimeLoading;
	private boolean announcementsLoading;
	private int announcementsNextPage = 1;
	private PullToRefreshListView lvAnnouncements;
	private AnnouncementArrayAdapter announcementsAdapter;

	public static CirclesAnnouncementsFragment getInstance(Circle circle) {
		CirclesAnnouncementsFragment fragment = new CirclesAnnouncementsFragment();

		Bundle args = new Bundle();
		args.putParcelable(ViewCircleFragment.TAG_CIRCLE, circle);
		fragment.setArguments(args);

		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getArguments() != null) {
			circle = getArguments().getParcelable(ViewCircleFragment.TAG_CIRCLE);
		}
	}

	@Override
	protected int getActionBarString() {
		return R.string.circleAnnouncements_title;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		// Save
		if (circle == null) {
			return null;
		}

		// Inflate View
		View view = (ViewGroup) inflater.inflate(R.layout.fragment_circles__circles_announcements, container, false);

		// Announcements
		View emptyView = view.findViewById(R.id.tv_emptyList);
		announcementsNextPage = 1;
		announcementsLoading = false;
		announcementsFirstTimeLoading = true;
		announcements = new ArrayList<>();
		lvAnnouncements = (PullToRefreshListView) view.findViewById(R.id.lv_announcements);
		lvAnnouncements.setEmptyView(emptyView);
		announcementsAdapter = new AnnouncementArrayAdapter(getActivity(), this, announcements);
		lvAnnouncements.setAdapter(announcementsAdapter);
		lvAnnouncements.setOnRefreshListener(onRefreshAllNotificationsListener);
		lvAnnouncements.setOnScrollListener(allNotificationsOnScrollListener);
		lvAnnouncements.setOnItemClickListener(onAnnouncementListItemClickListener);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		// Start loading new announcements
		refreshAllNotificationsFeed();
	}

	/**
	 * Hide all list views, progress bar and empty list view.
	 */
	private void hideAllViews() {
		getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.tv_emptyList).setVisibility(View.INVISIBLE);
		lvAnnouncements.setVisibility(View.INVISIBLE);
	}

	/*
	 * ALL NOTIFICATIONS
	 */
	private void refreshAllNotificationsFeed() {
		if (!announcementsLoading) {
			if (announcements.size() == 0) {
				hideAllViews();
				getView().findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
				lvAnnouncements.onRefreshComplete();
			}

			LoadAllNotificationsAsyncTask task = new LoadAllNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			task.execute(1);
		} else {
			lvAnnouncements.onRefreshComplete();
		}
	}

	private void loadNextPageAllNotificationsFeed() {
		if (!announcementsLoading && announcementsNextPage > 0) {
			LoadAllNotificationsAsyncTask task = new LoadAllNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			task.execute(announcementsNextPage);
		}
	}

	private OnRefreshListener<ListView> onRefreshAllNotificationsListener = new OnRefreshListener<ListView>() {
		@Override
		public void onRefresh(PullToRefreshBase<ListView> refreshView) {
			refreshAllNotificationsFeed();
		}
	};

	private OnScrollListener allNotificationsOnScrollListener = new OnScrollListener() {
		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
				loadNextPageAllNotificationsFeed();
			}
		}
	};
	
	private OnItemClickListener onAnnouncementListItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			Prayer announcement = (Prayer) lvAnnouncements.getRefreshableView().getItemAtPosition(position);
			pushFragment(AnnouncementDetailFragment.getInstance(announcement));
		}
	};

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class LoadAllNotificationsAsyncTask extends AsyncTask<Integer, Void, CircleAnnouncementsResponse> {

		private Prayer firstAnnouncement;

		public LoadAllNotificationsAsyncTask() {
			this.firstAnnouncement = lvAnnouncements.isRefreshing() || announcements.size() == 0 ? null : announcements
					.get(0);
		}

		@Override
		protected CircleAnnouncementsResponse doInBackground(Integer... params) {
			int page = params[0];
			long announcementId = WSCircleAnnouncements.ANNOUNCEMENT_ID_ALL_ANNOUNCEMENTS;
			if (firstAnnouncement != null) {
				announcementId = firstAnnouncement.getId();
			}

			// Make request
			return WSCircleAnnouncements.getCircleAnnouncements(getActivity(), circle.getId(), announcementId, page);
		}

		@Override
		protected void onPostExecute(CircleAnnouncementsResponse response) {
			super.onPostExecute(response);

			boolean refreshing = lvAnnouncements.isRefreshing() || announcementsFirstTimeLoading;
			if (announcements.size() == 0) {
				getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
			} else {
				lvAnnouncements.onRefreshComplete();
			}

			if (WSCircleAnnouncements.isFailedConnection()) {
				Toast.makeText(getActivity(), MasterService.getErrorMessage(), Toast.LENGTH_LONG).show();
			} else if (response != null) {
				// Feed data
				if (response.getPrayers() != null) {
					if (refreshing) {
						announcements.clear();
					}
					announcements.addAll(response.getPrayers());
					announcementsFirstTimeLoading = false;
				}

				// Next page
				announcementsNextPage = response.getNextPage();
			}

			lvAnnouncements.setVisibility(View.VISIBLE);
			announcementsAdapter.notifyDataSetChanged();

			announcementsLoading = false;
		}
	}
}
