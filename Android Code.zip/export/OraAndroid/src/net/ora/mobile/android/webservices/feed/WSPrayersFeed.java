package net.ora.mobile.android.webservices.feed;

import java.util.TimeZone;
import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import net.ora.mobile.dto.prayers.Prayer;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSPrayersFeed extends MasterService {

	public static final int TIME_ALL_TIME_PRAYRS = 4;
	public static final int TIME_PRAYERS_OF_CURRENT_DAY = 5;
	public static final int TIME_PRAYERS_OF_LAST_WEEK = 6;
	public static final int TIME_PRAYERS_OF_LAST_MONTH = 7;
	public static final int PRIVATE_TYPE_PRAYERS_FRIENDS_AND_CIRCLES = 1;
	public static final int PRIVATE_TYPE_PRAYERS_PRIVATE_CIRCLES = 2;
	public static final int PRIVATE_TYPE_PRAYERS_FRIENDS_CIRCLES = 3;

	private static final String URL = "prayers_feed_v2/";

	public static PrayersFeedResponse getPrayersFeed(Context context, int time, int page, int prayerId) {

		int timeOffset = TimeZone.getDefault().getRawOffset();

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("time", Integer.toString(time)));
			request.add(new BasicNameValuePair("time_offset", Integer.toString(timeOffset)));
			request.add(new BasicNameValuePair("page", Integer.toString(page)));
			request.add(new BasicNameValuePair("prayer_id", Integer.toString(prayerId)));

			// Make request
			PrayersFeedResponse response = makeRequest(context, CONNECTION_TYPE.GET, URL, request,
					new TypeReference<PrayersFeedResponse>() {
					});
			//
			// if(!isFailedConnection()) {
			// for(Prayer prayer : response.getPrayers()) {
			// if(prayer.getUser() == null) {
			// prayer.setUser(application.getUser());
			// }
			// }
			// }

			return response; 
		} catch (Exception e) {
			highlightError(context, e, R.string.wsBase_error);
		}

		return null;
	}
}
