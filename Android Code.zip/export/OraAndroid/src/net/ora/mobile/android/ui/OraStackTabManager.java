package net.ora.mobile.android.ui;

import net.ora.mobile.android.prayers.NewPrayerFragment;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

import com.actionbarsherlock.app.ActionBar.Tab;
import com.digitalgeko.mobile.android.ui.DGFragment;
import com.digitalgeko.mobile.android.ui.StackTabManager;

public class OraStackTabManager extends StackTabManager {

	private boolean shouldClear;
	
	public OraStackTabManager(Context context, DGFragment fragment,
			int idContiner) {
		super(context, fragment, idContiner);
		
		shouldClear = true;
	}
	
	public boolean getShouldClear() {
		return shouldClear;
	}

	public void setShouldClear(boolean shouldClear) {
		this.shouldClear = shouldClear;
	}

	@Override
	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		// Clear history 
		clearHistory();
		
		// Make change
		super.onTabSelected(tab, ft);
	}
	
	@Override
	public void onTabReselected(Tab tab, FragmentTransaction ft) {
		// Clear history 
		clearHistory();
		
		// Make change
		super.onTabSelected(tab, ft);
	}
	
	@Override
	public void onTabUnselected(Tab tab, FragmentTransaction ft) {
		// Check for New Prayer
		Fragment fragment = fragments.peek(); 
		if(fragments.peek() instanceof NewPrayerFragment) {
			NewPrayerFragment newPrayerFragment = (NewPrayerFragment) fragment;
			newPrayerFragment.clearData();
		}
		
		// Make change
		super.onTabUnselected(tab, ft);
	}
	
	private void clearHistory() {
		if(getShouldClear()) {
			while(fragments.size() > 1) {
				fragments.pop();
			}
		}
	}
}
