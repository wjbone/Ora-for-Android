package net.ora.mobile.android.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

public class OraButton extends Button {

	public OraButton(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		if (!isInEditMode()) {
			init(context);
		}
	}
	
	public OraButton(Context context, AttributeSet attrs) {
		super(context, attrs);
		if (!isInEditMode()) {
			init(context);
		}
	}

	public OraButton(Context context) {
		super(context);
		if (!isInEditMode()) {
			init(context);
		}
	}

	protected void init(Context context) {
		Typeface tf = Typeface.createFromAsset(context.getAssets(), OraTextView.FONT_NAME);
		setTypeface(tf);
	}

}
