package net.ora.mobile.android.friends;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.friends.WSFriendsFriendList;
import net.ora.mobile.dto.profile.response.FriendListResponse;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageSearchFriends;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.friends.ActivityImageData;
import com.digitalgeko.mobile.android.objects.profile.RequestFriendshipDialog;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class FriendsListFriendActivity extends ActivityImageData {

	private int friend_id;
	private String friend_name;
	private LinearLayout friendsList;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_friend_list);
		
		friend_id = getIntent().getExtras().getInt("friend_id");
		friend_name = getIntent().getExtras().getString("friend_name");
		
		int index = friend_name.indexOf(" ");
		
		setDownloadFlag(true);
		setTitle(friend_name.substring(0, ((index != -1 ? index : friend_name.length()))) + "'s Friends");
		
		friendsList = (LinearLayout) findViewById(R.id.ly_list_friends_list);
		
		new LoadfriendsActionDialog(this).init();
	}
	
	/* ***********************************************************************************************************************
	 * ActionDialogs
	 * ***********************************************************************************************************************/
	
	public class LoadfriendsActionDialog extends ActionDialog<FriendListResponse> {

		public LoadfriendsActionDialog(Activity context) {
			super(context);
		}

		@Override
		public FriendListResponse performAction() {
			return WSFriendsFriendList.findFriendsFriend(context, Integer.toString(friend_id));
		}

		@Override
		public void afterAction(FriendListResponse result) {
			if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			}else{
				int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(FriendsListFriendActivity.this);
				LayoutInflater inflater = LayoutInflater.from(FriendsListFriendActivity.this);
				
				for(final FriendUser temp : result.getFriendsList()){
					final View convertView = inflater.inflate(R.layout.item_friend_list, null);
					final TextView div = GeneralMethods.createLine(R.color.friends_div_line, FriendsListFriendActivity.this);
					
					ImageView friendPicture = ((ImageView) convertView.findViewById(R.id.iv_item_friend_image));
					ImageView circlePicture = (ImageView) convertView.findViewById(R.id.iv_friends_Cirle);
					
					friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					
					getPictureImageViewList().add(friendPicture);
					getCircleImageViewList().add(circlePicture);
					
					((TextView) convertView.findViewById(R.id.tv_item_friend_name)).setText(temp.getName());
					
					final ImageButton button = ((ImageButton) convertView.findViewById(R.id.b_item_friend_button));
					if(((OraApplication) FriendsListFriendActivity.this.getApplication()).getUser().getId() == temp.getId()){
						button.setVisibility(View.GONE);
					}else{
						if(temp.isFriend()){
							button.setImageResource(R.drawable.ic_check_green);
						}else if(temp.isRequested()){
							button.setImageResource(R.drawable.ic_check_gray_pending);
						}else{
							button.setImageResource(R.drawable.ic_add_request);
						}
					}
					button.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							if((!temp.isFriend()) && (!temp.isRequested())){
								new RequestFriendshipDialog(context, button, temp, null).init();
							}
						}
					});
					
					convertView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(FriendsListFriendActivity.this, ProfileFriendActivity.class);
							intent.putExtra("friend_id", temp.getId());
							FriendsListFriendActivity.this.startActivity(intent);
						}
					});
					
					friendsList.addView(convertView);
					friendsList.addView(div);
					friendsList.invalidate();
				}
				
				AsyncDownloadImageSearchFriends async = new AsyncDownloadImageSearchFriends("MyFriendsListFragmets", context, FriendsListFriendActivity.this);
				async.setListPictures(getPictureImageViewList());
				
				getAsyncTaskList().add(async);
				
				async.execute(result.getFriendsList());
			}
		}
	}
	
}
