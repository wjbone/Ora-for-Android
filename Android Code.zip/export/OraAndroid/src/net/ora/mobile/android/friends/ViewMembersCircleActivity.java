package net.ora.mobile.android.friends;

import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSCircleMembers;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.friends.ActivityImageData;
import com.digitalgeko.mobile.android.objects.profile.RequestFriendshipDialog;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class ViewMembersCircleActivity extends ActivityImageData {

	private int circle_id;
	private LinearLayout membersList;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_friend_list);
		
		setDownloadFlag(true);
		circle_id = getIntent().getExtras().getInt("circle_id");
		setTitle("Circle Members");
		
		membersList = (LinearLayout) findViewById(R.id.ly_list_friends_list);
		new LoadMembersActionDialog(this).init();
	}
	
	public class LoadMembersActionDialog extends ActionDialog<List<CircleMember>>{

		public LoadMembersActionDialog(Activity context) {
			super(context);
		}

		@Override
		public List<CircleMember> performAction() {
			return WSCircleMembers.getCircleMembers(context, circle_id);
		}

		@Override
		public void afterAction(List<CircleMember> result) {
			if(MasterService.isFailedConnection()){
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				ViewMembersCircleActivity.this.finish();
			}else{
				int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(context);
				LayoutInflater inflater = LayoutInflater.from(context);
				
				for(final CircleMember temp : result){
					final View convertView = inflater.inflate(R.layout.item_friend_list, null);
					final TextView div = GeneralMethods.createLine(R.color.friends_div_line, context);
					
					ImageView friendPicture = ((ImageView) convertView.findViewById(R.id.iv_item_friend_image));
					ImageView circlePicture = (ImageView) convertView.findViewById(R.id.iv_friends_Cirle);
					
					friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					
					getPictureImageViewList().add(friendPicture);
					getCircleImageViewList().add(circlePicture);
					
					((TextView) convertView.findViewById(R.id.tv_item_friend_name)).setText(temp.getName());
					
					final ImageButton button = ((ImageButton) convertView.findViewById(R.id.b_item_friend_button));
					if(((OraApplication) getApplication()).getUser().getId() == temp.getId()){
						button.setVisibility(View.GONE);
					}else{
						if(temp.isFriend()){
							button.setImageResource(R.drawable.ic_check_green);
						}else if(temp.isRequested()){
							button.setImageResource(R.drawable.ic_check_gray_pending);
						}else{
							button.setImageResource(R.drawable.ic_add_request);
						}
					}
					button.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							if((!temp.isFriend()) && (!temp.isRequested())){
								new RequestFriendshipDialog(context, button, null, temp).init();
							}
						}
					});
					
					convertView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(context, ProfileFriendActivity.class);
							intent.putExtra("friend_id", temp.getId());
							context.startActivity(intent);
						}
					});
					
					membersList.addView(convertView);
					membersList.addView(div);
					membersList.invalidate();
				}
			}
		}
	}
	
}
