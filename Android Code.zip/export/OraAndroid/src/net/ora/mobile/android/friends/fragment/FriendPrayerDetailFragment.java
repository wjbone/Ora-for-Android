package net.ora.mobile.android.friends.fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.prayers.PrayerCommentsLoader;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSAddComment;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.PrayerComment;
import net.ora.mobile.dto.prayers.response.AddCommentResponse;
import net.ora.mobile.dto.prayers.response.CommentsForPrayersResponse;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.format.DateUtils;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.profile.PrayerView;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class FriendPrayerDetailFragment extends BaseFriendsFragment implements
		LoaderManager.LoaderCallbacks<CommentsForPrayersResponse> {

	public static final String TAG_PRAYER = "prayer";
	public static final int LOADER_ID_PRAYER_COMMENTS = 30;

	private Prayer prayer;

	private ViewGroup view;
	private ViewGroup viewPrayer;
	private ViewGroup viewPrayerComments;

	private PrayerView prayerView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		setDownloadFlag(true);
		prayer = (Prayer) ((OraApplication) getActivity().getApplication()).getParam("prayer_friends");
		prayerView = (PrayerView) ((OraApplication) getActivity().getApplication()).getParam("prayer_view");

		view = (ViewGroup) inflater.inflate(R.layout.fragment_prayer_detail, container, false);

		((ImageButton) view.findViewById(R.id.prayerDetail_btnAddComment)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				new AddCommentActionDialog(getActivity()).init();
			}
		});

		// Prayers list view group
		viewPrayerComments = (ViewGroup) view.findViewById(R.id.prayerDetail_lstComments);

		// Prayer info
		viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_prayer_full_description, null);
		((ViewGroup) view.findViewById(R.id.prayerDetail_layoutHeader)).addView(viewPrayer);
		setUpPrayerInfo(viewPrayer, prayer);

		// Activate loader
		getActivity().getSupportLoaderManager().initLoader(LOADER_ID_PRAYER_COMMENTS, null, this);

		return view;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (prayerView != null) {
			prayerView.getCommentsCount().setText(Integer.toString(prayer.getCommentsCount()));
			prayerView.getPrayersCount().setText(Integer.toString(prayer.getLikesCount()));
			if (!prayer.isLikeAvailable()) {
				prayerView.getGrabber().setVisibility(View.GONE);
			}
			((OraApplication) getActivity().getApplication()).deleteParam("prayer_view");
		}
	}

	private void setUpPrayerInfo(ViewGroup viewPrayer, final Prayer prayer) {

		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());

		// Set listeners
		// if (prayer.isLikeAvailable()) {
		// viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer,
		// viewPrayer));
		// } else {
		// }
		View imgGrabber = viewPrayer.findViewById(R.id.feedPrayer_imGrabber);
		imgGrabber.setVisibility(View.GONE);

		// Set info
		((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());

		((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer)).setText(prayer.getUser().getName());

		// Go to user profile
		ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
		friendPicture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(
						new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
			}
		});
		ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

		friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
		circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

		pictureImageViewList.add(friendPicture);
		circleImageViewList.add(circlePicture);

		// Circles
		int circlesCount = prayer.getCircles().size();
		String firstCircle = "";
		if (circlesCount >= 1)
			firstCircle = prayer.getCircles().get(0).getName();
		String strCircles = getResources().getQuantityString(R.plurals.viewCircle_lblItemPrayer_circles, circlesCount,
				firstCircle, circlesCount - 1);
		// Set circles string
		((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);

		// Set prayer likes count
		((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer)).setText(Integer.toString(prayer.getLikesCount()));

		// Set prayer comments count
		((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer))
				.setText(Integer.toString(prayer.getCommentsCount()));

		// Set prayer time
		((TextView) viewPrayer.findViewById(R.id.tv_pray_time)).setText(GeneralMethods.fromDate(GeneralMethods
				.parseStringToDate(prayer.getDateCreated())));

		if (asyntTaskList.isEmpty()) {
			AsyncDownloadImageUser async = new AsyncDownloadImageUser("PrayerDetailFragmetsMain", getActivity(), this);
			asyntTaskList.add(async);

			// Set data
			Pair<User, ImageView>[] tempPair = new Pair[1];
			tempPair[0] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);
			async.execute(tempPair);
		}
	}

	@Override
	public Loader<CommentsForPrayersResponse> onCreateLoader(int arg0, Bundle arg1) {
		PrayerCommentsLoader loader = new PrayerCommentsLoader(getActivity());
		loader.setPrayerId(prayer.getId());
		return loader;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onLoadFinished(Loader<CommentsForPrayersResponse> loader, CommentsForPrayersResponse data) {
		// Load pictures
		Pair<User, ImageView>[] usersImagesViewsPairs = new Pair[data.getComments().size()];
		int i = 0;

		// Inflate views
		LayoutInflater inflater = LayoutInflater.from(getActivity());
		for (PrayerComment comment : data.getComments()) {
			View viewComment = inflater.inflate(R.layout.item_prayer_comment, null);
			setUpCommentView(viewComment, comment);
			viewPrayerComments.addView(viewComment);

			// Load picture
			ImageView commentPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
			usersImagesViewsPairs[i++] = new Pair<User, ImageView>(comment.getUser(), commentPicture);
		}

		// AsyncDownloadImageUser async = new AsyncDownloadImageUser(
		// "PrayerDetailFragmetsMain", getActivity(),
		// FriendPrayerDetailFragment.this);
		// asyntTaskList.add(async);
		// async.execute(usersImagesViewsPairs);

	}

	public class AddCommentActionDialog extends ActionDialog<AddCommentResponse> {

		public AddCommentActionDialog(Activity context) {
			super(context);
		}

		@Override
		public AddCommentResponse performAction() {

			int prayerId = prayer.getId();
			String text = ((TextView) view.findViewById(R.id.prayerDetail_txtComment)).getText().toString();

			return WSAddComment.addComment(context, prayerId, text);
		}

		@Override
		public void afterAction(AddCommentResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				return;
			}

			// Update
			prayer.setCommentsCount(response.getPrayer().getCommentsCount());
			setUpPrayerInfo(viewPrayer, prayer);

			// Add new comment to layout
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss", Locale.getDefault());
			TimeZone timeZone = TimeZone.getTimeZone("UTC");
			format.setTimeZone(timeZone);

			LayoutInflater inflater = LayoutInflater.from(getActivity());
			View viewComment = inflater.inflate(R.layout.item_prayer_comment, null);
			PrayerComment comment = new PrayerComment();
			comment.setId(response.getCommentId());
			comment.setFlagged(false);
			comment.setText(response.getText());
			comment.setDateCreated(format.format(new Date()));
			comment.setUser(new User(((OraApplication) getActivity().getApplication()).getUser()));

			setUpCommentView(viewComment, comment);

			// Clear comment text box
			((TextView) view.findViewById(R.id.prayerDetail_txtComment)).setText("");

			viewPrayerComments.addView(viewComment, 0);

			// Load picture
			ImageView commentPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
			// AsyncDownloadImageUser async = new AsyncDownloadImageUser(
			// "PrayerDetailFragmetsMain", getActivity(),
			// PrayerDetailFragment.this);
			// asyntTaskList.add(async);
			// Pair<User, ImageView>[] tempPair = new Pair[1];
			// tempPair[0] = new Pair<User, ImageView>(comment.getUser(),
			// commentPicture);
			// async.execute(tempPair);
		}
	}

	private void setUpCommentView(View viewComment, final PrayerComment comment) {

		// Set info
		((TextView) viewComment.findViewById(R.id.tv_prayer_comment_text)).setText(comment.getText());

		((TextView) viewComment.findViewById(R.id.tv_prayer_comment_name_user)).setText(comment.getUser().getName());

		// Set date info
		Date date = GeneralMethods.parseStringToDate(comment.getDateCreated());
		if (date != null) {
			String strTime = DateUtils.getRelativeDateTimeString(getActivity(), date.getTime(), DateUtils.MINUTE_IN_MILLIS,
					DateUtils.MINUTE_IN_MILLIS, 0).toString();
			((TextView) viewComment.findViewById(R.id.tv_prayer_comment_time)).setText(strTime);
		}

		ImageView friendPicture = (ImageView) viewComment.findViewById(R.id.iv_prayer_comment_image_user);
		friendPicture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(
						new Intent(getActivity(), ProfileFriendActivity.class).putExtra("friend_id", comment.getUser().getId()));
			}
		});
	}

	@Override
	public void onLoaderReset(Loader<CommentsForPrayersResponse> arg0) {
	}
}
