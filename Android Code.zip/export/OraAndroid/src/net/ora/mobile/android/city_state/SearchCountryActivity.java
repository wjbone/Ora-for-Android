package net.ora.mobile.android.city_state;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraSherlockActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;

public class SearchCountryActivity extends OraSherlockActivity implements OnItemClickListener {

	private static final String TAG_LOG = "SearchCityStateActivity";
	public static final int TYPE_SELECT_CITY = 10;
	public static final String TAG_CITY_STATE = "city_state";

//	private static final String[] COUNTRY_CODES = { null, "AD", "AR", "AS", "AT", "AU", "AX", "BD", "BE", "BG", "BR", "CA", "CH",
//			"CZ", "DE", "DK", "DO", "DZ", "ES", "FI", "FO", "FR", "GB", "GF", "GG", "GL", "GP", "GT", "GU", "HR", "HU", "IM",
//			"IN", "IS", "IT", "JE", "JP", "LI", "LK", "LT", "LU", "MC", "MD", "MH", "MK", "MP", "MQ", "MX", "MY", "NL", "NO",
//			"NZ", "PH", "PK", "PL", "PM", "PR", "PT", "RE", "RO", "RU", "SE", "SI", "SJ", "SK", "SM", "TH", "TR", "VA", "VI",
//			"YT", "ZA" };

	private String[] allCountries;
	private List<String> countries;
	private ListView viewCitiesAndStatesList;
	private EditText searchText;
	private ArrayAdapter<String> adapter;
	private View viewProgressBar;
	private SearchAsync task;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_city_state);

		// Instance fields
		allCountries = getResources().getStringArray(R.array.selectCountry_list);
		countries = new ArrayList<>(Arrays.asList(allCountries));

		// Views references
		viewCitiesAndStatesList = (ListView) findViewById(R.id.ly_cityStateList);
		viewCitiesAndStatesList.setOnItemClickListener(this);
		adapter = new ArrayAdapter<String>(this, R.layout.item_city_data, R.id.tv_item_activity_name, countries);
		viewCitiesAndStatesList.setAdapter(adapter);

		viewProgressBar = findViewById(R.id.pbLoading);

		setTitle("");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		LayoutInflater inflater = LayoutInflater.from(this);
		View searchTextView = inflater.inflate(R.layout.item_search, null);

		ActionBar _actionBar = getSupportActionBar();
		_actionBar.setDisplayHomeAsUpEnabled(true);

		menu.add(Menu.NONE, Menu.NONE, 1, "Search").setIcon(R.drawable.ic_search).setActionView(searchTextView)
				.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

		searchText = (EditText) searchTextView.findViewById(R.id.et_search_view);
		searchText.setMinWidth((int) (GeneralMethods.getWidth(this) * 0.90));
		searchText.addTextChangedListener(new SearchFeedManager(searchText));
		searchText.setHint(R.string.selectCountry_lblSearchCountry);
		searchText.requestFocus();

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;
		}
		return true;
	}

	@Override
	public void finish() {
		super.finish();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == TYPE_SELECT_CITY) {
			if (resultCode == android.app.Activity.RESULT_OK) {
				setResult(android.app.Activity.RESULT_OK,
						new Intent().putExtra(SearchCountryActivity.TAG_CITY_STATE, data.getStringExtra("city_state")));
			}
			finish();
		}
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		 String contrycode = countries.get(position).split(", ")[1];
		// setResult(android.app.Activity.RESULT_OK, new Intent().putExtra(SearchCountryActivity.TAG_CITY_STATE, contrycode));
		// finish();
		Intent intent = new Intent(this, SearchCityStateActivity.class);
		intent.putExtra(SearchCityStateActivity.TAG_ARG_COUNTRY_CODE, contrycode);
		startActivityForResult(intent, TYPE_SELECT_CITY);
	};

	/*
	 * 
	 */
	public class SearchAsync extends AsyncTask<String, Void, List<String>> {

		public SearchAsync(Activity context) {
			super();
		}

		@Override
		protected List<String> doInBackground(String... word) {
			String query = word[0].trim();
			query = Normalizer.normalize(query, Normalizer.Form.NFD);
			query = query.replaceAll("[^\\p{ASCII}]", "").toLowerCase();
			List<String> filteredCountries = new ArrayList<>();

			if (query.length() > 0) {

				// Search country
				for (String country : allCountries) {
					if (Normalizer.normalize(country, Normalizer.Form.NFD).toLowerCase().contains(query)) {
						filteredCountries.add(country);
					}
				}
			} else {
				filteredCountries.addAll(Arrays.asList(allCountries));
			}

			return filteredCountries;
		}

		@Override
		protected void onPostExecute(List<String> result) {
			super.onPostExecute(result);

			countries.clear();
			countries.addAll(result);

			// Change views
			viewProgressBar.setVisibility(View.INVISIBLE);
			viewCitiesAndStatesList.setVisibility(View.VISIBLE);
			adapter.notifyDataSetChanged();

			Log.i(TAG_LOG, "End loading data");
		}
	}

	/*
	 * 
	 */
	public class SearchFeedManager implements TextWatcher {

		private Handler mHandler;
		private EditText etSearch;

		public SearchFeedManager(EditText text) {
			this.etSearch = text;
			mHandler = new Handler();
		}

		private Runnable searchRunnable = new Runnable() {
			@Override
			public void run() {
				mHandler.removeCallbacks(searchRunnable);
				task = new SearchAsync(SearchCountryActivity.this);
				task.execute(etSearch.getText().toString());
			}

		};

		@Override
		public void afterTextChanged(Editable s) {
			// Stop
			mHandler.removeCallbacks(searchRunnable);
			if (task != null)
				task.cancel(true);

			// Visual
			viewCitiesAndStatesList.setVisibility(View.INVISIBLE);
			viewProgressBar.setVisibility(View.VISIBLE);

			mHandler.postDelayed(searchRunnable, 100);
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}
}
