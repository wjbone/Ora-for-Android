package net.ora.mobile.android.profile;

import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.MyCirclesFragment;
import net.ora.mobile.android.ui.OraTextView;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSGetProfile;
import android.app.Activity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.asynctask.ObtainProfilePrayersAsync;
import com.digitalgeko.mobile.android.helpers.profile.ProfileGestureDetector;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.UIConfiguration;

public class UserFragment extends FragmentImageData {

	private List<View> headersList;
	private ImageView imageBackgroundPicture, userPicture, imageBackgroundAbout;
	private LinearLayout pictureMargin, prayersList, profileSwitch;
	private OraTextView prayersCount, friendsCount, circlesCount, aboutText, cityText;
	private GestureDetector mGestureDetector;
	private View.OnTouchListener mGestureListener;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		String name = ((OraApplication) getActivity().getApplication()).getUser().getUsername();
		if (name == null || name.trim().length() == 0) {
			name = ((OraApplication) getActivity().getApplication()).getUser().getName();
		}
		getActivity().setTitle(name);
	}

	@SuppressWarnings("deprecation")
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.profile_main, container, false);

		int background_heigth = GeneralMethods.getProfileBackgroundWidth(getActivity());
		int picture_width = (int) (background_heigth * 0.75);

		profileSwitch = (LinearLayout) view.findViewById(R.id.ly_profile_swype);
		prayersList = (LinearLayout) view.findViewById(R.id.ly_profile_prayers_list);

		prayersCount = (OraTextView) view.findViewById(R.id.tv_Count_Prayers);
		friendsCount = (OraTextView) view.findViewById(R.id.tv_Count_Friends);
		circlesCount = (OraTextView) view.findViewById(R.id.tv_Count_Circles);

		((LinearLayout) view.findViewById(R.id.layoutPrayers)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				goToAllPrayers();
			}
		});

		((LinearLayout) view.findViewById(R.id.layoutFriends)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				pushFragment(new MyFriendsListFragments());
			}
		});

		((LinearLayout) view.findViewById(R.id.layoutCircles)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				UIConfiguration.setShouldMakeNextAction(false);
				getSherlockActivity().getSupportActionBar().getTabAt(1).select();
				popAllFragments(new MyCirclesFragment());
			}
		});

		/* ***********************************************************************************************************************
		 * obtaining the profile picture view *********************************** ***********************************
		 * ************************************************
		 */

		View headerPictureView = inflater.inflate(R.layout.profile_header_image, null);

		imageBackgroundPicture = (ImageView) headerPictureView.findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		userPicture = (ImageView) headerPictureView.findViewById(R.id.iv_Profile_Picture);
		userPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		pictureMargin = (LinearLayout) headerPictureView.findViewById(R.id.ly_Profile_Margin_Picture);
		pictureMargin.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		/* ***********************************************************************************************************************
		 * obtaining the profile information view ******************************* ***************************************
		 * ************************************************
		 */

		View headerDescriptionView = inflater.inflate(R.layout.profile_header_description, null);

		imageBackgroundAbout = (ImageView) headerDescriptionView.findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundAbout.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		aboutText = (OraTextView) headerDescriptionView.findViewById(R.id.tv_profile_about);
		cityText = (OraTextView) headerDescriptionView.findViewById(R.id.tv_profile_city);

		/* ***********************************************************************************************************************
		 * Setting the Gesture Detector for Swipe ******************************* ***************************************
		 * ************************************************
		 */

		headersList = Arrays.asList(headerPictureView, headerDescriptionView);

		mGestureDetector = new GestureDetector(new ProfileGestureDetector(profileSwitch, headersList));
		mGestureListener = new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				return mGestureDetector.onTouchEvent(event);
			}
		};

		profileSwitch.setOnTouchListener(mGestureListener);
		profileSwitch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// to detect the swipe.
			}
		});

		/* ***********************************************************************************************************************
		 * Connecting with the server
		 * ***********************************************************************************************************************
		 */

		LoadProfileActionDialog actionDialog = new LoadProfileActionDialog(getActivity());
		getActionDialogList().add(actionDialog);
		actionDialog.init();

		return view;
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		SubMenu sub = menu.addSubMenu(0, 0, Menu.NONE, "Settings");
		sub.setIcon(R.drawable.profile_btn_settings);
		sub.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		pushFragment(new SettingsFragment());
		return false;
	}

	@Override
	public void goToAllPrayers() {
		pushFragment(new MyPrayersListFragment());
	}

	@Override
	public void onDetach() {
		super.onFragmentDetach();
	}

	/*
	 * 
	 */
	public class LoadProfileActionDialog extends ActionDialog<Void> {

		private boolean consultPrayers = false;

		public LoadProfileActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			String userId = null;
			if (userId == null) {
				userId = Integer.toString(((OraApplication) getActivity().getApplication()).getUser().getId());
			}

			WSGetProfile.getProfile((OraApplication) getActivity().getApplication(), getContext(), userId);

			if (!MasterService.isFailedConnection()) {
				if (WSGetProfile.getResponse().getProfileUser() != null) {
					if (WSGetProfile.getResponse().getProfileUser().getPrayersCount() > 0) {
						consultPrayers = true;
					}
				}
			}
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				List<ImageView> pictures = Arrays.asList(userPicture);
				List<ImageView> picturesFaded = Arrays.asList(imageBackgroundPicture, imageBackgroundAbout);

				if (WSGetProfile.getResponse().getProfileUser() != null) {
					if (WSGetProfile.getResponse().getProfileUser().getProfilePicture().trim().length() > 0) {

						DownloadProfilePicture asyncJob = new DownloadProfilePicture(getActivity(), UserFragment.this, pictures,
								picturesFaded, "UserFragment Profile");
						UserFragment.this.getAsyncTaskList().add(asyncJob);
						asyncJob.execute(WSGetProfile.getResponse().getProfileUser().getProfilePicture().trim());

						userPicture.setVisibility(View.VISIBLE);
						pictureMargin.setBackgroundResource(R.drawable.profile_image_margin);
						pictureMargin.invalidate();
					}

					prayersCount.setText(Integer.toString(WSGetProfile.getResponse().getProfileUser().getPrayersCount()));
					friendsCount.setText(Integer.toString(WSGetProfile.getResponse().getProfileUser().getFriendsCount()));
					// circlesCount.setText(Integer.toString(WSGetProfile.getResponse().getProfileUser().getCirclesUsed()));
					circlesCount.setText(Integer.toString(WSGetProfile.getResponse().getProfileUser().getRelatedCirclesCount()));
					aboutText.setText(WSGetProfile.getResponse().getProfileUser().getAbout());
					cityText.setText(WSGetProfile.getResponse().getProfileUser().getCity());

					if (consultPrayers) {
						LayoutInflater inflater = LayoutInflater.from(context);
						prayersList.addView(inflater.inflate(R.layout.item_loading, null));

						ObtainProfilePrayersAsync asyncJob = new ObtainProfilePrayersAsync((OraApplication) getActivity()
								.getApplication(), getActivity(), prayersList, UserFragment.this, WSGetProfile.getResponse()
								.getProfileUser(), false);
						getAsyncTaskList().add(asyncJob);
						asyncJob.execute(new Void[] { null });
					}
				} else {
					GeneralMethods.crearDialogoOk(WSGetProfile.getResponse().getMessage(), context);
				}
			}
		}
	}
}
