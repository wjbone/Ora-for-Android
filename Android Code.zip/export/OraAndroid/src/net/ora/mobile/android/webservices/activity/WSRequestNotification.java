package net.ora.mobile.android.webservices.activity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.activity.Notification;
import net.ora.mobile.dto.activity.response.PrayersInteractionsResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSRequestNotification extends MasterService {

	public static final int NOTIFICATION_ID_ALL_NOTIFICATIONS = -1;
	public static final int FILTER_ALL_NOTIFICATIONS = 1;
	public static final int FILTER_PRAYER_INTERACTIONS = 2;
	public static final int FILTER_CIRCLE_INTERACTIONS = 3;

	private static final String URL = "notification_feed_v2/";

	public static PrayersInteractionsResponse getPrayersNotifications(OraApplication application, Context context, int page,
			long notificationId, int filter) {
		try {
			Vector<NameValuePair> request = new Vector<NameValuePair>();

			request.add(new BasicNameValuePair("page", Integer.toString(page)));
			request.add(new BasicNameValuePair("notification_id", Long.toString(notificationId)));
			request.add(new BasicNameValuePair("filter", Integer.toString(filter)));

			// Make request
			PrayersInteractionsResponse response = makeRequest(context, CONNECTION_TYPE.GET, URL, request,
					new TypeReference<PrayersInteractionsResponse>() {
					});

			if (!isFailedConnection()) {
				User appUser = application.getUser();
				List<Notification> toRemove = new ArrayList<>();
				for (Notification notification : response.getFeed()) {

					switch (notification.getType()) {
					// Prayer notifications
					case Notification.TYPE_ANSWERED:
					case Notification.TYPE_COMMENT:
					case Notification.TYPE_LIKE:
						// Friends notifications
					case Notification.TYPE_FRIENDSHIP_REQUEST:
						// Circle notifications
					case Notification.TYPE_CIRCLE_JOIN_REQUEST:
					case Notification.TYPE_ANNOUNCEMENT:
						break;
					default:
						toRemove.add(notification);
						continue;
					}

					if (notification.getPrayer() != null && notification.getPrayer().getUser() == null) {
						notification.getPrayer().setUser(appUser);
					}
				}
				
				response.getFeed().removeAll(toRemove);
			}

			return response;
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsBase_error);
		}
		return null;
	}

}
