package net.ora.mobile.android.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class OraTextViewForOraName extends TextView {
	
	public static final String FONT_NAME = "Futura_Medium.ttf";

	public OraTextViewForOraName(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		if (!isInEditMode()) {
			init(context);
		}
	}
	
	public OraTextViewForOraName(Context context, AttributeSet attrs) {
		super(context, attrs);
		if (!isInEditMode()) {
			init(context);
		}
	}

	public OraTextViewForOraName(Context context) {
		super(context);
		if (!isInEditMode()) {
			init(context);
		}
	}

	protected void init(Context context) {
		Typeface tf = Typeface.createFromAsset(context.getAssets(), OraTextViewForOraName.FONT_NAME);
		setTypeface(tf);
	}

//	private Context mContext;
//	private String mFont;
//
//	public OraTextView(Context context, AttributeSet attrs, int defStyle) {
//		super(context, attrs, defStyle);
//		if (!isInEditMode()) {
//			init(context);
//		}
//	}
//
//	public OraTextView(Context context, AttributeSet attrs) {
//		super(context, attrs);
//		if (!isInEditMode()) {
//			TypedArray a = context.getTheme().obtainStyledAttributes(attrs,
//					R.styleable.OraTextView, 0, 0);
//			try {
//				mFont = a.getString(R.styleable.OraTextView_font);
//			} finally {
//				a.recycle();
//			}
//
//			init(context);
//		}
//	}
//
//	public OraTextView(Context context) {
//		super(context);
//		if (!isInEditMode()) {
//			init(context);
//		}
//	}
//
//	protected void init(Context context) {
//		// Typeface tf = Typeface.createFromAsset(context.getAssets(),
//		// "fonts/Frutiger LT 45 Light.ttf");
//		// setTypeface(tf);
//		mContext = context;
//		if (mFont != null) {
//			Typeface tf = Typeface.createFromAsset(context.getAssets(), "agenda.ttf");//mFont);
//			setTypeface(tf);
//			// setTypeface(FontsUtils.get(mFont));
//		}
//	}

}
