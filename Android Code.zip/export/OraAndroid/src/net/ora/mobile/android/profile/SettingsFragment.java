package net.ora.mobile.android.profile;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import net.ora.mobile.android.InitialActivity;
import net.ora.mobile.android.MainActivity;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.city_state.SearchCountryActivity;
import net.ora.mobile.android.help.TutorialActivity;
import net.ora.mobile.android.ui.OraTextView;
import net.ora.mobile.android.util.Blur;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSEditProfile;
import net.ora.mobile.android.webservices.profile.WSGetProfile;
import net.ora.mobile.dao.FeedDBHelper;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.database.UserOraTableManager;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;
import com.digitalgeko.mobile.android.services.ShowNotification;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.facebook.Session;
import com.facebook.widget.InviteFriendsButton;
import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.loopj.android.http.PersistentCookieStore;

@SuppressWarnings("static-access")
public class SettingsFragment extends FragmentImageData {

	public static final int TAKE_PICTURE = 1;
	public static final int SELECT_PICTURE = 2;
	public static final int SELECT_PLACE = 3;

	private int hour = -1;
	private int minute = -1;

	static final int TIME_DIALOG_ID = 999;

	private EditText profileName, profileAbout, profileEmail, currentPassword, newPassword, ConfirmPassword;
	private Button privacyButton, profileCity;
	private OraTextView privacyMessage;
	private CheckBox notificationSelected;

	private ImageView backgroundImage, pictureImage, cameraImage;
	private LinearLayout marginImage;

	private String imageFilePath;
	private String searchCityStateResponse;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		String name = ((OraApplication) getActivity().getApplication()).getUser().getName();
		if ((name == null) || (name.trim().length() == 0)) {
			name = ((OraApplication) getActivity().getApplication()).getUser().getUsername();
		}
		getActivity().setTitle(name);

		try {
			hour = WSGetProfile.getResponse().getProfileUser().getHour();
			minute = WSGetProfile.getResponse().getProfileUser().getMinute();
		} catch (NullPointerException exception) {
			hour = -1;
			minute = -1;
		}

		if ((hour == -1) || (minute == -1)) {
			Calendar c = Calendar.getInstance();
			hour = c.get(Calendar.HOUR_OF_DAY);
			minute = c.get(Calendar.MINUTE);
		}
	}

	@Override
	protected boolean isShowKeyboard() {
		return false;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.profile_settings, container, false);

		int background_heigth = GeneralMethods.getProfileBackgroundWidth(getActivity());
		int picture_width = (int) (background_heigth * 0.75);

		notificationSelected = (CheckBox) view.findViewById(R.id.cb_setting_reminder);
		notificationSelected.setChecked(((OraApplication) getActivity().getApplication()).getUser().isHaveNotification());

		notificationSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					((OraApplication) getActivity().getApplication()).getUser().setHaveNotification(true);
					((OraApplication) getActivity().getApplication()).persistUser();
					Toast.makeText(getActivity(), "Remember to set the time", Toast.LENGTH_LONG).show();
				} else {
					((OraApplication) getActivity().getApplication()).getUser().setHaveNotification(false);
					((OraApplication) getActivity().getApplication()).persistUser();
				}
			}
		});

		backgroundImage = (ImageView) view.findViewById(R.id.iv_setting_background);
		backgroundImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		pictureImage = (ImageView) view.findViewById(R.id.iv_setting_picture);
		pictureImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		cameraImage = (ImageView) view.findViewById(R.id.iv_setting_camera);
		cameraImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

				builder.setItems(new String[] { "Camera", "Gallery" }, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
						Intent intent = null;
						switch (which) {
						case 0:
							intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
							startActivityForResult(intent, TAKE_PICTURE);
							break;
						case 1:
							intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
							intent.setType("image/*");
							startActivityForResult(intent, SELECT_PICTURE);
							break;
						}
					}
				});

				builder.create().show();
			}
		});

		marginImage = (LinearLayout) view.findViewById(R.id.ly_setting_margin);
		marginImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		profileName = (EditText) view.findViewById(R.id.etProfileName);

		profileAbout = (EditText) view.findViewById(R.id.etProfileAbout);

		profileEmail = (EditText) view.findViewById(R.id.etProfileEmail);

		profileCity = (Button) view.findViewById(R.id.b_profile_city);
		profileCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(getActivity(), SearchCountryActivity.class), SELECT_PLACE);
			}
		});

		currentPassword = (EditText) view.findViewById(R.id.etProfileCurrent);

		newPassword = (EditText) view.findViewById(R.id.etProfileNew);

		ConfirmPassword = (EditText) view.findViewById(R.id.etProfileconfirm);

		((Button) view.findViewById(R.id.btn_Add_Friends)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				pushFragment(new MyContactFriendsFragments());
			}
		});

		((Button) view.findViewById(R.id.btn_set_reminder)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				TimePickerDialog picker = new TimePickerDialog(getActivity(), timePickerListener, hour, minute, false);
				picker.setTitle("Remind me to pray at");
				picker.show();
			}
		});

		privacyButton = (Button) view.findViewById(R.id.b_Private_Profile);
		privacyMessage = (OraTextView) view.findViewById(R.id.tv_privacy_message);

		// Set info
		if (WSGetProfile.getResponse() == null || !WSGetProfile.getResponse().isStatus()) {
			new LoadProfileActionDialog(getActivity()).init();
		} else {
			setBasicProfileInformation();
		}

		return view;
	}

	private void setBasicProfileInformation() {

		// Set data
		profileName.setText(WSGetProfile.getResponse().getProfileUser().getName());
		profileAbout.setText(WSGetProfile.getResponse().getProfileUser().getAbout());
		profileEmail.setText(WSGetProfile.getResponse().getProfileUser().getEmail());
		profileCity.setText(WSGetProfile.getResponse().getProfileUser().getCity());

		// Load image
		if (WSGetProfile.getResponse().getProfileUser().getProfilePicture().trim().length() > 0) {
			List<ImageView> pictures = Arrays.asList(pictureImage);
			List<ImageView> picturesFaded = Arrays.asList(backgroundImage);

			DownloadProfilePicture asyncJob = new DownloadProfilePicture(getActivity(), SettingsFragment.this, pictures,
					picturesFaded, "SettingsFragment");
			SettingsFragment.this.getAsyncTaskList().add(asyncJob);
			asyncJob.execute(WSGetProfile.getResponse().getProfileUser().getProfilePicture().trim());

			pictureImage.setVisibility(View.VISIBLE);
			marginImage.setBackgroundResource(R.drawable.profile_image_margin);
			marginImage.invalidate();
		}

		// Configure privacy button/message
		if (WSGetProfile.getResponse().getProfileUser().isPrivateProfile()) {
			privacyButton.setText(getString(R.string.profile_setting_btn_public));
			privacyMessage.setText(getString(R.string.profile_setting_text_public_message));
		} else {
			privacyButton.setText(getString(R.string.profile_setting_btn_privacy));
			privacyMessage.setText(getString(R.string.profile_setting_text_message));
		}
		privacyButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				WSGetProfile.getResponse().getProfileUser().changePrivateProfile();
				new EditProfileDialog(getActivity()).init();
			}
		});
	}

	private TimePickerDialog.OnTimeSetListener timePickerListener = new TimePickerDialog.OnTimeSetListener() {
		public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
			hour = selectedHour;
			minute = selectedMinute;

			if (notificationSelected.isChecked()) {
				if ((hour != -1) && (minute != -1)) {
					AlarmManager manager = (AlarmManager) getActivity().getSystemService(getActivity().ALARM_SERVICE);

					manager.cancel(getNotificationIntent(getActivity()));

					Calendar cal = Calendar.getInstance();
					cal.setTimeInMillis(System.currentTimeMillis());
					cal.set(Calendar.HOUR_OF_DAY, hour);
					cal.set(Calendar.MINUTE, minute);
					cal.set(Calendar.SECOND, 0);

					manager.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis() + (1000 * 60 * 60 * 24),
							(1000 * 60 * 60 * 24), getNotificationIntent(getActivity()));
					((OraApplication) getActivity().getApplication()).getUser().setHaveNotification(true);
					((OraApplication) getActivity().getApplication()).getUser().setHour(hour);
					((OraApplication) getActivity().getApplication()).getUser().setMinute(minute);

					WSGetProfile.getResponse().getProfileUser().setHaveNotification(true);
					WSGetProfile.getResponse().getProfileUser().setHour(hour);
					WSGetProfile.getResponse().getProfileUser().setMinute(minute);

					((OraApplication) getActivity().getApplication()).persistUser();
				}
			} else {
				((OraApplication) getActivity().getApplication()).getUser().setHaveNotification(false);
				((OraApplication) getActivity().getApplication()).getUser().setHour(-1);
				((OraApplication) getActivity().getApplication()).getUser().setMinute(-1);

				WSGetProfile.getResponse().getProfileUser().setHaveNotification(false);
				WSGetProfile.getResponse().getProfileUser().setHour(-1);
				WSGetProfile.getResponse().getProfileUser().setMinute(-1);

				((OraApplication) getActivity().getApplication()).persistUser();
			}
		}
	};

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == TAKE_PICTURE) {
			if (data != null) {
				if (data.hasExtra("data")) {
					Bitmap bitmap = data.getParcelableExtra("data");
					Bitmap bmpFaded = Blur.fastblur(getActivity(), bitmap, DownloadProfilePicture.BLUR_RATIO);

					backgroundImage.setImageBitmap(bmpFaded);
					pictureImage.setImageBitmap(bitmap);

					pictureImage.setVisibility(View.VISIBLE);
					marginImage.setBackgroundResource(R.drawable.profile_image_margin);

					Uri selectedImage = Uri.parse(MediaStore.Images.Media.insertImage(getActivity().getContentResolver(), bitmap,
							"", ""));

					String[] filePathColumn = { MediaStore.Images.Media.DATA };

					Cursor cursor = getActivity().getContentResolver().query(selectedImage, filePathColumn, null, null, null);
					cursor.moveToFirst();

					int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
					String final_path = cursor.getString(columnIndex);
					cursor.close();

					System.out.println(final_path);

					setImageFilePath(final_path);
				}
			}
		} else if (requestCode == SELECT_PICTURE) {
			if (data != null) {
				Uri selectedImage = data.getData();
				String urlPath = selectedImage.toString();

				String[] filePathColumn = { MediaStore.Images.Media.DATA };

				Cursor cursor = getActivity().getContentResolver().query(selectedImage, filePathColumn, null, null, null);
				cursor.moveToFirst();

				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String filePath = cursor.getString(columnIndex);
				cursor.close();

				System.out.println(urlPath);
				System.out.println(filePath);

				setImage(selectedImage, filePath);
			}
		} else if ((requestCode == SELECT_PLACE) && (resultCode == android.app.Activity.RESULT_OK)) {
			searchCityStateResponse = data.getStringExtra("city_state");
			profileCity.setText(searchCityStateResponse);
			if (searchCityStateResponse.length() > 0) {
				new EditProfileDialog(getActivity()).init();
			}
		}
	}

	@Override
	public void onResume() {
		super.onResume();

		if (searchCityStateResponse != null) {
			if (searchCityStateResponse.length() > 0) {
				new EditProfileDialog(getActivity()).init();
			}
			searchCityStateResponse = null;
		}
	}

	private void setImageFilePath(String path) {
		this.imageFilePath = path;
	}

	private void setImage(Uri selectedImage, String filePath) {
		if (selectedImage != null) {
			InputStream is;
			try {
				is = getActivity().getContentResolver().openInputStream(selectedImage);
				BufferedInputStream bis = new BufferedInputStream(is);
				Bitmap bitmap = BitmapFactory.decodeStream(bis);
				Bitmap bmpFaded = Blur.fastblur(getActivity(), bitmap, DownloadProfilePicture.BLUR_RATIO);

				backgroundImage.setImageBitmap(bmpFaded);
				pictureImage.setImageBitmap(bitmap);

				pictureImage.setVisibility(View.VISIBLE);
				marginImage.setBackgroundResource(R.drawable.profile_image_margin);

				setImageFilePath(filePath);
			} catch (FileNotFoundException e) {

			}
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		SubMenu sub = menu.addSubMenu(0, 0, 3, getString(R.string.profile_settings__mi_settings));
		sub.setIcon(R.drawable.profile_btn_settings);
		sub.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

		// Save
		SubMenu sub1 = sub.addSubMenu(0, 0, 0, getString(R.string.profile_settings__mi_save));
		sub1.setIcon(R.drawable.profile_btn_save);
		sub1.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_WITH_TEXT);

		// Tutorial
		SubMenu sub0 = sub.addSubMenu(0, 1, 1, getString(R.string.profile_settings__mi_tutorial));
		sub0.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_WITH_TEXT);

		// Logout
		SubMenu sub2 = sub.addSubMenu(0, 2, 2, getString(R.string.profile_settings__mi_logout));
		sub2.setIcon(R.drawable.profile_btn_logout);
		sub2.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_WITH_TEXT);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		AlarmManager manager = (AlarmManager) getActivity().getSystemService(getActivity().ALARM_SERVICE);
		switch (item.getOrder()) {
		case 0:// Guardar
			boolean connectWithServer = true;

			if (connectWithServer) {
				if ((currentPassword.getText().length() > 0) || (newPassword.getText().length() > 0)
						|| (ConfirmPassword.getText().length() > 0)) {
					if ((newPassword.getText().toString().equals(ConfirmPassword.getText().toString()))
							&& (!currentPassword.getText().toString().equals(newPassword.getText().toString()))) {
						new EditProfileDialog(getActivity()).init();
					} else {
						if (!newPassword.getText().toString().equals(ConfirmPassword.getText().toString())) {
							GeneralMethods.crearDialogoOk("New password and confirmation password don't match.", getActivity());
						} else {
							GeneralMethods.crearDialogoOk("New password can't be the same as before.", getActivity());
						}
					}
				} else {
					new EditProfileDialog(getActivity()).init();
				}
			}
			break;
		case 2:// Cerrar Sesión
				// Cancel all notifications
			onLogout(manager, getActivity());
			break;
		case 1:
			// Go to Tutorial Activity
			Intent intent = new Intent(getActivity(), TutorialActivity.class);
			startActivity(intent);
		}
		return false;
	}

	public static void onLogout(AlarmManager manager, Activity activity) {
		// Cancel all notifications
		manager.cancel(getNotificationIntent(activity));

		// Remove user information
		UserOraTableManager.forgetUser(activity);

		// Closing fb session if that is open
		InviteFriendsButton facebookButton = new InviteFriendsButton(activity);
		if (facebookButton.getSessionTracker() != null) {
			Session openSession = facebookButton.getSessionTracker().getOpenSession();
			if (openSession != null) {
				openSession.closeAndClearTokenInformation();
			}
		}

		// Cleaning the cookie
		PersistentCookieStore cookieStore = new PersistentCookieStore(activity);
		cookieStore.clear();

		// Opening the initial activity (where you decided login with fb or
		// normal)
		activity.startActivity(new Intent(activity, InitialActivity.class));

		// closing the activity
		// boolean isLast = activity.isTaskRoot();
		// do {
		// isLast = activity.isTaskRoot();
		if (activity instanceof MainActivity) {
			((MainActivity) activity).superFinish();
		} else {
			activity.finish();
		}
		// } while(!isLast);

		FeedDBHelper helper = OpenHelperManager.getHelper(activity, FeedDBHelper.class);
		helper.clearData();
		OpenHelperManager.releaseHelper();

		// Clear application data
		((OraApplication) activity.getApplication()).clearData();
	}

	public static PendingIntent getNotificationIntent(Activity activity) {
		Intent broadcastIntent = new Intent(activity.getBaseContext(), ShowNotification.class);
		return PendingIntent.getBroadcast(activity, 0, broadcastIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	}

	public class LoadProfileActionDialog extends ActionDialog<Void> {

		public LoadProfileActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			String userId = null;
			if (userId == null) {
				userId = Integer.toString(((OraApplication) getActivity().getApplication()).getUser().getId());
			}

			WSGetProfile.getProfile((OraApplication) getActivity().getApplication(), getContext(), userId);
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				setBasicProfileInformation();
			}
		}
	}

	public class EditProfileDialog extends ActionDialog<Void> {

		public EditProfileDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			WSEditProfile.editProfile((OraApplication) getActivity().getApplication(), getContext(), profileName.getText()
					.toString(), profileAbout.getText().toString(), profileEmail.getText().toString(), WSGetProfile.getResponse()
					.getProfileUser().getMobile(), profileCity.getText().toString(), newPassword.getText().toString(),
					currentPassword.getText().toString(), WSGetProfile.getResponse().getProfileUser().isPrivateProfile(),
					imageFilePath);
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				if (WSEditProfile.getResponse().getProfileUser() != null) {
					WSGetProfile.getResponse().setProfileUser((WSEditProfile.getResponse().getProfileUser()));
					if (WSEditProfile.getResponse().getProfileUser().isPrivateProfile()) {
						Log.i("SettingsFragment", "is Private");
						privacyButton.setText(getString(R.string.profile_setting_btn_public));
						privacyMessage.setText(getString(R.string.profile_setting_text_public_message));
					} else {
						Log.i("SettingsFragment", "is Public");
						privacyButton.setText(getString(R.string.profile_setting_btn_privacy));
						privacyMessage.setText(getString(R.string.profile_setting_text_message));
					}

					getActivity().setTitle(((OraApplication) getActivity().getApplication()).getUser().getName());
				} else {
					GeneralMethods.crearDialogoOk(WSEditProfile.getResponse().getMessage(), context);
				}
			}
		}

	}

}
