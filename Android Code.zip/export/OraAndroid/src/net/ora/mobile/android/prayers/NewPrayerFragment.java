package net.ora.mobile.android.prayers;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.MyCirclesFragment;
import net.ora.mobile.android.circles.RelatedCirclesActionDialog;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.prayers.WSCreatePrayer;
import net.ora.mobile.android.webservices.profile.WSShareOnFacebook;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.prayers.Prayer;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadAnyImage;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGFragment;

public class NewPrayerFragment extends DGFragment implements OnCheckedChangeListener,
		RelatedCirclesActionDialog.OnRelatedCirclesLoadedListener {

	public static final int ITEM_PRAY = 1;

	private List<Circle> circles;
	private boolean shouldShareCircles;
	private boolean shouldShareWithFacebook;
	private boolean[] selectedCircles;

	private View view;
	private TextView txtPrayerText;
	private ViewGroup viewShareCircles;

	protected void setCircles(List<Circle> circles) {
		this.circles = circles;

		this.selectedCircles = new boolean[circles.size()];

		initCirclesView(circles);
	}

	@Override
	protected int getActionBarString() {
		return R.string.newPrayer_title;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_new_prayer, container, false);

		// Set Circles Share Toggle Button listener
		ToggleButton button;
		button = (ToggleButton) view.findViewById(R.id.newPrayer_tbtnShareCircles);
		button.setOnCheckedChangeListener(this);
		button = (ToggleButton) view.findViewById(R.id.newPrayer_tbtnShareFacebook);
		button.setOnCheckedChangeListener(this);

		// Text view
		txtPrayerText = (TextView) view.findViewById(R.id.newPrayer_txtPrayer);

		// Share Circles List View
		viewShareCircles = (ViewGroup) view.findViewById(R.id.newPrayer_layoutShareCircleList);

		// Share circles option
		shouldShareCircles = false;
		shouldShareWithFacebook = false;

		// Load circles list
		new RelatedCirclesActionDialog(getActivity(), ((OraApplication) getActivity().getApplication()).getUser(), false, this)
				.init();

		return view;
	}

	@Override
	public void onLoaded(List<Circle> circles) {
		setCircles(circles);
	}

	protected void initCirclesView(List<Circle> circles) {
		if (getActivity() == null) {
			return;
		}

		// width of the picture
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());

		// List of image views
		List<ImageView> pictureViews = new ArrayList<ImageView>();
		List<String> pictureUrls = new ArrayList<String>();

		// Load circles
		for (int i = 0; i < circles.size(); i++) {
			final Circle circle = circles.get(i);

			LayoutInflater inflater = LayoutInflater.from(getActivity());
			View viewCircle = inflater.inflate(R.layout.list_prayer_circle, null);

			final int circlePos = i;
			viewCircle.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					onShareWithCircleClick(circlePos, circle);
				}
			});

			TextView lblName = (TextView) viewCircle.findViewById(R.id.itemCircle_lblName);
			lblName.setText(circle.getName());

			TextView lblType = (TextView) viewCircle.findViewById(R.id.itemCircle_tvType);
			lblType.setText(circle.getSecurityLevelId());

			TextView lblCity = (TextView) viewCircle.findViewById(R.id.itemCircle_lblCity);
			lblCity.setText(circle.getCity());

			ImageView imgPicture = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivImage);
			imgPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			((ImageView) viewCircle.findViewById(R.id.itemCircle_ivCheck))
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			if (circle.getPicture() != null && circle.getPicture().length() > 0) {
				pictureViews.add(imgPicture);
				pictureUrls.add(circle.getPicture());
			}

			viewShareCircles.addView(viewCircle);
		}

		// Load images
		DownloadAnyImage asyncLoadCirclesPictures = new DownloadAnyImage("Load circles' pictures", getActivity());
		asyncLoadCirclesPictures.setListPictures(pictureViews);
		asyncLoadCirclesPictures.execute(MyCirclesFragment.toArray(pictureUrls));
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch (buttonView.getId()) {
		case R.id.newPrayer_tbtnShareCircles:
			InputMethodManager im = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
			if (isChecked) {
				viewShareCircles.setVisibility(View.VISIBLE);
				shouldShareCircles = true;
				im.hideSoftInputFromWindow(txtPrayerText.getApplicationWindowToken(), 0);
			} else {
				viewShareCircles.setVisibility(View.GONE);
				shouldShareCircles = false;
				im.showSoftInput(txtPrayerText, 0);
				txtPrayerText.requestFocus();
			}
			break;
		case R.id.newPrayer_tbtnShareFacebook:
			shouldShareWithFacebook = !shouldShareWithFacebook;
			break;
		}
	}

	public void onShareWithCircleClick(int index, Circle circle) {
		// Set new state of the circle
		selectedCircles[index] = !selectedCircles[index];

		// Change image
		View viewCircle = viewShareCircles.getChildAt(index);
		ImageView imageView = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivState);
		if (selectedCircles[index]) {
			imageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_check_grey_checked));
		} else {
			imageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_check_grey_unchecked));
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		// Vars
		MenuItem sub;

		// Create circle button
		sub = menu.add(0, ITEM_PRAY, Menu.NONE, getString(R.string.newPrayer_btnPray));
		sub.setIcon(R.drawable.ic_submit_prayer);
		sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case ITEM_PRAY:
			onPrayClick(null);
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	public void onPrayClick(View view) {
		new NewPrayerActionDialog(getActivity()).init();
	}

	public void clearData() {
		if (view == null) {
			return;
		}

		// Clear new prayer screen
		if (txtPrayerText != null) {
			txtPrayerText.setText("");
		}

		// Clear selected circles
		if (selectedCircles != null) {
			for (int i = 0; i < selectedCircles.length; i++) {
				selectedCircles[i] = false;
			}
		}

		// Hide circles list
		((CompoundButton) view.findViewById(R.id.newPrayer_tbtnShareCircles)).setChecked(false);
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class NewPrayerActionDialog extends ActionDialog<Prayer> {

		public NewPrayerActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Prayer performAction() {
			List<Circle> shareCircles = new ArrayList<Circle>();
			if (shouldShareCircles) {
				for (int i = 0; i < selectedCircles.length; i++) {
					if (selectedCircles[i]) {
						shareCircles.add(circles.get(i));
					}
				}
			}

			final String text = ((TextView) view.findViewById(R.id.newPrayer_txtPrayer)).getText().toString();

			WSCreatePrayer.createPrayer(context, shareCircles, text);

			if (!MasterService.isFailedConnection()) {
				if (shouldShareWithFacebook) {
					getActivity().runOnUiThread(new Runnable() {

						@Override
						public void run() {
							if (WSShareOnFacebook.isFacebookLogin()) {
								WSShareOnFacebook.share(getActivity(), text);
							} else {
								Toast.makeText(getContext(), getString(R.string.newPrayer_errorShareFacebook), Toast.LENGTH_SHORT)
										.show();
							}
						}
					});
				}
			}
			return null;
		}

		@Override
		public void afterAction(Prayer result) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				popAllFragments(new NewPrayerFragment());
				getSherlockActivity().getSupportActionBar().getTabAt(0).select();
			}
		}

	}
}
