package net.ora.mobile.android.activity;

import java.util.ArrayList;
import java.util.List;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.activity.WSRequestNotification;
import net.ora.mobile.dto.activity.Notification;
import net.ora.mobile.dto.activity.response.PrayersInteractionsResponse;
import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

public class ActivityFragment extends CachedImageDataFragment implements RadioGroup.OnCheckedChangeListener {

	// private String TAG = "ActivityFragment";
	private static final int TYPE_ALL_NOTIFICATIONS = 0;
	private static final int TYPE_PRAYERS_NOTIFICATIONS = 10;
	private static final int TYPE_CIRCLES_NOTIFICATIONS = 20;

	private int notificationsFeedType;

	private List<Notification> allNotifications;
	private boolean firstTimeLoadingAllNotificaitons;
	private boolean loadingAllNotificaitons;
	private int nextPageAllNotifications = 1;
	private PullToRefreshListView lvAllNotifications;
	private NotificationArrayAdapter allNotificationsAdapter;

	private List<Notification> prayersNotifications;
	private boolean firstTimeLoadingPrayersNotificaitons;
	private boolean loadingPrayersNotificaitons;
	private int nextPagePrayersNotifications = 1;
	private PullToRefreshListView lvPrayersNotifications;
	private NotificationArrayAdapter prayersNotificationsAdapter;

	private List<Notification> circlesNotifications;
	private boolean firstTimeLoadingCirclesNotificaitons;
	private boolean loadingCirclesNotificaitons;
	private int nextPageCirclesNotifications = 1;
	private PullToRefreshListView lvCirclesNotifications;
	private NotificationArrayAdapter circlesNotificationsAdapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getActivity().setTitle(getString(R.string.activity_title));
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Create view
		View view = inflater.inflate(R.layout.fragment_activity, container, false);

		// Set listeners
		((RadioGroup) view.findViewById(R.id.activity_rgOptions)).setOnCheckedChangeListener(this);

		// Set instance data
		notificationsFeedType = TYPE_ALL_NOTIFICATIONS;

		// // All notifications
		nextPageAllNotifications = 1;
		loadingAllNotificaitons = false;
		firstTimeLoadingAllNotificaitons = true;
		allNotifications = new ArrayList<>();
		lvAllNotifications = (PullToRefreshListView) view.findViewById(R.id.lv_all);
		lvAllNotifications.setEmptyView(view.findViewById(R.id.tv_emptyList_all));
		allNotificationsAdapter = new NotificationArrayAdapter(getActivity(), this, allNotifications);
		lvAllNotifications.setAdapter(allNotificationsAdapter);
		lvAllNotifications.setOnRefreshListener(onRefreshAllNotificationsListener);
		lvAllNotifications.setOnScrollListener(allNotificationsOnScrollListener);

		// // Prayers notifications
		nextPagePrayersNotifications = 1;
		loadingPrayersNotificaitons = false;
		firstTimeLoadingPrayersNotificaitons = true;
		prayersNotifications = new ArrayList<>();
		lvPrayersNotifications = (PullToRefreshListView) view.findViewById(R.id.lv_prayers);
		lvPrayersNotifications.setEmptyView(view.findViewById(R.id.tv_emptyList_prayers));
		prayersNotificationsAdapter = new NotificationArrayAdapter(getActivity(), this, prayersNotifications);
		lvPrayersNotifications.setAdapter(prayersNotificationsAdapter);
		lvPrayersNotifications.setOnRefreshListener(onRefreshPrayersNotificationsListener);
		lvPrayersNotifications.setOnScrollListener(prayersNotificationsOnScrollListener);

		// // Circles notifications
		nextPageCirclesNotifications = 1;
		loadingCirclesNotificaitons = false;
		firstTimeLoadingCirclesNotificaitons = true;
		circlesNotifications = new ArrayList<>();
		lvCirclesNotifications = (PullToRefreshListView) view.findViewById(R.id.lv_circles);
		lvCirclesNotifications.setEmptyView(view.findViewById(R.id.tv_emptyList_circles));
		circlesNotificationsAdapter = new NotificationArrayAdapter(getActivity(), this, circlesNotifications);
		lvCirclesNotifications.setAdapter(circlesNotificationsAdapter);
		lvCirclesNotifications.setOnRefreshListener(onRefreshCirclesNotificationsListener);
		lvCirclesNotifications.setOnScrollListener(circlesNotificationsOnScrollListener);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		// Start loading new notifications
		refreshAllNotificationsFeed();
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		hideAllViews();
		switch (checkedId) {
		case R.id.rb_all:
			notificationsFeedType = TYPE_ALL_NOTIFICATIONS;
			if (firstTimeLoadingAllNotificaitons) {
				refreshAllNotificationsFeed();
			} else {
				lvAllNotifications.setVisibility(View.VISIBLE);
				allNotificationsAdapter.notifyDataSetChanged();
			}
			break;
		case R.id.rb_prayers:
			notificationsFeedType = TYPE_PRAYERS_NOTIFICATIONS;
			if (firstTimeLoadingPrayersNotificaitons) {
				refreshPrayersNotificationsFeed();
			} else {
				lvPrayersNotifications.setVisibility(View.VISIBLE);
				prayersNotificationsAdapter.notifyDataSetChanged();
			}
			break;
		case R.id.rb_circles:
			notificationsFeedType = TYPE_CIRCLES_NOTIFICATIONS;
			if (firstTimeLoadingCirclesNotificaitons) {
				refreshCirclesNotificationsFeed();
			} else {
				lvCirclesNotifications.setVisibility(View.VISIBLE);
				circlesNotificationsAdapter.notifyDataSetChanged();
			}
			break;
		}
	}

	/**
	 * Hide all list views, progress bar and empty list view.
	 */
	private void hideAllViews() {
		getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.tv_emptyList_all).setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.tv_emptyList_prayers).setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.tv_emptyList_circles).setVisibility(View.INVISIBLE);
		lvAllNotifications.setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.lv_prayers).setVisibility(View.INVISIBLE);
		getView().findViewById(R.id.lv_circles).setVisibility(View.INVISIBLE);
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private static void executeTask(LoadNotificationsAsyncTask task, int page) {
		if(Build.VERSION.SDK_INT > 11) {
			task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, page);
		} else {
			task.execute(page);
		}
	}

	/*
	 * ALL NOTIFICATIONS
	 */
	private void refreshAllNotificationsFeed() {
		if (!loadingAllNotificaitons) {
			if (allNotifications.size() == 0) {
				hideAllViews();
				getView().findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
				lvAllNotifications.onRefreshComplete();
			}

			LoadAllNotificationsAsyncTask task = new LoadAllNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, 1);
		} else {
			lvAllNotifications.onRefreshComplete();
		}
	}

	private void loadNextPageAllNotificationsFeed() {
		if (!loadingAllNotificaitons && nextPageAllNotifications > 0) {
			LoadAllNotificationsAsyncTask task = new LoadAllNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, nextPageAllNotifications);
		}
	}

	private OnRefreshListener<ListView> onRefreshAllNotificationsListener = new OnRefreshListener<ListView>() {
		@Override
		public void onRefresh(PullToRefreshBase<ListView> refreshView) {
			refreshAllNotificationsFeed();
		}
	};

	private OnScrollListener allNotificationsOnScrollListener = new OnScrollListener() {
		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
				loadNextPageAllNotificationsFeed();
			}
		}
	};

	/*
	 * PRAYERS NOTIFICATIONS
	 */
	private void refreshPrayersNotificationsFeed() {
		if (!loadingPrayersNotificaitons) {
			if (prayersNotifications.size() == 0) {
				hideAllViews();
				getView().findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
				lvPrayersNotifications.onRefreshComplete();
			}

			LoadPrayersNotificationsAsyncTask task = new LoadPrayersNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, 1);
		} else {
			lvPrayersNotifications.onRefreshComplete();
		}
	}

	private void loadNextPagePrayersNotificationsFeed() {
		if (!loadingPrayersNotificaitons && nextPagePrayersNotifications > 0) {
			LoadPrayersNotificationsAsyncTask task = new LoadPrayersNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, nextPagePrayersNotifications);
		}
	}

	private OnRefreshListener<ListView> onRefreshPrayersNotificationsListener = new OnRefreshListener<ListView>() {
		@Override
		public void onRefresh(PullToRefreshBase<ListView> refreshView) {
			refreshPrayersNotificationsFeed();
		}
	};

	private OnScrollListener prayersNotificationsOnScrollListener = new OnScrollListener() {
		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
				loadNextPagePrayersNotificationsFeed();
			}
		}
	};

	/*
	 * CICLES NOTIFICATIONS
	 */
	private void refreshCirclesNotificationsFeed() {
		if (!loadingCirclesNotificaitons) {
			if (circlesNotifications.size() == 0) {
				hideAllViews();
				getView().findViewById(R.id.pbLoading).setVisibility(View.VISIBLE);
				lvCirclesNotifications.onRefreshComplete();
			}

			LoadCirclesNotificationsAsyncTask task = new LoadCirclesNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, 1);
		} else {
			lvCirclesNotifications.onRefreshComplete();
		}
	}

	private void loadNextPageCirclesNotificationsFeed() {
		if (!loadingCirclesNotificaitons && nextPageCirclesNotifications > 0) {
			LoadCirclesNotificationsAsyncTask task = new LoadCirclesNotificationsAsyncTask();
			getAsyncTaskList().add(task);
			executeTask(task, nextPageCirclesNotifications);
		}
	}

	private OnRefreshListener<ListView> onRefreshCirclesNotificationsListener = new OnRefreshListener<ListView>() {
		@Override
		public void onRefresh(PullToRefreshBase<ListView> refreshView) {
			refreshCirclesNotificationsFeed();
		}
	};

	private OnScrollListener circlesNotificationsOnScrollListener = new OnScrollListener() {
		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
				loadNextPageCirclesNotificationsFeed();
			}
		}
	};

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class LoadNotificationsAsyncTask extends AsyncTask<Integer, Void, PrayersInteractionsResponse> {

		private Notification firstNotification;
		private int filter;

		public LoadNotificationsAsyncTask(Notification firstNotification, int filter) {
			this.firstNotification = firstNotification;
			this.filter = filter;
		}

		@Override
		protected PrayersInteractionsResponse doInBackground(Integer... params) {
			int page = params[0];
			long notificationId = WSRequestNotification.NOTIFICATION_ID_ALL_NOTIFICATIONS;
			if (firstNotification != null) {
				notificationId = firstNotification.getId();
			}

			// Make request
			return WSRequestNotification.getPrayersNotifications(((OraApplication) getActivity().getApplication()),
					getActivity(), page, notificationId, filter);
		}

	}

	/**
	 * Loads the notifications feed.
	 */
	public class LoadAllNotificationsAsyncTask extends LoadNotificationsAsyncTask {

		public LoadAllNotificationsAsyncTask() {
			super((lvAllNotifications.isRefreshing() || allNotifications.size() == 0 ? null : allNotifications.get(0)),
					WSRequestNotification.FILTER_ALL_NOTIFICATIONS);
			loadingAllNotificaitons = true;
		}

		@Override
		protected void onPostExecute(PrayersInteractionsResponse response) {
			super.onPostExecute(response);

			boolean refreshing = lvAllNotifications.isRefreshing() || firstTimeLoadingAllNotificaitons;
			if (allNotifications.size() == 0) {
				getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
			} else {
				lvAllNotifications.onRefreshComplete();
			}

			if (WSRequestNotification.isFailedConnection()) {
				Toast.makeText(getActivity(), MasterService.getErrorMessage(), Toast.LENGTH_LONG).show();
			} else if (response != null) {
				// Feed data
				if (response.getFeed() != null) {
					if (refreshing) {
						allNotifications.clear();
					}
					allNotifications.addAll(response.getFeed());
					firstTimeLoadingAllNotificaitons = false;
				}

				// Next page
				nextPageAllNotifications = response.getNextPage();
			}

			if (notificationsFeedType == TYPE_ALL_NOTIFICATIONS) {
				lvAllNotifications.setVisibility(View.VISIBLE);
				allNotificationsAdapter.notifyDataSetChanged();
			}

			loadingAllNotificaitons = false;
		}
	}

	/**
	 * Loads the prayers notifications feed.
	 */
	public class LoadPrayersNotificationsAsyncTask extends LoadNotificationsAsyncTask {

		public LoadPrayersNotificationsAsyncTask() {
			super(
					(lvPrayersNotifications.isRefreshing() || prayersNotifications.size() == 0 ? null : prayersNotifications
							.get(0)), WSRequestNotification.FILTER_PRAYER_INTERACTIONS);
			loadingPrayersNotificaitons = true;
		}

		@Override
		protected void onPostExecute(PrayersInteractionsResponse response) {
			super.onPostExecute(response);

			boolean refreshing = lvPrayersNotifications.isRefreshing() || firstTimeLoadingPrayersNotificaitons;
			if (prayersNotifications.size() == 0) {
				getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
			} else {
				lvPrayersNotifications.onRefreshComplete();
			}

			if (WSRequestNotification.isFailedConnection()) {
				Toast.makeText(getActivity(), MasterService.getErrorMessage(), Toast.LENGTH_LONG).show();
			} else if (response != null) {
				// Feed data
				if (response.getFeed() != null) {
					if (refreshing) {
						prayersNotifications.clear();
					}
					prayersNotifications.addAll(response.getFeed());
					firstTimeLoadingPrayersNotificaitons = false;
				}

				// Next page
				nextPagePrayersNotifications = response.getNextPage();
			}

			if (notificationsFeedType == TYPE_PRAYERS_NOTIFICATIONS) {
				lvPrayersNotifications.setVisibility(View.VISIBLE);
				prayersNotificationsAdapter.notifyDataSetChanged();
			}

			loadingPrayersNotificaitons = false;
		}
	}

	/**
	 * Loads the circles notifications feed.
	 */
	public class LoadCirclesNotificationsAsyncTask extends LoadNotificationsAsyncTask {

		public LoadCirclesNotificationsAsyncTask() {
			super(
					(lvCirclesNotifications.isRefreshing() || circlesNotifications.size() == 0 ? null : circlesNotifications
							.get(0)), WSRequestNotification.FILTER_CIRCLE_INTERACTIONS);
			loadingCirclesNotificaitons = true;
		}

		@Override
		protected void onPostExecute(PrayersInteractionsResponse response) {
			super.onPostExecute(response);

			boolean refreshing = lvCirclesNotifications.isRefreshing() || firstTimeLoadingCirclesNotificaitons;
			if (circlesNotifications.size() == 0) {
				getView().findViewById(R.id.pbLoading).setVisibility(View.INVISIBLE);
			} else {
				lvCirclesNotifications.onRefreshComplete();
			}

			if (WSRequestNotification.isFailedConnection()) {
				Toast.makeText(getActivity(), MasterService.getErrorMessage(), Toast.LENGTH_LONG).show();
			} else if (response != null) {
				// Feed data
				if (response.getFeed() != null) {
					if (refreshing) {
						circlesNotifications.clear();
					}
					circlesNotifications.addAll(response.getFeed());
					firstTimeLoadingCirclesNotificaitons = false;
				}

				// Next page
				nextPageCirclesNotifications = response.getNextPage();
			}

			if (notificationsFeedType == TYPE_CIRCLES_NOTIFICATIONS) {
				lvCirclesNotifications.setVisibility(View.VISIBLE);
				circlesNotificationsAdapter.notifyDataSetChanged();
			}

			loadingCirclesNotificaitons = false;
		}
	}
}
