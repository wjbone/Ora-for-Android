package net.ora.mobile.android.webservices.prayers;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.response.AddLikeResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSAddLike extends MasterService {

	private static final String URL = "add_like/";

	public static AddLikeResponse addLike(Context context, int prayerId) {

		try {
			String strIsDev = OraApplication.IS_DEV ? "1" : "0";
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("prayer_id", Integer.toString(prayerId)));
			request.add(new BasicNameValuePair("is_dev", strIsDev));

			// Make request
			AddLikeResponse response = makeRequest(context,
					CONNECTION_TYPE.POST, URL, request,
					new TypeReference<AddLikeResponse>() {});

			return response;
			
		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}

		return null;
	}
}
