package net.ora.mobile.android.webservices.prayers;

import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.prayers.response.CommentsForPrayersResponse;
import net.ora.mobile.dto.prayers.response.PrayedUsersForPrayerResponse;

public class WSPrayedUsersForPrayer extends MasterService {

	private static final String URL = "prayed_users_for_prayer/";

	public static PrayedUsersForPrayerResponse getPrayedUserForPrayer(Context context, int prayerId) {

		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("prayer_id", Integer
					.toString(prayerId)));

			// Make request
			PrayedUsersForPrayerResponse response = makeRequest(context,
					CONNECTION_TYPE.GET, URL, request,
					new TypeReference<PrayedUsersForPrayerResponse>() {
					});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsRelatedCircles_error);
		}

		return null;
	}
}
