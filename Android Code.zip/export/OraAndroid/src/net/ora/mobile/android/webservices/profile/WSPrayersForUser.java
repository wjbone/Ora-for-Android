package net.ora.mobile.android.webservices.profile;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSPrayersForUser extends MasterService {

	private static final String URL = "prayers_for_user/";
	private static RequestPrayersResponse response;

	public static RequestPrayersResponse getResponse() {
		return response;
	}
	
	public static void searchPrayers(Context context, String userId, String page){
		response = null;
		
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("user_id", userId));			
			request.add(new BasicNameValuePair("prayer_id", "-1"));			
			request.add(new BasicNameValuePair("page", page));
			
			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< RequestPrayersResponse >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
	
}
