package net.ora.mobile.android.friends;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.circles.WSGetCircleProfile;
import net.ora.mobile.android.webservices.circles.WSJoinCircle;
import net.ora.mobile.android.webservices.circles.WSLeaveCircle;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.JoinCircleResponse;
import net.ora.mobile.dto.circles.response.LeaveCircleResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadAnyImage;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.asynctask.ObtainCirclePrayersAsync;
import com.digitalgeko.mobile.android.objects.friends.ActivityImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class ViewFriendCircleActivity extends ActivityImageData {

	public static final String TAG_CIRCLE = "circle";

	private Circle circle;

	private ViewGroup viewCirclePrayers;

	private ImageView imageBackgroundPicture;

	private ImageView userPicture;

	private LinearLayout pictureMargin;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_circles_view_circle);
		
		setDownloadFlag(true);
		Bundle extras = getIntent().getExtras();
		
		circle = new Circle();
		circle.setAbout(extras.getString("about"));
		circle.setApprovesMembers(extras.getBoolean("approvesMembers"));
		circle.setCity(extras.getString("city"));
		circle.setId(extras.getInt("id"));
		circle.setCommunity(extras.getBoolean("isEnterprise"));
		circle.setLite(extras.getBoolean("isLite"));
		circle.setMember(extras.getBoolean("isMember"));
		circle.setOwner(extras.getBoolean("isOwner"));
		circle.setPrivate(extras.getBoolean("isPrivate"));
		circle.setRequested(extras.getBoolean("isRequested"));
		circle.setName(extras.getString("name"));
		circle.setPicture(extras.getString("picture"));
		
		setTitle(circle.getName());

		// Join button configuration
		if (!circle.isOwner()) {
			Button temp = (Button) findViewById(R.id.viewCircle_btnJoin);
			temp.setVisibility(View.VISIBLE);
			
			if(circle.isMember()){
				temp.setText("Leave Circle");
			}else{
				temp.setText("Join Circle");
			}
		}
		
		// Prayers list view group
		viewCirclePrayers = (ViewGroup) findViewById(R.id.viewCircle_lstPrayers);
		
		/* ***********************************
		 * obtaining the profile picture view
		 * ***********************************
		 */
		int background_heigth = GeneralMethods.getProfileBackgroundWidth(this);
		int picture_width = (int) (background_heigth * 0.75);

		imageBackgroundPicture = (ImageView) findViewById(R.id.iv_Profile_Image_Background);
		imageBackgroundPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
						android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		userPicture = (ImageView) findViewById(R.id.iv_Profile_Picture);
		userPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
						picture_width, picture_width));

		pictureMargin = (LinearLayout) findViewById(R.id.ly_Profile_Margin_Picture);
		pictureMargin.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
						picture_width, picture_width));

		// Load circle info
		new LoadCircleProfileActionDialog(this, circle).init();
		
		// Load circle's picture
		if (circle.getPicture().trim().length() > 0) {
			List<ImageView> pictures = Arrays.asList(userPicture);
			List<ImageView> picturesFaded = Arrays.asList(imageBackgroundPicture);
			
			DownloadProfilePicture asyncJob = new DownloadProfilePicture(this, this, 
					pictures, picturesFaded, "ProfileFriendActivity Profile");
			asyncTaskList.add(asyncJob);
			asyncJob.execute(circle.getPicture());

			userPicture.setVisibility(View.VISIBLE);
			pictureMargin.setBackgroundResource(R.drawable.profile_image_margin);
			pictureMargin.invalidate();
		}
		
	}
	
	public void onLoadComplete(List<Prayer> data){
		if (data != null) {
			// Clear list
			viewCirclePrayers.removeAllViews();

			// Set vars
			int width = com.digitalgeko.mobile.android.accesories.GeneralMethods
					.getProfileImageWidth(this);

			// Inflate views
			LayoutInflater inflater = LayoutInflater.from(this);
			List<ImageView> pictureView = new ArrayList<ImageView>();
			List<String> pictureString = new ArrayList<String>();
			for (final Prayer prayer : data) {

				ViewGroup viewPrayer = (ViewGroup) inflater.inflate(
						R.layout.item_feed_prayer, null);
				
				// Set listeners
				TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
				descriptionView.setOnClickListener(new GoPrayerDetailManager(prayer, false));
				if (prayer.isLikeAvailable()) {
					View btnPray = viewPrayer
							.findViewById(R.id.feedPrayer_btnPray);
					ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
					btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer,
							containerView));
				} else {
					View btnPray = viewPrayer
							.findViewById(R.id.feedPrayer_btnPray);
					btnPray.setVisibility(View.GONE);
				}
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments).setOnClickListener(
						new GoPrayerDetailManager(prayer, true));
				if(prayer.getUser().equals( ((OraApplication)getApplication()).getUser())) {
					// Can see prays list only in is the owner of the pray
					viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(
							new GoPrayerPraysManager(prayer));
				}
				OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);
				

				// Set info
				((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer))
						.setText(prayer.getText());
				// Prayer User View
				TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
				prayerUserTextView.setText(prayer.getUser().getName());
				prayerUserTextView.setOnClickListener(goToProfileListener);

				// Go to user profile
				ImageView friendPicture = (ImageView) viewPrayer
						.findViewById(R.id.iv_profile_image_prayer);
				friendPicture.setOnClickListener(goToProfileListener);
				
				// Set circle
				ImageView circlePicture = (ImageView) viewPrayer
						.findViewById(R.id.iv_profile_circle_prayer);

				friendPicture
						.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
								width, width));
				circlePicture
						.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
								width, width));

				pictureImageViewList.add(friendPicture);
				circleImageViewList.add(circlePicture);
				
				// Save user/image view info
//				usersImagesViewsPairs[i++] = new Pair<User, ImageView>(prayer.getUser(), friendPicture);
				pictureView.add(friendPicture);

				// Circles
				int circlesCount = prayer.getCircles().size();
				String strCircles = "";
				if (circlesCount == 0) {
					viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
				} else {
					// Set listener
					viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(
							new GoPrayerCirclesManager(prayer));
					
					for(Circle circle : prayer.getCircles())
						strCircles += circle.getName() + ", ";
					strCircles = strCircles.substring(0, strCircles.length() - 2);
					// Set circles string
					((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer))
							.setText(strCircles);
				}

				// Set prayer likes count
				TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
				likesCount.setText(Integer.toString(prayer.getLikesCount()));

				// Set prayer comments count
				TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
				commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
				// Set prayer time
				TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
				timeCount.setText(GeneralMethods.fromDate(
								GeneralMethods.parseStringToDate(prayer.getDateCreated())));

				// Add view
				viewCirclePrayers.addView(viewPrayer);
				viewCirclePrayers.invalidate();
			}

//			for (final Prayer prayer : data) {
//				ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);
//
//				// Set listeners
//				viewPrayer.setOnClickListener(new View.OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						//prayer detail
//					}
//				});
//				
//				if (prayer.isLikeAvailable()) {
//					viewPrayer.setOnTouchListener(new SwipeToPrayDetector(prayer, viewPrayer));
//				} else {
//					View imgGrabber = viewPrayer
//							.findViewById(R.id.feedPrayer_imGrabber);
//					imgGrabber.setVisibility(View.GONE);
//				}
//				
//				((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
//				((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer)).setText(prayer.getUser().getRealName());
//				
//				// Go to user profile
//				ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
//				friendPicture.setOnClickListener(new View.OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						ViewFriendCircleActivity.this.startActivity(
//							new Intent(ViewFriendCircleActivity.this, ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
//					}
//				});
//
//				// Save user/image view info
//				pictureView.add(friendPicture);
//				pictureString.add(prayer.getUser().getProfilePicture());
//				
//				// Circles
//				int circlesCount = prayer.getCircles().size();
//				String firstCircle = "";
//				if (circlesCount >= 1){
//					firstCircle = prayer.getCircles().get(0).getName();
//				}
//				String strCircles = getResources().getQuantityString(R.plurals.viewCircle_lblItemPrayer_circles,
//									               circlesCount, firstCircle, circlesCount - 1);
//				// Set circles string
//				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);
//
//				// Set prayer likes count
//				((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer)).setText(Integer.toString(prayer.getLikesCount()));
//
//				// Set prayer comments count
//				((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer)).setText(Integer.toString(prayer.getCommentsCount()));
//
//				// Set prayer time
//				((TextView) viewPrayer.findViewById(R.id.tv_pray_time)).setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));
//
//				// Add view
//				viewCirclePrayers.addView(viewPrayer);
//				viewCirclePrayers.invalidate();
//			}

			// Start loading pictures
			DownloadAnyImage async = new DownloadAnyImage("ViewFriendCircleActivity", this);
			asyncTaskList.add(async);
			async.setListPictures(pictureView);
			
			String[] tempPictures = new String[pictureString.size()];
			for(int i = 0; i < pictureString.size(); i++){
				tempPictures[i] = pictureString.get(i);
			}
			
			async.execute(tempPictures);
		}
	}
	
	public void onCirclesViewPrayersClick(View view) {
		goToAllPrayers();
	}
	
	@Override
	public void goToAllPrayers() { 
		Intent intent = new Intent(this, ViewPrayersCircleActivity.class);
		intent.putExtra("circle_id", circle.getId());
		startActivity(intent);
	}
	
	public void onCirclesViewMembersClick(View view) {
		Intent intent = new Intent(this, ViewMembersCircleActivity.class);
		intent.putExtra("circle_id", circle.getId());
		startActivity(intent);
	}
	
	public void onCirclesButtonClick(View view){
		if(circle.isMember()){
			onCirclesLeaveCircleClick(view);
		}else{
			onCirclesJoinCircleClick(view);
		}
	}
	
	public void onCirclesLeaveCircleClick(View view) {
		GeneralMethods.showDialogYesNo(getString(R.string.viewCircle_askLeaveCircle,
			circle.getName()), this, this, new Runnable() {
				@Override
				public void run() {
					new LeaveCircleActionDialog(ViewFriendCircleActivity.this).init();
				}
			});
	}
	
	public void onCirclesJoinCircleClick(View view) {
		new JoinCircleActionDialog(this).init();
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class LoadCircleProfileActionDialog extends ActionDialog<Circle> {

		private Circle circle;

		public LoadCircleProfileActionDialog(Activity context, Circle circle) {
			super(context);
			this.circle = circle;
		}

		@Override
		public Circle preAction() {
//			if (circle instanceof Circle) {
//				return (Circle) circle;
//			}
			return super.preAction();
		}

		@Override
		public Circle performAction() {
			return WSGetCircleProfile.getCircleProfile(context, circle.getId());
		}

		@Override
		public void afterAction(Circle result) {
			// Validate result
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				finish();
				return;
			}

			TextView temp;

			// Set Prayers Count
			temp = (TextView) findViewById(R.id.viewCircle_lblPrayersQuantity);
			temp.setText(Integer.toString(result.getPrayersCount()));
 
			// Set Members Count
			temp = (TextView) findViewById(R.id.viewCircle_lblCirclesQuantity);
			temp.setText(Integer.toString(result.getMembersCount()));
			
			// Scope
			temp = (TextView) findViewById(R.id.circleProfile_tv_scope);
			temp.setText(circle.getSecurityLevelId());

			if(result.getPrayersCount() > 0){
				LayoutInflater inflater = LayoutInflater.from(context);
				viewCirclePrayers.addView(inflater.inflate(R.layout.item_loading, null));
				
				ObtainCirclePrayersAsync async = new ObtainCirclePrayersAsync(ViewFriendCircleActivity.this, viewCirclePrayers, ViewFriendCircleActivity.this, circle, 1); 
				asyncTaskList.add(async);
				async.execute();
			}
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class LeaveCircleActionDialog extends
			ActionDialog<LeaveCircleResponse> {

		public LeaveCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public LeaveCircleResponse performAction() {
			int circleId = circle.getId();
			return WSLeaveCircle.leaveCircle(context, circleId);
		}

		@Override
		public void afterAction(LeaveCircleResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
						context);
			} else {
				finish();
				Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
			}
		}

	}

	public class JoinCircleActionDialog extends
			ActionDialog<JoinCircleResponse> {

		public JoinCircleActionDialog(Activity context) {
			super(context);
		}

		@Override
		public JoinCircleResponse performAction() {
			int circleId = circle.getId();
			return WSJoinCircle.joinCircle(context, circleId);
		}

		@Override
		public void afterAction(JoinCircleResponse response) {
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(),
						context);
				return;
			}

			/*if (response.isMember() || response.isOwner()) {
				((OraApplication) getActivity().getApplication()).getCirclesManager().markToReload();
			}*/
			Toast.makeText(context, response.getMessage(), Toast.LENGTH_SHORT).show();
			View temp = findViewById(R.id.viewCircle_btnJoin);
			temp.setVisibility(View.GONE);
		}
	}

	
	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, boolean showOnlyComments) {
			this.prayer = prayer;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			startActivity(new Intent(ViewFriendCircleActivity.this, PrayerDetailActivity.class)
			.putExtra("friend_id", prayer.getUser().getId()));
//			pushFragment(PrayerDetailFragment.getInstance(prayer, showOnlyComments));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			startActivity(new Intent(ViewFriendCircleActivity.this, ProfileFriendActivity.class)
					.putExtra("friend_id", prayer.getUser().getId()));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerPraysManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
//			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerCirclesManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			if(prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
//				new Intent(ViewFriendCircleActivity.this, ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser().getId()));
//				pushFragment(ViewCircleFragment.getInstance(circle));
			} else {
//				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}
}
