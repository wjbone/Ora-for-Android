package net.ora.mobile.android;

import java.util.Arrays;
import java.util.Date;

import net.ora.mobile.android.help.TutorialActivity;
import net.ora.mobile.android.profile.RegisterContactFriendsActivity;
import net.ora.mobile.android.security.CreateAccountActivity;
import net.ora.mobile.android.security.LoginActivity;
import net.ora.mobile.android.ui.activities.OraSherlockActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSShareOnFacebook;
import net.ora.mobile.android.webservices.security.WSFacebookLogin;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.facebook.FacebookException;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.widget.LoginButton;
import com.facebook.widget.LoginButton.OnErrorListener;
import com.loopj.android.http.PersistentCookieStore;

public class InitialActivity extends OraSherlockActivity {
	
	private static final String TAG_HAS_SHOWN_TUTORIAL = "has_shown_tutorial";
	
	private String access_token;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Set layout
		setContentView(R.layout.activity_initial);
		
		/**
		 * Facebook Configuration
		 */
		
		OraApplication.setTimeToPray(false);
		
		if(getIntent().getExtras() != null){
			if(getIntent().getExtras().containsKey("notification")){
				OraApplication.setTimeToPray(true);
			}
		}
		
		PersistentCookieStore cookieStore = new PersistentCookieStore(this);
		cookieStore.clearExpired(new Date());
		if(cookieStore.getCookies().size() != 0){
			((OraApplication) getApplication()).setUser();
			startActivity(new Intent(this, MainActivity.class));
//			startActivity(new Intent(this, RegisterContactFriendsActivity.class));
			finish();
			
			// Show tutorial
			checkTutorial();

			return;
		}
		
		LoginButton authButton = (LoginButton) findViewById(R.id.initial_btnFBConnect);
		
		if(WSShareOnFacebook.isFacebookLogin()){
			Session openSession = authButton.getSessionTracker().getOpenSession();
			access_token = openSession.getAccessToken();
			Log.i("FB ReLogin", "Access Token: "+ openSession.getAccessToken());
			new LoginFacebookDialog(InitialActivity.this).init();
		}else{
			authButton.setApplicationId("257685094367122");			
			authButton.setReadPermissions(Arrays.asList("email", "friends_hometown"/*, "publish_actions", "publish_stream", "publish_checkins"*/));
			
			authButton.setOnErrorListener(new OnErrorListener() {
				@Override
				public void onError(FacebookException error) {
					Log.e("FBAutentication", "Error " + error.getMessage());
					Toast.makeText(InitialActivity.this, "We had a problem with facebook, try again later.", Toast.LENGTH_SHORT).show();
				}
			});

			authButton.setSessionStatusCallback(new Session.StatusCallback() {
				@Override
				public void call(Session session, SessionState state, Exception exception) {
					if (session.isOpened()) {
						access_token = session.getAccessToken();
						Log.i("FBAutentication", "Access Token: "+ session.getAccessToken());
						new LoginFacebookDialog(InitialActivity.this).init();
					}
				}
			});
		}
		
		// Show tutorial
		checkTutorial();
	}
	
	private void checkTutorial() {
		// Check for tutorial configuration
		SharedPreferences prefs = this.getSharedPreferences(
			      "net.ora.mobile.android", Context.MODE_PRIVATE);
		boolean hasShownTutorail = prefs.getBoolean(TAG_HAS_SHOWN_TUTORIAL, false); 
		if(!hasShownTutorail) {
			// Go to Tutorial Activity
			Intent intent = new Intent(this, TutorialActivity.class);
			startActivity(intent);
			
			prefs.edit().putBoolean(TAG_HAS_SHOWN_TUTORIAL, true).commit();
		}
	}

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
    }
    
    public class LoginFacebookDialog extends ActionDialog<Void>{
    	
    	public LoginFacebookDialog(Activity context){
    		super(context);
    	}
    	
    	@Override
    	public Void performAction() {
    		WSFacebookLogin.fb_auth((OraApplication) getApplication(), context, access_token);
    		if(!WSFacebookLogin.isFailedConnection()){
    			((OraApplication)getApplication()).setUser(WSFacebookLogin.getUsuario());
    		}
    		return null;
    	}
    	
    	@Override
    	public void afterAction(Void result){
    		if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				if(WSFacebookLogin.getResponse().getRegistered()){
					startActivity(new Intent(context, MainActivity.class));
					startActivity(new Intent(context, RegisterContactFriendsActivity.class));
				}else{
					startActivity(new Intent(context, MainActivity.class));
				}
				finish();
			}
    	}
    	
    }
	
	public void onLoginClick(View view) {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finish();
	}
	
	public void onCreateAccountClick(View view) {
		Intent intent = new Intent(this, CreateAccountActivity.class);
		startActivity(intent);
		finish();
	}
	
}
