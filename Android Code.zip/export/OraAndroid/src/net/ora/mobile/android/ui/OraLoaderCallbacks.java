package net.ora.mobile.android.ui;

import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;

public interface OraLoaderCallbacks<T> extends LoaderManager.LoaderCallbacks<T> {

	public void onAbandon(Loader<T> loader);
}
