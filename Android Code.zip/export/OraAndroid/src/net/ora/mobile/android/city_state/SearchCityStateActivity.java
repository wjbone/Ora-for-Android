package net.ora.mobile.android.city_state;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraSherlockActivity;
import net.ora.mobile.android.webservices.city_state.WSCityStateSearch;
import net.ora.mobile.dto.city_state.response.CityStateList;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;

public class SearchCityStateActivity extends OraSherlockActivity implements OnItemClickListener {

	private static final String TAG_LOG = "SearchCityStateActivity";

	public static final String TAG_ARG_COUNTRY_CODE = "country_code";

	private String countryCode;

	private ListView viewCitiesAndStatesList;
	private EditText searchText;
	private LoadingCityStateAsync task;
	private SearchCityListAdapter adapter;
	private View viewProgressBar;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_city_state);

		countryCode = getIntent().getStringExtra(SearchCityStateActivity.TAG_ARG_COUNTRY_CODE);

		viewCitiesAndStatesList = (ListView) findViewById(R.id.ly_cityStateList);
		viewCitiesAndStatesList.setOnItemClickListener(this);
		viewCitiesAndStatesList.setAdapter(getSearchCityListAdapter(null));

		viewProgressBar = findViewById(R.id.pbLoading);

		setTitle("");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		LayoutInflater inflater = LayoutInflater.from(this);
		View searchTextView = inflater.inflate(R.layout.item_search, null);

		ActionBar _actionBar = getSupportActionBar();
		_actionBar.setDisplayHomeAsUpEnabled(true);

		menu.add(Menu.NONE, Menu.NONE, 1, "Search").setIcon(R.drawable.ic_search).setActionView(searchTextView)
				.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

		searchText = (EditText) searchTextView.findViewById(R.id.et_search_view);
		searchText.setMinWidth((int) (GeneralMethods.getWidth(this) * 0.90));
		searchText.addTextChangedListener(new SearchFeedManager(searchText));
		searchText.setHint(R.string.selectCountry_lblSearchCity);
		searchText.requestFocus();

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;
		}
		return true;
	}

	// private Runnable searchCityState = new Runnable() {
	// @Override
	// public void run() {
	// if (searchText.getText().toString().trim().length() > 0) {
	// asyncSearch = new LoadingCityStateAsync("SearchCityStateActivity", SearchCityStateActivity.this);
	// asyncSearch.execute(searchText.getText().toString());
	// } else {
	// cityStateList.setAdapter(null);
	// cityStateList.invalidate();
	// }
	// }
	// };
	//
	// private void setLoading() {
	// cityStateList.setAdapter(getSearchCityListAdapter(null));
	// cityStateList.invalidate();
	//
	// vProgressBar.setVisibility(View.VISIBLE);
	// }

	@Override
	public void finish() {
		super.finish();

		if (task != null) {
			task.cancel(true);
		}
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		String cityState = (String) adapter.getItemAtPosition(position);
		setResult(android.app.Activity.RESULT_OK, new Intent().putExtra("city_state", cityState));
		finish();
	};

	private SearchCityListAdapter getSearchCityListAdapter(String[] citiesStates) {
		adapter = new SearchCityListAdapter(citiesStates);
		return adapter;
	}

	/*
	 * 
	 */
	public class LoadingCityStateAsync extends AsyncTask<String, Void, CityStateList> {

		private Activity context;

		public LoadingCityStateAsync(Activity context) {
			super();
			this.context = context;
		}

		@Override
		protected CityStateList doInBackground(String... word) {

			// Load cities
			WSCityStateSearch searchCity = new WSCityStateSearch();
			searchCity.search(context, word[0], countryCode);

			return searchCity.getResponse();
		}

		@Override
		protected void onPostExecute(CityStateList result) {
			super.onPostExecute(result);

			viewProgressBar.setVisibility(View.GONE);

			viewCitiesAndStatesList.setAdapter(getSearchCityListAdapter(result.getCitiesStates()));
			viewCitiesAndStatesList.setVisibility(View.VISIBLE);

			Log.i(TAG_LOG, "End loading data");
		}
	}

	/*
	 * 
	 */
	public class SearchFeedManager implements TextWatcher {

		private Handler mHandler;
		private EditText etSearch;

		// private LoadingCityStateAsync task;

		public SearchFeedManager(EditText text) {
			this.etSearch = text;
			mHandler = new Handler();
		}

		private Runnable searchRunnable = new Runnable() {
			@Override
			public void run() {
				mHandler.removeCallbacks(searchRunnable);
				if (etSearch.getText().toString().trim().length() > 0) {
					task = new LoadingCityStateAsync(SearchCityStateActivity.this);
					task.execute(etSearch.getText().toString());
				}
			}

		};

		@Override
		public void afterTextChanged(Editable s) {
			// Stop
			mHandler.removeCallbacks(searchRunnable);
			if (task != null)
				task.cancel(true);

			// Visual
			viewCitiesAndStatesList.setVisibility(View.GONE);

			if (s.length() > 0) {
				viewProgressBar.setVisibility(View.VISIBLE);
				mHandler.postDelayed(searchRunnable, 1500);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}
}
