package net.ora.mobile.android.city_state;

import net.ora.mobile.android.R;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SearchCityListAdapter extends BaseAdapter {
	
	private static final String TAG_LOG = "SearchCityListAdapter";

	private String[] citiesStates;
	
	public SearchCityListAdapter(String[] citiesStates) {
		this.citiesStates = citiesStates;
	}
	
	@Override
	public int getCount() {
		int count = 0;
		if(citiesStates != null) {
			count = citiesStates.length;
		}
		
		Log.i(TAG_LOG, "Count: " + count);
		return count;
	}

	@Override
	public Object getItem(int position) {
		return citiesStates[position];
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		Log.i(TAG_LOG, "Get view: " + position);
		
		SearchCityViewHolder holder;
		if(view == null) {
			
			LayoutInflater inflater = LayoutInflater.from(parent.getContext());
			view = inflater.inflate(R.layout.item_city_data, null);
			
			holder = new SearchCityViewHolder();
			holder.tvName = ((TextView) view.findViewById(R.id.tv_item_activity_name));
			view.setTag(holder);
		} else {
			holder = (SearchCityViewHolder) view.getTag();
			
			if(holder.position == position) {
				return view;
			}
		}
		
		// Set data
		holder.position = position;
		holder.tvName.setText(citiesStates[position]);
		
		return view;

	}
	

	
	/*
	 * 
	 */
	public static class SearchCityViewHolder {
		public int position;
		public TextView tvName;
	}
}
