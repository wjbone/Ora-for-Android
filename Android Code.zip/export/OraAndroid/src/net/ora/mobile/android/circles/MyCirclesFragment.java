package net.ora.mobile.android.circles;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.CachedImageDataFragment;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CircleSearchResponse;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.MenuItem.OnActionExpandListener;
import com.digitalgeko.mobile.android.asynctask.DownloadAnyImage;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

public class MyCirclesFragment extends CachedImageDataFragment implements
		RelatedCirclesActionDialog.OnRelatedCirclesLoadedListener {

	public static final int LOADER_ID_SEARCH_CIRCLES = 100;

	public static final int GROUP_CIRCLES = 1;
	private static final int ITEM_SEARCH = 0;
	private static final int ITEM_ADD = 1;

	private int page = 1;
	private boolean showLoading = true;
	private Handler mHandler;

	private View view;
	private ViewGroup viewMyCircles;
	private ViewGroup viewSearchCircles;
	private TextView searchText;

	private PullToRefreshScrollView mPullRefreshScrollView;

	@Override
	protected int getActionBarString() {
		return R.string.myCircles_title;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();

		// String name = ((OraApplication) getActivity().getApplication()).getUser().getName();
		// if ((name == null) || (name.trim().length() == 0)) {
		// name = ((OraApplication) getActivity().getApplication()).getUser().getUsername();
		// }
		// int index = name.indexOf(" ");
		// getActivity().setTitle(name.substring(0, ((index != -1 ? index : name.length()))) + "'s Circles");
	}

	private void stopRefreshing() {
		mPullRefreshScrollView.onRefreshComplete();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if (this.view != null) {
			return view;
		}

		view = inflater.inflate(R.layout.fragment_circles_my_circles, container, false);

		viewMyCircles = (ViewGroup) view.findViewById(R.id.myCircles_lstCircles);
		viewSearchCircles = (ViewGroup) view.findViewById(R.id.myCircles_lstSearchCircles);

		mPullRefreshScrollView = (PullToRefreshScrollView) view.findViewById(R.id.pull_refresh_scrollview);
		mPullRefreshScrollView.setOnRefreshListener(new OnRefreshListener<ScrollView>() {

			@Override
			public void onRefresh(PullToRefreshBase<ScrollView> refreshView) {
				stopRefreshing();
				new RelatedCirclesActionDialog(getActivity(), ((OraApplication) getActivity().getApplication()).getUser(), true,
						MyCirclesFragment.this).init();
			}
		});

		// Load circles list
		RelatedCirclesActionDialog dialog = new RelatedCirclesActionDialog(getActivity(), ((OraApplication) getActivity()
				.getApplication()).getUser(), false, this);
		getActionDialogList().add(dialog);
		dialog.init();

		return view;
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		if (view != null) {
			ViewGroup parentViewGroup = (ViewGroup) view.getParent();
			if (parentViewGroup != null) {
				parentViewGroup.removeAllViews();
			}
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
		super.onCreateOptionsMenu(menu, menuInflater);

		// Vars
		MenuItem sub;

		// // Build search view
		// LayoutInflater inflater = LayoutInflater.from(getActivity());
		// View searchTextView = inflater.inflate(R.layout.item_search, null);
		// searchText = (TextView) searchTextView
		// .findViewById(R.id.et_search_view);
		// searchText
		// .setMinWidth((int) (GeneralMethods.getWidth(getActivity()) * 0.75));
		// // searchText.setPadding(5, 1, 5, 1);
		// searchText
		// .addTextChangedListener(new SearchTextViewTextChangeListener());
		//
		// // Find circle button
		// sub = menu.add(GROUP_CIRCLES, ITEM_SEARCH, Menu.NONE,
		// getString(R.string.relatedCircles_btnFindCircles));
		// sub.setIcon(R.drawable.ic_search);
		// sub.setActionView(searchTextView);
		// sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW
		// | MenuItem.SHOW_AS_ACTION_ALWAYS);
		// sub.setOnActionExpandListener(new
		// SearchCircleActionExpandListener());

		// Find circle button
		sub = menu.add(GROUP_CIRCLES, ITEM_SEARCH, Menu.NONE, getString(R.string.relatedCircles_btnFindCircles));
		sub.setIcon(R.drawable.ic_search);
		sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

		// Create circle button
		sub = menu.add(GROUP_CIRCLES, ITEM_ADD, Menu.NONE, getString(R.string.relatedCircles_btnAddCircle));
		sub.setIcon(R.drawable.ic_add);
		sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case ITEM_ADD:
			pushFragment(new AddCircleFragment());
			break;
		case ITEM_SEARCH:
			pushFragment(new SearchCircleFragment());
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private <T extends Circle> void loadCirclesViews(List<T> circles, ViewGroup viewGroup, final boolean sendCircle) {
		// List of image views
		List<ImageView> pictureViews = new ArrayList<ImageView>();
		List<String> pictureUrls = new ArrayList<String>();

		// Variables
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
		LayoutInflater inflater = LayoutInflater.from(getActivity());

		// Load circles
		for (int i = 0; i < circles.size(); i++) {
			final Circle circle = circles.get(i);

			View viewCircle = inflater.inflate(R.layout.list_item_circle, null);

			// final int circlePos = i;
			viewCircle.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

					// if(!sendCircle) {
					// pushFragment(ViewCircleFragment.getInstance(circlePos));
					// } else {
					pushFragment(ViewCircleFragment.getInstance(circle));
					// }

				}
			});

			TextView lblName = (TextView) viewCircle.findViewById(R.id.itemCircle_lblName);
			lblName.setText(circle.getName());

			TextView lblType = (TextView) viewCircle.findViewById(R.id.itemCircle_tvType);
			lblType.setText(circle.getSecurityLevelId());

			TextView lblCity = (TextView) viewCircle.findViewById(R.id.itemCircle_lblCity);
			lblCity.setText(circle.getCity());

			ImageView imgPicture = (ImageView) viewCircle.findViewById(R.id.itemCircle_ivImage);
			imgPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			((ImageView) viewCircle.findViewById(R.id.itemCircle_ivCheck))
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			if (circle.getPicture() != null && circle.getPicture().length() > 0) {
				pictureViews.add(imgPicture);
				pictureUrls.add(circle.getPicture());
			}

			viewGroup.addView(viewCircle);
			if (i != circles.size() - 1) {
				View viewSeparator = inflater.inflate(R.layout.item_separator, null);
				viewGroup.addView(viewSeparator);
			}

			// Configure settings
			setActionButtons(circle, viewCircle);
		}

		// Load images
		DownloadAnyImage asyncLoadCirclesPictures = new DownloadAnyImage("Load circles' pictures", getActivity());
		asyncLoadCirclesPictures.setListPictures(pictureViews);
		asyncLoadCirclesPictures.execute(MyCirclesFragment.toArray(pictureUrls));
	}

	public static String[] toArray(List<String> strings) {
		String[] values = new String[strings.size()];
		for (int i = 0; i < strings.size(); i++) {
			values[i] = strings.get(i);
		}

		return values;
	}

	private void setActionButtons(Circle circle, View viewCircle) {
		// Set up the image
		ImageView imgCheckGreen = (ImageView) viewCircle.findViewById(R.id.ib_item_accepted);
		ImageView imgPending = (ImageView) viewCircle.findViewById(R.id.ib_item_pending);
		ImageView imgAdd = (ImageView) viewCircle.findViewById(R.id.ib_item_add);

		if (circle.isOwner() || circle.isMember()) {
			// Is member
			imgCheckGreen.setVisibility(View.VISIBLE);
			imgPending.setVisibility(View.GONE);
			imgAdd.setVisibility(View.GONE);
		} else {
			if (circle.isRequested()) {
				// Pending
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.VISIBLE);
				imgAdd.setVisibility(View.GONE);

				// Set listener
				// imgPending
				// .setOnClickListener(new RemoveRequestManager(
				// circle, viewCircle));
			} else {
				// Unknown
				imgCheckGreen.setVisibility(View.GONE);
				imgPending.setVisibility(View.GONE);
				imgAdd.setVisibility(View.VISIBLE);

				// Set listener
				// imgAdd.setOnClickListener(new AddFriendManager(
				// circle, viewCircle));
			}
		}
	}

	private Runnable searchCircleRunnable = new Runnable() {
		@Override
		public void run() {
			if (searchText.getText().toString().trim().length() > 0) {
				getActivity().getSupportLoaderManager()
						.restartLoader(LOADER_ID_SEARCH_CIRCLES, null, new SearchCirclesCallback());
			} else {
				viewSearchCircles.removeAllViews();
			}
		}
	};

	private void setLoading() {
		viewSearchCircles.removeAllViews();

		LayoutInflater inflater = LayoutInflater.from(getActivity());
		View loadingView = inflater.inflate(R.layout.item_city_loading, null);

		viewSearchCircles.addView(loadingView);
	}

	@Override
	public void onLoaded(List<Circle> circles) {
		viewMyCircles.removeAllViews();
		loadCirclesViews(circles, viewMyCircles, false);
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class SearchTextViewTextChangeListener implements TextWatcher {

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			page = 1;
			viewSearchCircles.removeAllViews();

			mHandler.removeCallbacks(searchCircleRunnable);
			mHandler.postDelayed(searchCircleRunnable, 1000);
			if (showLoading) {
				setLoading();
				showLoading = false;
			}
			if (s.toString().length() == 0) {
				showLoading = true;
			}
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class SearchCircleActionExpandListener implements OnActionExpandListener {
		@Override
		public boolean onMenuItemActionCollapse(MenuItem item) {
			viewMyCircles.setVisibility(View.VISIBLE);
			viewSearchCircles.setVisibility(View.GONE);
			return true; // Return true to collapse action view
		}

		@Override
		public boolean onMenuItemActionExpand(MenuItem item) {
			page = 1;
			viewMyCircles.setVisibility(View.GONE);
			viewSearchCircles.setVisibility(View.VISIBLE);
			searchText.clearFocus();
			return true; // Return true to expand action view
		}
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class SearchCirclesCallback implements LoaderManager.LoaderCallbacks<CircleSearchResponse> {

		@Override
		public Loader<CircleSearchResponse> onCreateLoader(int id, Bundle args) {
			SearchCirclesLoader loader = new SearchCirclesLoader(getActivity());
			loader.setPage(page);
			loader.setQuery(searchText.getText().toString());
			loader.setCity("");
			return loader;
		}

		@Override
		public void onLoadFinished(Loader<CircleSearchResponse> loader, CircleSearchResponse data) {
			page = data.getNextPage();
			if (viewSearchCircles.getChildCount() > 0)
				viewSearchCircles.removeViewAt(viewSearchCircles.getChildCount() - 1);
			loadCirclesViews(data.getCircles(), viewSearchCircles, true);
		}

		@Override
		public void onLoaderReset(Loader<CircleSearchResponse> loader) {
		}

	}
}
