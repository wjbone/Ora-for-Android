package net.ora.mobile.android.feed;

import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.feed.WSPrayersFeed;
import net.ora.mobile.dao.FeedDBHelper;
import net.ora.mobile.dao.configuration.BaseConfiguration;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.feed.Inspiration;
import net.ora.mobile.dto.feed.response.PrayersFeedResponse;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.prayers.PrayerAndCircle;
import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.digitalgeko.mobile.android.objects.User;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.table.TableUtils;

/**
 * 
 * @author byron
 * 
 */
public class PrayersFeedLoader extends DbFeedAsyncTaskLoader {

	private int time = WSPrayersFeed.TIME_ALL_TIME_PRAYRS;
	private int page = 1;
	private int prayerId = 0;
	private boolean reload;

	public PrayersFeedLoader(Activity activity, FeedLoaderCallbacks<PrayersFeedResponse> callbacks, FeedDBHelper helper) {
		super(activity, callbacks, helper);
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getPrayerId() {
		return prayerId;
	}

	public void setPrayerId(int prayerId) {
		this.prayerId = prayerId;
	}

	public boolean getReload() {
		return reload;
	}

	public void setReload(boolean reload) {
		this.reload = reload;
	}

	@Override
	public PrayersFeedResponse loadInBackground() {

		Log.i("Loader", "init");

		if (page <= 0) {
			Log.i("Loader", "No more data");
			return PrayersFeedResponse.EMPTY_RESPONSE;
		} else if (page == 1) {
			if (!getReload()) {
				try {
					Dao<Circle, ?> circleDao = getHelper().getCircleDao();
					Dao<Prayer, ?> prayerDao = getHelper().getPrayerDao();
					Dao<PrayerAndCircle, Integer> prayerAndCirclesDao = getHelper().getPrayerAndCirclesDao();

					// Load prayers
					QueryBuilder<Prayer, ?> prayerQueryBuilder = prayerDao.queryBuilder();
					prayerQueryBuilder.orderBy("id", false);
					List<Prayer> prayers = prayerQueryBuilder.query();

					// Set circles
					for (Prayer prayer : prayers) {
						QueryBuilder<PrayerAndCircle, ?> prayerAndCircleQueryBuilder = prayerAndCirclesDao.queryBuilder();
						prayerAndCircleQueryBuilder.where().eq(Prayer.FOREIGN_FIELD_ID, prayer.getId());

						QueryBuilder<Circle, ?> circleQueryBuilder = circleDao.queryBuilder();
						circleQueryBuilder.join(prayerAndCircleQueryBuilder);
						circleQueryBuilder.orderBy(Circle.FIELD_NAME, true);

						List<Circle> circles = circleQueryBuilder.query();
						prayer.setCircles(circles);
					}

					// Load next page
					Dao<BaseConfiguration, Integer> configurationDao = getHelper().getConfigurationDao();
					QueryBuilder<BaseConfiguration, ?> builder = configurationDao.queryBuilder();
					builder.limit(1L);
					List<BaseConfiguration> configurations = builder.query();

					int nextPage = -1;
					if (configurations.size() == 1) {
						BaseConfiguration configuration;
						configuration = configurations.get(0);

						if (configuration.getNexPageFeed() > 1) {
							nextPage = configuration.getNexPageFeed();
						}
					}

					// Load inspiration
					Dao<Inspiration, ?> inspirationDao = getHelper().getInspirationDao();
					QueryBuilder<Inspiration, ?> inspirationBuilder = inspirationDao.queryBuilder();
					Inspiration inspiration = inspirationBuilder.queryForFirst();

					// Build response
					PrayersFeedResponse response = new PrayersFeedResponse();
					response.setPrayers(prayers);
					response.setNextPage(nextPage);
					response.setInspiration(inspiration);

					return response;
				} catch (SQLException e) {
					MasterService.setErrorMessage(getContext().getString(R.string.feedLoader_errorDb1));
				}
			}
		}

		//
		Context context = getContext();
		PrayersFeedResponse response = WSPrayersFeed.getPrayersFeed(context, time, page, prayerId);

		if (MasterService.isFailedConnection()) {
			showErrorMessage(MasterService.getErrorMessage());
			// abandon();
			return null;
		}

		try {

			Dao<User, ?> userDao = getHelper().getUserDao();
			Dao<Circle, ?> circleDao = getHelper().getCircleDao();
			Dao<Prayer, Integer> prayerDao = getHelper().getPrayerDao();
			Dao<PrayerAndCircle, Integer> prayerAndCirclesDao = getHelper().getPrayerAndCirclesDao();

			if (page == 1) {
				prayerAndCirclesDao.deleteBuilder().delete();
				prayerDao.deleteBuilder().delete();
			}

			for (Prayer prayer : response.getPrayers()) {
				// Save prayer
				prayerDao.createOrUpdate(prayer);

				// Save circles
				for (Circle circle : prayer.getCircles()) {
					circleDao.createIfNotExists(circle);

					PrayerAndCircle prayerAndCircle = new PrayerAndCircle();
					prayerAndCircle.setPrayer(prayer);
					prayerAndCircle.setCircle(circle);

					prayerAndCirclesDao.create(prayerAndCircle);
				}
				// Save user
				userDao.createIfNotExists(prayer.getUser());
			}

			// Save next page
			Dao<BaseConfiguration, Integer> configurationDao = getHelper().getConfigurationDao();
			QueryBuilder<BaseConfiguration, ?> builder = configurationDao.queryBuilder();
			builder.limit(1L);
			List<BaseConfiguration> configurations = builder.query();
			// // Search for configuration
			BaseConfiguration configuration;
			if (configurations.size() == 0) {
				configuration = new BaseConfiguration();
			} else {
				configuration = configurations.get(0);
			}
			// // Save
			configuration.setNextPageFeed(response.getNextPage());
			configurationDao.createOrUpdate(configuration);

			// Save inspiration (if any)
			if (response.getInspiration() != null) {
				Dao<Inspiration, ?> inspirationDao = getHelper().getInspirationDao();
				TableUtils.clearTable(getHelper().getConnectionSource(), Inspiration.class);
				inspirationDao.deleteBuilder().delete();
				inspirationDao.createOrUpdate(response.getInspiration());
				
				Log.i("Loader", "Saving inspiration.");
			}
		} catch (SQLException e) {
			MasterService.setErrorMessage(getContext().getString(R.string.feedLoader_errorDb2));
		}

		Log.i("Loader", "finish");

		return response;
	}

}
