package net.ora.mobile.android.webservices.friends;

import java.util.Vector;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

import android.content.Context;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;

public class WSCancelFriendRequest extends MasterService {
	
	private static final String URL = "cancel_request/";
	
	public static RequestFriendResponse cancelRequestFriend(Context context, int userId) {
		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("user_id", Integer.toString(userId)));

			// Make request
			RequestFriendResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, 
					request, new TypeReference<RequestFriendResponse>() {});

			return response;
		} catch (Exception e) {
			highlightError(context, e, R.string.wsViewCircles_error);
		}
		
		return null;
	}

}
