package net.ora.mobile.android.profile;

import net.ora.mobile.android.R;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSSuggestedUsers;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImageSearchFriends;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.FragmentImageData;
import com.digitalgeko.mobile.android.objects.profile.RequestFriendshipDialog;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class MySuggestedFriendsFragment extends FragmentImageData {
	
	private LinearLayout friendsList;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		
		getActivity().setTitle("Suggested Friends");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.list_friend_list, container, false);
		
		friendsList = (LinearLayout) view.findViewById(R.id.ly_list_friends_list);
		new LoadFriendsActionDialog(getActivity()).init();
		
		return view;
	}
	
	public class LoadFriendsActionDialog extends ActionDialog<Void> {
		
		public LoadFriendsActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			Log.i("consult", "frineds");
			WSSuggestedUsers.findSuggestions(getActivity());
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if(MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			}else{
				int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getActivity());
				
				LayoutInflater inflater = LayoutInflater.from(getActivity());
				
				for(final FriendUser temp : WSSuggestedUsers.getResponse().getFriendsList()){
					final View convertView = inflater.inflate(R.layout.item_friend_list, null);
					final TextView div = GeneralMethods.createLine(R.color.friends_div_line, getActivity());
					
					ImageView friendPicture = ((ImageView) convertView.findViewById(R.id.iv_item_friend_image));
					ImageView circlePicture = (ImageView) convertView.findViewById(R.id.iv_friends_Cirle);
					
					friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
					
					pictureImageViewList.add(friendPicture);
					circleImageViewList.add(circlePicture);
					
					((TextView) convertView.findViewById(R.id.tv_item_friend_name)).setText(temp.getName());
					
					final ImageButton button = ((ImageButton) convertView.findViewById(R.id.b_item_friend_button));
					if(temp.isFriend()){
						button.setImageResource(R.drawable.ic_check_green);
					}else if(temp.isRequested()){
						button.setImageResource(R.drawable.ic_check_gray_pending);
					}else{
						button.setImageResource(R.drawable.ic_add_request);
					}
					button.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							if((!temp.isFriend()) && (!temp.isRequested())){
								new RequestFriendshipDialog(getContext(), button, temp, null).init();
							}
						}
					});
					
					convertView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(getActivity(), ProfileFriendActivity.class);
							intent.putExtra("friend_id", temp.getId());
							getActivity().startActivity(intent);
						}
					});
					
					friendsList.addView(convertView);
					friendsList.addView(div);
					friendsList.invalidate();
				}
				
				AsyncDownloadImageSearchFriends async = new AsyncDownloadImageSearchFriends("MyFriendsListFragmets", context, MySuggestedFriendsFragment.this);
				async.setListPictures(pictureImageViewList);
				
				asyncTaskList.add(async);
				
				async.execute(WSSuggestedUsers.getResponse().getFriendsList());
			}
		}
	}

}
