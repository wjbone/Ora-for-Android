package net.ora.mobile.android;

import java.util.HashMap;
import java.util.Map;

import net.ora.mobile.android.profile.ProfileManager;
import android.app.Application;

import com.digitalgeko.mobile.android.database.UserOraTableManager;
import com.digitalgeko.mobile.android.objects.User;

public class OraApplication extends Application {
	
	public static final boolean IS_LITE = false;
	public static final boolean IS_DEV = false;
	
	public static boolean isTimeToPray = false;

	private User user;
	private ProfileManager profileManager = new ProfileManager();
	private Map<String, Object> params = new HashMap<String, Object>();

	@Override
	public void onCreate(){
		super.onCreate();
		setUser();
	}
	
	@Override
	public void onTerminate(){
		super.onTerminate();
		if(user != null){
			UserOraTableManager.saveUser(getApplicationContext(), user);
		}
	}
	
	public ProfileManager getProfileManager() {
		return profileManager;
	}

	public void setProfileManager(ProfileManager profileManager) {
		this.profileManager = profileManager;
	}

	public User getUser() {
		return user;
	}
	
	public void setUser(){
		user = UserOraTableManager.getUser(getApplicationContext());
	}

	public void setUser(User user) {
		UserOraTableManager.saveUser(getApplicationContext(), user);
		this.user = user;
	}
	
	public void persistUser(){
		UserOraTableManager.saveUser(getApplicationContext(), user);
	}
	
	public void clearData() {
		user = new User();
		profileManager = new ProfileManager();
		params = new HashMap<String, Object>();
	}

	public static boolean isTimeToPray() {
		return isTimeToPray;
	}

	public static void setTimeToPray(boolean isTimeToPray) {
		OraApplication.isTimeToPray = isTimeToPray;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}
	
	public void addParam(String key, Object value){
		params.put(key, value);
	}
	
	public Object getParam(String key){
		return params.get(key);
	}
	
	public void deleteParam(String key){
		params.remove(key);
	}
	
}
