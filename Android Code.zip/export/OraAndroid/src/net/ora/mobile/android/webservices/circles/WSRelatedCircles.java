package net.ora.mobile.android.webservices.circles;

import java.util.List;
import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.RelatedCirclesResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSRelatedCircles extends MasterService {

	private static final String URL = "related_circles/";
	
//	public static List<Circle> getRelatedCircles(Context context, 
//			String userId, boolean reload) {
//		if(reload) {
//			FeedDBHelper helper = OpenHelperManager.getHelper(context, FeedDBHelper.class);
//			try {
//				Dao<Circle, Integer> dao = helper.getCircleDao();
//				dao.crea
//			} catch (SQLException e) {
//				highlightError(context, e, R.string.wsBase_error);
//			}
//			
//		} else {
//			return getRelatedCirclesFromServer(context, userId);
//		}
//		return null;
//	}
	
	public static List<Circle> getRelatedCirclesFromServer(Context context, String userId) {
		
		try {
			// Validates
			validateRequired(context, userId, R.string.wsRelatedCircles_errorUserId);
			
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("user_id", userId));
		
			// Make request
			RelatedCirclesResponse response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL, request, new TypeReference< RelatedCirclesResponse >() {});
			 
			// Sort circles' list
			List<Circle> circles = null;
			if(!isFailedConnection()) {
				circles = response.getRelatedCircles();
				
				int i = 0;
				Circle currentCircle;
				Circle nextCircle;
				while(i + 1 < circles.size()) {
					currentCircle = circles.get(i);
					nextCircle = circles.get(i + 1);
					if(nextCircle.getName().compareToIgnoreCase(currentCircle.getName()) < 0) {
						// Swap
						circles.remove(i + 1);
						circles.add(i, nextCircle);
						
						if(i > 0) {
							i--;
						}
					} else {
						i++;
					}
				}
				
			}
			
			return circles;
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsRelatedCircles_error);
		}
		
		return null;
	}
	
	public static List<Circle> getRelatedCirclesFromServer(Context context, User user) {
		String userId = Integer.toString(user.getId());
		
		List<Circle> circles = getRelatedCirclesFromServer(context, userId);
		
		if(!isFailedConnection()) {
			for(Circle circle: circles) {
				if(circle.getUser() == null) {
					circle.setUser(user);
				}
			}
		}
		
		return circles;
	}
}
