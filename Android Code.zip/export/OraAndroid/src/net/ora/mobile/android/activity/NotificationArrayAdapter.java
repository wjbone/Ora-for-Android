package net.ora.mobile.android.activity;

import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.activity.WSCancelRequest;
import net.ora.mobile.android.webservices.activity.WSCircleInviteAccept;
import net.ora.mobile.android.webservices.activity.WSCircleInviteDecline;
import net.ora.mobile.android.webservices.activity.WSFriendshipAcceept;
import net.ora.mobile.core.OraConfiguration;
import net.ora.mobile.dto.activity.Notification;
import android.content.Context;
import android.text.Html;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImage;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGFragment;

public class NotificationArrayAdapter extends ArrayAdapter<Notification> {

	private static final String TAG = "NotificationArrayAdapter";

	private BaseImageData fragment;
	private int width;

	public NotificationArrayAdapter(Context context, BaseImageData fragment, List<Notification> notifications) {
		super(context, 0, notifications);

		// Instance data
		this.fragment = fragment;
		width = GeneralMethods.getProfileImageWidth(getContext());
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		final Notification notification = getItem(position);
		ViewHolder holder;

		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(getContext());
			convertView = inflater.inflate(R.layout.item_activity_prayer_interaction, null);

			holder = new ViewHolder();
			convertView.setTag(holder);

			// References to the views
			holder.friendPicture = ((ImageView) convertView.findViewById(R.id.iv_item_activity_image));
			holder.circlePicture = (ImageView) convertView.findViewById(R.id.iv_item_activity_Cirle);
			holder.tvMessage = (TextView) convertView.findViewById(R.id.tv_item_activity_name);
			holder.ibAcceptButton = (ImageButton) convertView.findViewById(R.id.ib_item_activity_accept);
			holder.ibDeclineButton = (ImageButton) convertView.findViewById(R.id.ib_item_activity_decline);

			// Set profile image size
			holder.friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		// Set texts and images
		String text = "";
		View.OnClickListener convertViewListener;
		View.OnClickListener acceptViewListener;
		View.OnClickListener declineViewListener;

		switch (notification.getType()) {
		// PRAYERS NOTIFICATIONS
		case Notification.TYPE_LIKE:
			text = getContext().getString(R.string.activity_Prayers_type_like, notification.getUser().getName());
			convertViewListener = new GoToPrayerManager(notification);
			acceptViewListener = null;
			declineViewListener = null;
			break;
		case Notification.TYPE_COMMENT:
			text = getContext().getString(R.string.activity_Prayers_type_comment, notification.getUser().getName());
			convertViewListener = new GoToPrayerManager(notification);
			acceptViewListener = null;
			declineViewListener = null;
			break;
		case Notification.TYPE_ANSWERED:
			text = getContext().getString(R.string.activity_Prayers_type_answered, notification.getUser().getName());
			convertViewListener = new GoToPrayerManager(notification);
			acceptViewListener = null;
			declineViewListener = null;
			break;
		// CIRCLES NOTIFICATIONS
		case Notification.TYPE_CIRCLE_INVITATION:
			text = notification.getCircle().getName();

			convertViewListener = null;
			acceptViewListener = new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					new AcceptCirclesRequestDialog(getContext(), notification).init();
				}
			};
			declineViewListener = new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					new RejectCirclesRequestDialog(getContext(), notification).init();
				}
			};
			break;

		case Notification.TYPE_ANNOUNCEMENT:
			text = getContext().getString(R.string.activity__circles__type_announcement, notification.getCircle().getName(),
					notification.getPrayer().getText());
			convertViewListener = null;
			acceptViewListener = null;
			declineViewListener = null;
			break;
		// FRIENDS NOTIFICATIONS
		case Notification.TYPE_FRIENDSHIP_REQUEST:
		default:
			text = notification.getUser().getName();

			convertViewListener = null;
			acceptViewListener = new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					new AcceptFriendRequestDialog(getContext(), notification).init();
				}
			};
			declineViewListener = new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					new RejectFriendRequestDialog(getContext(), notification).init();
				}
			};
			break;
		}

		// Set text and listeners
		holder.tvMessage.setText(Html.fromHtml(text));
		convertView.setOnClickListener(convertViewListener);
		holder.ibAcceptButton.setOnClickListener(acceptViewListener);
		if (acceptViewListener == null) {
			holder.ibAcceptButton.setVisibility(View.GONE);
		}
		holder.ibDeclineButton.setOnClickListener(declineViewListener);
		if (declineViewListener == null) {
			holder.ibDeclineButton.setVisibility(View.GONE);
		}

		// Load image task
		AsyncDownloadImage async = new AsyncDownloadImage(TAG, getContext(), fragment);
		fragment.getAsyncTaskList().add(async);
		String url = notification.getNotificationImageUrl();
		holder.friendPicture.setTag(url);
		async.execute(new Pair<String, ImageView>(url, holder.friendPicture));

		// Return view
		return convertView;
	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class ViewHolder {
		public ImageView friendPicture;
		public ImageView circlePicture;
		public TextView tvMessage;
		public ImageButton ibAcceptButton;
		public ImageButton ibDeclineButton;
	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class RejectFriendRequestDialog extends ActionDialog<Void> {

		private Notification notification;

		public RejectFriendRequestDialog(Context context, Notification notification) {
			super(context);
			this.notification = notification;
		}

		@Override
		public Void performAction() {
			WSCancelRequest.cancelRequest(context, Integer.toString(notification.getUser().getId()));
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				Toast.makeText(getContext(), MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
			} else {
				remove(notification);
				notifyDataSetChanged();
				Toast.makeText(getContext(), WSCancelRequest.getResponse().getMessage(), Toast.LENGTH_SHORT).show();
			}
		}

	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class AcceptFriendRequestDialog extends ActionDialog<Void> {

		private Notification notification;

		public AcceptFriendRequestDialog(Context context, Notification notification) {
			super(context);
			this.notification = notification;
		}

		@Override
		public Void performAction() {
			WSFriendshipAcceept.acceptInvitation(context, Integer.toString(notification.getUser().getId()));
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (WSFriendshipAcceept.isFailedConnection()) {
				Toast.makeText(getContext(), MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
			} else {
				remove(notification);
				notifyDataSetChanged();
				Toast.makeText(getContext(), WSFriendshipAcceept.getResponse().getMessage(), Toast.LENGTH_SHORT).show();
			}
		}

	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class RejectCirclesRequestDialog extends ActionDialog<Void> {

		private Notification notification;

		public RejectCirclesRequestDialog(Context context, Notification notification) {
			super(context);
			this.notification = notification;
		}

		@Override
		public Void performAction() {
			WSCircleInviteDecline.cancelInvite(context, Integer.toString(notification.getCircle().getId()));
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				Toast.makeText(getContext(), MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
			} else {
				remove(notification);
				notifyDataSetChanged();
				Toast.makeText(getContext(), WSCircleInviteDecline.getResponse().getMessage(), Toast.LENGTH_SHORT).show();
			}
		}

	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class AcceptCirclesRequestDialog extends ActionDialog<Void> {

		private Notification notification;

		public AcceptCirclesRequestDialog(Context context, Notification notification) {
			super(context);
			this.notification = notification;
		}

		@Override
		public Void performAction() {
			WSCircleInviteAccept.acceptInvitation(context, Integer.toString(notification.getCircle().getId()));
			return null;
		}

		@Override
		public void afterAction(Void result) {
			if (MasterService.isFailedConnection()) {
				Toast.makeText(getContext(), MasterService.getErrorMessage(), Toast.LENGTH_SHORT).show();
			} else {
				remove(notification);
				notifyDataSetChanged();
				Toast.makeText(getContext(), WSCircleInviteDecline.getResponse().getMessage(), Toast.LENGTH_SHORT).show();

				// Mark circle list for reload
				OraConfiguration configuration = new OraConfiguration(getContext());
				configuration.setFirstTimeLoadingCircles(true);
				configuration.close();
			}
		}

	}

	/**
	 * 
	 * @author bmorales
	 * 
	 */
	public class GoToPrayerManager implements OnClickListener {

		private Notification notification;

		public GoToPrayerManager(Notification notification) {
			this.notification = notification;
		}

		@Override
		public void onClick(View v) {
			((DGFragment) fragment).pushFragment(PrayerDetailFragment.getInstance(notification.getPrayer(), false));
		}
	}

}
