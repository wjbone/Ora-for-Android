package net.ora.mobile.android.help;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class TutorailPageAdapter extends FragmentStatePagerAdapter {

	public TutorailPageAdapter(FragmentManager fm) {
		super(fm);
	}

	private static final int PAGES_COUNT = 5;
	
	@Override
	public int getCount() {
		return PAGES_COUNT;
	}

	@Override
	public Fragment getItem(int position) {
		return TutorialPageFragment.getInstance(position);
	}
}
