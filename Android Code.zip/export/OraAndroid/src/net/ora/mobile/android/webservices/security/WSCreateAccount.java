package net.ora.mobile.android.webservices.security;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.util.ParseImageHttpEntityBuilder;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.ValidationException;
import net.ora.mobile.dto.security.response.AuthResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCreateAccount extends MasterService {

	private static String URL = "register_v2/";

	public static void createAccount(OraApplication application, Context context, String name, String email, String password, String passwordConfirmation,
			String picturePath) {

		try {
			// Validates
			validateRequired(context, email, R.string.wsCreateAccount_errorEmail);
			validateRequired(context, password, R.string.wsCreateAccount_errorPassword);
			validateConfirmation(context, password, passwordConfirmation, R.string.wsCreateAccount_errorPasswordConfirmation);
			validateRequired(context, picturePath, R.string.wsCreateAccount_errorImage);

			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("name", name));
			request.add(new BasicNameValuePair("email", email));
			request.add(new BasicNameValuePair("version", getVersion(context)));
			request.add(new BasicNameValuePair("password", password));
			request.add(new BasicNameValuePair("image", picturePath));

			// Make request
			AuthResponse response = makeRequest(context, CONNECTION_TYPE.POST, URL, request, new ParseImageHttpEntityBuilder(
					"image"), new TypeReference<AuthResponse>() {
			});

			if (response.isStatus()) {
				MasterService.setUsuario(response.getUser());
				application.setUser(response.getUser());
			}
		} catch (ValidationException e) {
			highlightError(e, e.getMessage());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}
}
