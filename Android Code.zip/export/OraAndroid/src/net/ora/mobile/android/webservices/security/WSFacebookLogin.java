package net.ora.mobile.android.webservices.security;

import java.util.Vector;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.security.response.FacebookAuthResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSFacebookLogin extends MasterService {

	private static String URL = "fb_auth/";
	private static FacebookAuthResponse response;

	public static FacebookAuthResponse getResponse() {
		return response;
	}

	public static void fb_auth(OraApplication application, Context context, String access_token) {
		try {
			// Build request
			Vector<NameValuePair> request = new Vector<NameValuePair>();
			request.add(new BasicNameValuePair("version", getVersion(context)));
			request.add(new BasicNameValuePair("access_token", access_token));

			// Make request
			response = makeRequest(context, CONNECTION_TYPE.POST, URL, request, new TypeReference<FacebookAuthResponse>() {
			});

			MasterService.setUsuario(response.getUser());
			application.setUser(response.getUser());
		} catch (Exception e) {
			highlightError(context, e, R.string.wsLogin_error);
		}
	}

}
