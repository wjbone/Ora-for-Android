package net.ora.mobile.android.webservices.city_state;

import java.io.IOException;
import java.util.Vector;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.dto.city_state.response.CityStateList;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

import com.digitalgeko.mobile.android.helpers.ConnectionHelper.CONNECTION_TYPE;
import com.fasterxml.jackson.core.type.TypeReference;

public class WSCityStateSearch extends MasterService {

	private final String URL = "city_state_search/";
	private CityStateList response;

	public CityStateList getResponse() {
		return response;
	}
	
	public void search(Context context, String text, String countryCode){
		try{
			Vector<NameValuePair> request = new Vector<NameValuePair>();			
			request.add(new BasicNameValuePair("q", text));
			request.add(new BasicNameValuePair("country_code", countryCode));
			
			response = makeRequest(context, CONNECTION_TYPE.GET, 
					URL , request, new TypeReference< CityStateList >() {});
		} catch (ClientProtocolException e) {
			highlightError(e, e.getMessage());
		} catch (IOException e) {
			highlightError(context, e, R.string.wsBase_error);
		}
	}
	
}
