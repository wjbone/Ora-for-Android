package net.ora.mobile.android.profile;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.OraButton;
import net.ora.mobile.android.util.ImageDownloader;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSRequestFriend;
import net.ora.mobile.android.webservices.profile.WSSug;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.RequestFriendUser;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.facebook.FB_Friend;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.facebook.FacebookException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Session;
import com.facebook.widget.WebDialog;

public class MyContactFiendsFacebookFriendsListAdapter extends BaseAdapter {

	private static final String TAG_LOG = "MyContactFiendsContactsListAdapter";

	private Activity context;
	private List<FB_Friend> facebookFriendsList;
	private int width;
	private String strButton;
	private ImageDownloader imageDownloader;

	public MyContactFiendsFacebookFriendsListAdapter(Activity context, List<FB_Friend> facebookFriendsList, Bitmap defaultBitmap,
			String strButton) {
		this.context = context;
		this.strButton = strButton;
		// Filter users list
		this.facebookFriendsList = facebookFriendsList;

		// Set up instance data
		width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(context);
		imageDownloader = new ImageDownloader(context, context.getResources(), defaultBitmap);
	}

	@Override
	public int getCount() {
		int count = 0;
		if (facebookFriendsList != null) {
			count = facebookFriendsList.size();
		}
		return count;
	}

	@Override
	public Object getItem(int position) {
		return facebookFriendsList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		FacebookFriendViewHolder holder;

		if (view == null) {
			LayoutInflater inflater = LayoutInflater.from(parent.getContext());

			view = inflater.inflate(R.layout.item_friend, null);

			holder = new FacebookFriendViewHolder();
			holder.friendPicture = ((ImageView) view.findViewById(R.id.iv_item_friend_image));
			holder.circlePicture = (ImageView) view.findViewById(R.id.iv_friends_Cirle);
			holder.tvName = ((TextView) view.findViewById(R.id.tv_item_friend_name));
			holder.button = ((OraButton) view.findViewById(R.id.b_item_friend_button));

			// Configure views
			holder.friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			holder.button.setText(strButton);

			// Save holder for later
			view.setTag(holder);

		} else {
			holder = (FacebookFriendViewHolder) view.getTag();

			if (holder.position == position) {
				return view;
			}
		}

		// Set data
		FB_Friend user = facebookFriendsList.get(position);
		holder.tvName.setText(user.getName());
		holder.button.setOnClickListener(new InviteFacebookFriendToJoinOraManager(position, user));
		// Profile picture
		if (!user.getPicture().getData().getIs_silhouette()) {
			String url = user.getPicture().getData().getUrl();
			Log.i(TAG_LOG, user.getPicture().getData().getUrl());
			imageDownloader.download(url, holder.friendPicture);
		}

		// Return
		return view;
	}

	/*
	 * 
	 */
	public static class FacebookFriendViewHolder {
		public int position;
		public ImageView friendPicture;
		public ImageView circlePicture;
		public TextView tvName;
		public OraButton button;

	}

	/*
	 * 
	 */
	public class InviteFacebookFriendToJoinOraManager implements OnClickListener {

		private int position;
		private FB_Friend facebookFriend;

		public InviteFacebookFriendToJoinOraManager(int position, FB_Friend user) {
			this.position = position;
			this.facebookFriend = user;
		}

		@Override
		public void onClick(View v) {
			Bundle params = new Bundle();
			params.putString("message", "I send you and invitation for use ORA application");
			params.putString("to", facebookFriend.getId());

			WebDialog requestsDialog = (new WebDialog.RequestsDialogBuilder(context, Session.getActiveSession(), params))
					.setOnCompleteListener(new InviteFacebookFriendToJoinOraOnResultManager()).build();
			requestsDialog.show();
		}

		/*
		 * 
		 */
		public class InviteFacebookFriendToJoinOraOnResultManager implements WebDialog.OnCompleteListener {

			@Override
			public void onComplete(Bundle values, FacebookException error) {
				if (error != null) {
					if (!(error instanceof FacebookOperationCanceledException)) {
						Toast.makeText(context, "Network Error", Toast.LENGTH_SHORT).show();
					}
				} else {
					String requestId = values.getString("request");
					if (requestId != null) {
						
						// Hide user
						facebookFriendsList.remove(position);
						notifyDataSetChanged();
						
						// Show success message
						Toast.makeText(context, "Request sent", Toast.LENGTH_SHORT).show();
					}
				}
			}

		}
	}
}
