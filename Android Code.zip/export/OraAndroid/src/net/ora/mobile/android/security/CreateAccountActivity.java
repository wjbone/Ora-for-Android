package net.ora.mobile.android.security;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.profile.RegisterContactFriendsActivity;
import net.ora.mobile.android.profile.SettingsFragment;
import net.ora.mobile.android.ui.activities.OraInsecureActivity;
import net.ora.mobile.android.util.Blur;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.security.WSCreateAccount;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadProfilePicture;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.utilities.ContentUtilities;

public class CreateAccountActivity extends OraInsecureActivity {

	private String picturePath;

	private LinearLayout marginImage;
	private ImageView backgroundImage;
	private ImageView pictureImage;
	private ImageView cameraImage;

	@Override
	protected void onCreate(Bundle savedInstance) {
		super.onCreate(savedInstance);

		// Create
		setTitle(R.string.createAccount_title);
		setContentView(R.layout.activity_create_account);

		/* Load images */
		int background_heigth = GeneralMethods.getProfileBackgroundWidth(this);
		int picture_width = (int) (background_heigth * 0.75);

		backgroundImage = (ImageView) findViewById(R.id.iv_setting_background);
		backgroundImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
				android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, background_heigth));

		pictureImage = (ImageView) findViewById(R.id.iv_setting_picture);
		pictureImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

		cameraImage = (ImageView) findViewById(R.id.iv_setting_camera);
		cameraImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(CreateAccountActivity.this);

				builder.setItems(new String[] { "Camera", "Gallery" }, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
						Intent intent = null;
						switch (which) {
						case 0:
							intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
							startActivityForResult(intent, SettingsFragment.TAKE_PICTURE);
							break;
						case 1:
							intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
							intent.setType("image/*");
							startActivityForResult(intent, SettingsFragment.SELECT_PICTURE);
							break;
						}
					}
				});

				builder.create().show();
			}
		});

		marginImage = (LinearLayout) findViewById(R.id.ly_setting_margin);
		marginImage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(picture_width, picture_width));

	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SettingsFragment.TAKE_PICTURE) {
			if (data != null) {
				if (data.hasExtra("data")) {
					Bitmap bitmap = data.getParcelableExtra("data");
					Uri selectedImage = Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "", ""));
					picturePath = ContentUtilities.getRealPathFromURI(this, selectedImage);
					setImagesViews(bitmap);
				}
			}
		} else if (requestCode == SettingsFragment.SELECT_PICTURE) {
			if (data != null) {
				Uri selectedImage = data.getData();
				picturePath = ContentUtilities.getRealPathFromURI(this, selectedImage);
				setImage(selectedImage);
			}
		}
	}

	private void setImage(Uri selectedImage) {
		if (selectedImage != null) {
			try {
				InputStream is = getContentResolver().openInputStream(selectedImage);
				BufferedInputStream bis = new BufferedInputStream(is);
				Bitmap bitmap = BitmapFactory.decodeStream(bis);
				setImagesViews(bitmap);
			} catch (FileNotFoundException e) {
			}
		}
	}

	private void setImagesViews(Bitmap bitmap) {
		Bitmap bmpFaded = Blur.fastblur(this, bitmap, DownloadProfilePicture.BLUR_RATIO);

		backgroundImage.setImageBitmap(bmpFaded);
		pictureImage.setImageBitmap(bitmap);

		pictureImage.setVisibility(View.VISIBLE);
		marginImage.setBackgroundResource(R.drawable.profile_image_margin);
	}

	public void onCreateAccountClick(View view) {
		new CreateAccountActionDialog(this).init();
	}

	public class CreateAccountActionDialog extends ActionDialog<Void> {

		public CreateAccountActionDialog(Activity context) {
			super(context);
		}

		@Override
		public Void performAction() {
			// Take data from inputs
			TextView viewPassword = (TextView) findViewById(R.id.createAccount_txtPassword);
			TextView viewPasswordConfirmation = (TextView) findViewById(R.id.createAccount_txtPasswordConfirmation);
			String name = ((TextView) findViewById(R.id.createAccount_txtName)).getText().toString();
			String email = ((TextView) findViewById(R.id.createAccount_txtEmail)).getText().toString();
			String password = viewPassword.getText().toString();
			String passwordConfirmation = viewPasswordConfirmation.getText().toString();

			// Call ws
			WSCreateAccount.createAccount((OraApplication) getApplication(), context, name, email, password,
					passwordConfirmation, picturePath);
			return null;
		}

		@Override
		public void afterAction(Void result) {
			// Clear password inputs
			TextView viewPassword = (TextView) findViewById(R.id.createAccount_txtPassword);
			TextView viewPasswordConfirmation = (TextView) findViewById(R.id.createAccount_txtPasswordConfirmation);
			viewPassword.setText("");
			viewPasswordConfirmation.setText("");

			// Process information
			if (MasterService.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			} else {
				startActivity(new Intent(context, RegisterContactFriendsActivity.class));
				close();
			}
		}
	}
}
