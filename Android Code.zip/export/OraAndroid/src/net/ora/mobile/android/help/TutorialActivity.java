package net.ora.mobile.android.help;

import net.ora.mobile.android.R;
import net.ora.mobile.android.ui.activities.OraSherlockFragmentActivity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;

public class TutorialActivity extends OraSherlockFragmentActivity {

	private ViewPager mPager;
	private TutorailPageAdapter mPagerAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// // Set layout
		// setContentView(R.layout.activity_tutorial);
		//
		// // Instantiate a ViewPager and a PagerAdapter.
		// mPager = (ViewPager) findViewById(R.id.pager);
		// mPagerAdapter = new TutorailPageAdapter(getSupportFragmentManager());
		// mPager.setAdapter(mPagerAdapter);

		setContentView(R.layout.fragment_tutorial_page);

		ImageView ivPage = (ImageView) findViewById(R.id.tutorial_page__iv_image);
		MyGestureDetector detector = new MyGestureDetector(ivPage);
		final GestureDetector gestureDetector = new GestureDetector(this, detector);
		ivPage.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return gestureDetector.onTouchEvent(event);
			}
		});
		ivPage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			}
		});

//		myDetector = new MyGestureDetector((ImageView) findViewById(R.id.ivGuide));
//		mGestureDetector = new GestureDetector(myDetector);
//		mGestureListener = new View.OnTouchListener() {
//			public boolean onTouch(View v, MotionEvent event) {
//				return mGestureDetector.onTouchEvent(event);
//			}
//		};
	}

	public void onQuitTutorialClick(View view) {
		finish();
	}
}
