package net.ora.mobile.android.profile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.ora.mobile.android.MainActivity;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSFacebookSynchronization;
import net.ora.mobile.android.webservices.profile.WSShareOnFacebook;
import net.ora.mobile.android.webservices.profile.WSSug;
import net.ora.mobile.android.webservices.profile.WSSuggestedFriends;
import net.ora.mobile.dto.profile.request.PhoneFacebookContacts;

import org.json.JSONException;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.DownloadFriendsImage;
import com.digitalgeko.mobile.android.objects.RequestFriendUser;
import com.digitalgeko.mobile.android.objects.facebook.FB_Friend;
import com.digitalgeko.mobile.android.objects.profile.PhoneContact;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGListFriendsActivity;
import com.facebook.FacebookException;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.Session.StatusCallback;
import com.facebook.SessionState;
import com.facebook.model.GraphUser;
import com.facebook.widget.InviteFriendsButton;
import com.facebook.widget.InviteFriendsButton.OnErrorListener;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RegisterContactFriendsActivity extends DGListFriendsActivity {

	private String TAG_LOG = "AddFriendsListFragment";

	private static final int GROUP_FRIENDS = Menu.NONE;
	private static final int ITEM_SEARCH = Menu.NONE;

	private ListView oraFriendsListView;
	private ListView facebookFriendListView;
	private LinearLayout facebookButtonLayout;
	private InviteFriendsButton facebookButton;

	private List<FB_Friend> facebookFriendsList;
	private DownloadFriendsImage asyncFacebookFriendsOne, asyncFacebookFriendsTwo, asyncFacebookFriendsThree,
			asyncFacebookFriendsFour, asyncFacebookFriendsFive;

	private List<List<FB_Friend>> friendsBitmapList;
	private List<List<ImageView>> friendsImageDoubleList;

	private Bitmap defaultBitmap;

	private TextView titleView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_friends);

		// ActionBar gets initiated
		ActionBar actionbar = getSupportActionBar();
		// Tell the ActionBar we want to use Tabs.
//		actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Set info
		actionbar.setCustomView(R.layout.custom_action_layout);
		View customView = actionbar.getCustomView();
		titleView = (TextView) customView.findViewById(R.id.action_custom_title);

		String name = ((OraApplication) getApplication()).getUser().getUsername();
		if ((name == null) || (name.trim().length() == 0)) {
			name = ((OraApplication) getApplication()).getUser().getName();
		}
		int index = name.indexOf(" ");
		titleView.setText(name.substring(0, ((index != -1 ? index : name.length()))) + "'s Friends");

		oraFriendsListView = (ListView) findViewById(R.id.ly_Friends_OraList);
		facebookFriendListView = (ListView) findViewById(R.id.ly_Friends_FBList);
		facebookButtonLayout = (LinearLayout) findViewById(R.id.ly_Friends_FBbtn);
		facebookButton = (InviteFriendsButton) findViewById(R.id.b_Friends_FBConnect);

		Boolean loginFacebook = false;
		if (WSShareOnFacebook.isFacebookLogin()) {
			Session openSession = Session.getActiveSession();
			Log.i("FB ReLogin", "Access Token: " + openSession.getAccessToken());
			facebookButtonLayout.setVisibility(View.GONE);
			loginFacebook = true;
			new AddTwoKindFriendDialog(RegisterContactFriendsActivity.this, openSession).init();
		} else {
			facebookButton.setApplicationId("257685094367122");
			facebookButton.setReadPermissions(Arrays.asList("email", "friends_hometown"));

			facebookButton.setOnErrorListener(new OnErrorListener() {
				@Override
				public void onError(FacebookException error) {
					Log.e(TAG_LOG, "Error " + error.getMessage());
					Toast.makeText(RegisterContactFriendsActivity.this, "Had problems with facebook, try again later.",
							Toast.LENGTH_SHORT).show();
				}
			});

			facebookButton.setSessionStatusCallback(new StatusCallback() {

				@Override
				public void call(Session session, SessionState state, Exception exception) {
					if (session.isOpened()) {
						facebookButtonLayout.setVisibility(View.GONE);

						Log.i("FBAutentication", "Access Token: " + session.getAccessToken());
						new AddFriendsListInitialDialog(RegisterContactFriendsActivity.this, session).init();
					}

					if (exception != null) {
						Log.e("Facebook Ex", exception.getMessage());
					}
				}

			});
		}

		asyncFacebookFriendsOne = new DownloadFriendsImage("One", this);
		asyncFacebookFriendsTwo = new DownloadFriendsImage("Two", this);
		asyncFacebookFriendsThree = new DownloadFriendsImage("Three", this);
		asyncFacebookFriendsFour = new DownloadFriendsImage("Four", this);
		asyncFacebookFriendsFive = new DownloadFriendsImage("Five", this);

		friendsImageDoubleList = new ArrayList<List<ImageView>>();
		friendsBitmapList = new ArrayList<List<FB_Friend>>();

		if (!loginFacebook) {
			new ConsultListContactDialog(this).init();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Vars
		MenuItem sub;

		// Find circle button
		sub = menu.add(GROUP_FRIENDS, ITEM_SEARCH, Menu.NONE, getString(R.string.friendsList_miSearch));
		sub.setIcon(R.drawable.ic_search);
		sub.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case ITEM_SEARCH: {
			Intent intent = new Intent(this, AddOraFriendsListActivity.class);
			startActivity(intent);
//			pushFragment(new AddOraFriendsListFragment());
			return true;
		}
		case android.R.id.home: {
			goToMain();
			return true;
		}
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			goToMain();
		}
		return false;
	}

	private void goToMain() {
		startActivity(new Intent(this, MainActivity.class));
		close();
	}

	@Override
	protected void onStart() {
		super.onStart();

		defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		asyncFacebookFriendsOne.cancel(true);
		asyncFacebookFriendsTwo.cancel(true);
		asyncFacebookFriendsThree.cancel(true);
		asyncFacebookFriendsFour.cancel(true);
		asyncFacebookFriendsFive.cancel(true);

		for (List<ImageView> tempList : friendsImageDoubleList) {
			for (ImageView temp : tempList) {
				unbindDrawables(temp);
			}
		}

		for (List<FB_Friend> tempList : friendsBitmapList) {
			for (FB_Friend temp : tempList) {
				temp.freeBitmapMemory();
			}
		}
		System.gc();
	}

	public Activity getActivity() {
		return this;
	}

	private void addOraFriends(List<RequestFriendUser> users) {
		// Vars
		String strButtonAdd = getString(R.string.friendsList_btnAdd);

		// Set new list data
		MyContactFiendsContactsListAdapter adapter = new MyContactFiendsContactsListAdapter(getActivity(), users, defaultBitmap,
				strButtonAdd);
		oraFriendsListView.setAdapter(adapter);
	}

	private void addFacebookFriends() {
		facebookButtonLayout.setVisibility(View.GONE);

		// New list data
		String strButtonInvite = getString(R.string.friendsList_btnInvite);
		MyContactFiendsFacebookFriendsListAdapter adapter = new MyContactFiendsFacebookFriendsListAdapter(this,
				facebookFriendsList, defaultBitmap, strButtonInvite);
		facebookFriendListView.setAdapter(adapter);
	}

	/*
	 * 
	 */
	public class AddFriendsListInitialDialog extends ActionDialog<List<RequestFriendUser>> {

		private Session session;

		public AddFriendsListInitialDialog(Activity context, Session session) {
			super(context);
			this.session = session;
		}

		@Override
		public List<RequestFriendUser> performAction() {
			WSFacebookSynchronization.synchronize(RegisterContactFriendsActivity.this, session.getAccessToken());
			if (!WSFacebookSynchronization.isFailedConnection()) {
				// Phone contacts
				PhoneFacebookContacts contactsRequest = new PhoneFacebookContacts();

				// Facebook friends
				Log.i(TAG_LOG, "Access Token: " + session.getAccessToken());
				Request request = Request.newMyFriendsRequest(session, new OnLoadFacebookFriendManager());
				Bundle params = new Bundle();
				params.putString("fields", "id, name, username, picture");
				request.setParameters(params);
				request.executeAndWait();

				// List of facebook friends id's
				String[] tempArray = new String[facebookFriendsList.size()];
				for (int i = 0; i < facebookFriendsList.size(); i++) {
					tempArray[i] = facebookFriendsList.get(i).getId();
				}
				contactsRequest.setFb_ids(tempArray);

				// Get Ora users
				List<RequestFriendUser> tempUsers = WSSuggestedFriends.getSuggestedFriend(getContext(), contactsRequest);

				if(!MasterService.isFailedConnection()) {
					// Filter Facebook users
					for (RequestFriendUser tempUser : tempUsers) {
						for (FB_Friend friend : facebookFriendsList) {
							if (tempUser.getFbId().equals(friend.getId())) {
								facebookFriendsList.remove(friend);
								break;
							}
						}
					}
					
					return tempUsers;
				}
			}

			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (WSFacebookSynchronization.isFailedConnection()) {
				GeneralMethods.crearDialogoOk(WSFacebookSynchronization.getErrorMessage(), context);
			} else {
				facebookButtonLayout.setVisibility(View.GONE);
				friendsImageDoubleList = new ArrayList<List<ImageView>>();

				addFacebookFriends();
				addOraFriends(result);
			}
		}

	}

	/*
	 * 
	 */
	public class AddTwoKindFriendDialog extends ActionDialog<List<RequestFriendUser>> {

		private Session session;

		public AddTwoKindFriendDialog(Activity context, Session session) {
			super(context);
			this.session = session;
		}

		@Override
		public List<RequestFriendUser> performAction() {
			// Contact list
			List<PhoneContact> contacts = MyContactFriendsFragments.getContactList(getContentResolver());

			// Facebook Friends
			Log.i(TAG_LOG, "Access Token: " + session.getAccessToken());
			Log.i(TAG_LOG, "Begin request from facebook friends.");
			Request request = Request.newMyFriendsRequest(session, new OnLoadFacebookFriendManager());
			Bundle params = new Bundle();
			params.putString("fields", "id, name, username, picture");
			request.setParameters(params);
			request.executeAndWait();

			// List of facebook friends ids
			String[] facebookFriendList = new String[facebookFriendsList.size()];
			for (int i = 0; i < facebookFriendsList.size(); i++) {
				facebookFriendList[i] = facebookFriendsList.get(i).getId();
			}

			// Request for Ora users
			PhoneFacebookContacts allContact = new PhoneFacebookContacts();
			allContact.setContacts(contacts);
			allContact.setFb_ids(facebookFriendList);

			// Get Ora users
			List<RequestFriendUser> tempUsers = WSSuggestedFriends.getSuggestedFriend(getContext(), allContact);

			if(!MasterService.isFailedConnection()) {
				// Filter Facebook users
				for (RequestFriendUser tempUser : tempUsers) {
					for (FB_Friend friend : facebookFriendsList) {
						if (tempUser.getFbId().equals(friend.getId())) {
							facebookFriendsList.remove(friend);
							break;
						}
					}
				}
				
				return tempUsers;
			}
			
			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (!WSSug.isFailedConnection()) {
				facebookButtonLayout.setVisibility(View.GONE);
				friendsImageDoubleList = new ArrayList<List<ImageView>>();

				Log.i(TAG_LOG, "Begin render views");
				addFacebookFriends();
				addOraFriends(result);
				Log.i(TAG_LOG, "End render views");
			}
		}

	}

	/*
	 * 
	 */
	private class ConsultListContactDialog extends ActionDialog<List<RequestFriendUser>> {

		public ConsultListContactDialog(Activity context) {
			super(context);
		}
		@Override
		public List<RequestFriendUser> performAction() {
			// Load contact list
			List<PhoneContact> contacts = MyContactFriendsFragments.getContactList(getContentResolver());

			PhoneFacebookContacts allContact = new PhoneFacebookContacts();
			allContact.setContacts(contacts);

			// Retrieve info from Ora
			// Get Ora users
			List<RequestFriendUser> tempUsers = WSSuggestedFriends.getSuggestedFriend(getContext(), allContact);

			if(!MasterService.isFailedConnection()) {
				// Filter Facebook users
				for (RequestFriendUser tempUser : tempUsers) {
					for (FB_Friend friend : facebookFriendsList) {
						if (tempUser.getFbId().equals(friend.getId())) {
							facebookFriendsList.remove(friend);
							break;
						}
					}
				}
				
				return tempUsers;
			}


			return null;
		}

		@Override
		public void afterAction(List<RequestFriendUser> result) {
			if (!WSSug.isFailedConnection()) {
				Log.i(TAG_LOG, "Begin render views");
				addOraFriends(result);
				Log.i(TAG_LOG, "End render views");
			}
		}
	}

	/*
	 * 
	 */
	private class OnLoadFacebookFriendManager implements Request.GraphUserListCallback {

		@Override
		public void onCompleted(List<GraphUser> users, Response response) {
			Log.i(TAG_LOG, "End request from facebook friends.");

			Log.d(TAG_LOG, "Begin parse Friends");
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			try {
				String strList = response.getGraphObject().getInnerJSONObject().getJSONArray("data").toString();
				Log.i(TAG_LOG, strList);
				List<FB_Friend> fbUsers = mapper.readValue(strList, new TypeReference<List<FB_Friend>>() {
				});
				facebookFriendsList = fbUsers;
			} catch (JSONException e) {
				Log.e(TAG_LOG + " - JSONException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (JsonParseException e) {
				Log.e(TAG_LOG + " - JsonParseException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (JsonMappingException e) {
				Log.e(TAG_LOG + " - JsonMappingException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			} catch (IOException e) {
				Log.e(TAG_LOG + " - IOException", e.getMessage());
				facebookFriendsList = new ArrayList<FB_Friend>();
			}
			Log.d(TAG_LOG, "End parse Friends");
		}

	}

}
