package com.digitalgeko.mobile.android.objects.profile;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSRequestFriend;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;
import android.content.Context;
import android.widget.ImageButton;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.CircleMember;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class RequestFriendshipDialog extends ActionDialog<RequestFriendResponse> {

	private ImageButton button;
	private FriendUser user;
	private CircleMember circle;
	
	public RequestFriendshipDialog(Context context, ImageButton button, FriendUser user, CircleMember circle){
		super(context);
		this.button = button;
		this.user = user;
		this.circle = circle;
	}
	
	@Override
	public RequestFriendResponse performAction() {
		if(user != null){
			return WSRequestFriend.requestFriend(context, user.getId());
		}else{
			return WSRequestFriend.requestFriend(context, circle.getId());
		}
	}

	@Override
	public void afterAction(RequestFriendResponse result) {
		if(MasterService.isFailedConnection()){
			GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
		}else{
			if(result.isStatus()){
				if(user != null){
					user.setFriend(result.isFriend());
					user.setRequested(result.isRequested());
				}else{
					circle.setFriend(result.isFriend());
					circle.setRequested(result.isRequested());
				}
				
				if(result.isFriend()){
					button.setImageResource(R.drawable.ic_check_green);
				}else if(result.isRequested()){
					button.setImageResource(R.drawable.ic_check_gray_pending);
				}
			}else{
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			}
		}
	}

}
