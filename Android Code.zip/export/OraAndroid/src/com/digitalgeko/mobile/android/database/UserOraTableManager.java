package com.digitalgeko.mobile.android.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.digitalgeko.mobile.android.objects.User;

public final class UserOraTableManager {

	public static User getUser(Context context){
		User result = null;
		
		DataBaseManager manager = new DataBaseManager(context);
		SQLiteDatabase db = manager.getWritableDatabase();
		
		Cursor cursor = db.query(DataBaseManager.USER_ORA_TABLE, new String[]{DataBaseManager.USER_ORA_FIELD_ABOUT,
				DataBaseManager.USER_ORA_FIELD_CITY, DataBaseManager.USER_ORA_FIELD_EMAIL, DataBaseManager.USER_ORA_FIELD_FACEBOOK_ID,
				DataBaseManager.USER_ORA_FIELD_MOBILE, DataBaseManager.USER_ORA_FIELD_NAME, DataBaseManager.USER_ORA_FIELD_PROFILE_PICTURE,
				DataBaseManager.USER_ORA_FIELD_TWITTER_ID, DataBaseManager.USER_ORA_FIELD_USERNAME, DataBaseManager.USER_ORA_FIELD_HAVE_HOUR,
				DataBaseManager.USER_ORA_FIELD_ORA_ID, DataBaseManager.USER_ORA_FIELD_HAVE_MINUTE, DataBaseManager.USER_ORA_FIELD_NOTIFICATIONS_COUNT,
				DataBaseManager.USER_ORA_FIELD_HAVE_NOTIFICATION, DataBaseManager.USER_ORA_FIELD_IGNORE_LITE, DataBaseManager.USER_ORA_FIELD_PREMIUM},
				DataBaseManager.USER_ORA_FIELD_ID + "=?", new String[] {DataBaseManager.USER_ORA_ID}, null, null, null);
		
		if(cursor.moveToFirst()){
			result = new User();
			result.setAbout(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_ABOUT)));
			result.setCity(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_CITY)));
			result.setEmail(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_EMAIL)));
			result.setFbId(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_FACEBOOK_ID)));
			result.setMobile(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_MOBILE)));
			result.setName(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_NAME)));
			result.setProfilePicture(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_PROFILE_PICTURE)));
			result.setTwId(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_TWITTER_ID)));
			result.setUsername(cursor.getString(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_USERNAME)));
			
			result.setHour(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_HAVE_HOUR)));
			result.setId(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_ORA_ID)));
			result.setMinute(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_HAVE_MINUTE)));
			result.setNotificationsCount(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_NOTIFICATIONS_COUNT)));
			
			result.setHaveNotification(getValBoolean(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_HAVE_NOTIFICATION))));
			result.setIgnoreLite(getValBoolean(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_IGNORE_LITE))));
			result.setPremium(getValBoolean(cursor.getInt(cursor.getColumnIndex(DataBaseManager.USER_ORA_FIELD_PREMIUM))));
		}
		
		db.close();
		manager.close();
		
		return result;
	}
	
	private static boolean getValBoolean(int val){
		return ((val == 0) ? false : true);
	}
	
	public static void saveUser(Context context, User user){
		DataBaseManager manager = new DataBaseManager(context);
		SQLiteDatabase db = manager.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put(DataBaseManager.USER_ORA_FIELD_ID, DataBaseManager.USER_ORA_ID);
		cv.put(DataBaseManager.USER_ORA_FIELD_ABOUT, user.getAbout());
		cv.put(DataBaseManager.USER_ORA_FIELD_CITY, user.getCity());
		cv.put(DataBaseManager.USER_ORA_FIELD_EMAIL, user.getEmail());
		cv.put(DataBaseManager.USER_ORA_FIELD_FACEBOOK_ID, user.getFbId());
		cv.put(DataBaseManager.USER_ORA_FIELD_MOBILE, user.getMobile());
		cv.put(DataBaseManager.USER_ORA_FIELD_NAME, user.getName());
		cv.put(DataBaseManager.USER_ORA_FIELD_PROFILE_PICTURE, user.getProfilePicture());
		cv.put(DataBaseManager.USER_ORA_FIELD_TWITTER_ID, user.getTwId());
		cv.put(DataBaseManager.USER_ORA_FIELD_USERNAME, user.getUsername());
		
		cv.put(DataBaseManager.USER_ORA_FIELD_HAVE_HOUR, user.getHour());
		cv.put(DataBaseManager.USER_ORA_FIELD_ORA_ID, user.getId());
		cv.put(DataBaseManager.USER_ORA_FIELD_HAVE_MINUTE, user.getMinute());
		cv.put(DataBaseManager.USER_ORA_FIELD_NOTIFICATIONS_COUNT, user.getNotificationsCount());
		
		cv.put(DataBaseManager.USER_ORA_FIELD_HAVE_NOTIFICATION, ((user.isHaveNotification() == true) ? 1 : 0));
		cv.put(DataBaseManager.USER_ORA_FIELD_IGNORE_LITE, ((user.isIgnoreLite() == true) ? 1 : 0));
		cv.put(DataBaseManager.USER_ORA_FIELD_PREMIUM, ((user.isPremium() == true) ? 1 : 0));
		
		System.out.println(user.isHaveNotification() + " - " + user.getHour() + " - " + user.getMinute());
		Cursor cursor = db.query(DataBaseManager.USER_ORA_TABLE, new String[]{DataBaseManager.USER_ORA_FIELD_ID},
				DataBaseManager.USER_ORA_FIELD_ID + "=?", new String[] {DataBaseManager.USER_ORA_ID}, null, null, null);
		
		if(cursor.moveToFirst()){
			System.out.println(db.update(DataBaseManager.USER_ORA_TABLE, cv, DataBaseManager.USER_ORA_FIELD_ID + "=?", new String[] {DataBaseManager.USER_ORA_ID}));
		}else{
			cv.put(DataBaseManager.USER_ORA_FIELD_ID, DataBaseManager.USER_ORA_ID);
			System.out.println(db.insert(DataBaseManager.USER_ORA_TABLE, null, cv));
		}
		
		db.close();
		manager.close();
	}
	
	public static void forgetUser(Context context){
		DataBaseManager manager = new DataBaseManager(context);
		SQLiteDatabase db = manager.getWritableDatabase();
		
		db.delete(DataBaseManager.USER_ORA_TABLE, DataBaseManager.USER_ORA_FIELD_ID + "=?", new String[] {DataBaseManager.USER_ORA_ID});
		
		db.close();
		manager.close();
	}
	
}
