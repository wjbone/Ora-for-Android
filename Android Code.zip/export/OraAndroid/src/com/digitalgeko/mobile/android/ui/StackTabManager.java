package com.digitalgeko.mobile.android.ui;


import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.actionbarsherlock.app.ActionBar.Tab;
import com.actionbarsherlock.app.ActionBar.TabListener;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;

public class StackTabManager implements TabListener {
	
	protected Context context;
	protected Stack<DGFragment> fragments;
	protected int idContainer;
	protected DGTabListener tabListener;
//	private boolean hasLostFocus;
//	private Activity context;
	
	public StackTabManager(Context context, DGFragment fragment, int idContiner) {
		// Instance data
		this.context = context;
		
		// Initiate list of fragments
		fragments = new Stack<DGFragment>();
		fragments.push(fragment);
		
		// Configure fragment
		fragment.setTabListener(this);
		
		// Main layout
		this.idContainer = idContiner;
	}

	@Override
	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		ft.replace(idContainer, fragments.peek());
		
		if(tabListener != null)
			tabListener.onTabSelected(fragments.peek());
	}

	@Override
	public void onTabUnselected(Tab tab, FragmentTransaction ft) {
		ft.remove(fragments.peek());
//		ft.detach(fragments.peek());
	}

	@Override
	public void onTabReselected(Tab tab, FragmentTransaction ft) {
//		Toast.makeText(fragments.peek().getActivity(), "Reselect", Toast.LENGTH_LONG).show();
	}
	
	public void pushFragment(DGFragment fragment) {
		// Push fragment
		fragments.push(fragment);
		
		// Configure fragment
		fragment.setTabListener(this);
	}
	
	public DGFragment popFragment(FragmentTransaction ft) {
		ft.remove(fragments.peek());
		DGFragment fragment = fragments.pop();
		ft.replace(idContainer, fragments.peek());
		return fragment;
	}
	
	public DGFragment peekFragment() {
		return fragments.peek();
	}
	
	public void popAllFragments(DGFragment fragment) {
		fragments.clear();
		fragments.add(fragment);
	}
	
	public boolean isLastFragment() {
		return fragments.size() <= 1;
	}

	public DGTabListener getTabListener() {
		return tabListener;
	}

	public void setTabListener(DGTabListener tabListener) {
		this.tabListener = tabListener;
	}

	public Context getContext() {
		return context;
	}

	public interface DGTabListener {
		public void onTabSelected(DGFragment fragment);
	}
	
	
	
}
