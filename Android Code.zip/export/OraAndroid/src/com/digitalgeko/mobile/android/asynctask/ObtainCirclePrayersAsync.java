package com.digitalgeko.mobile.android.asynctask;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.PrayerDetailActivity;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.friends.ViewFriendCircleActivity;
import net.ora.mobile.android.friends.fragment.CirclesPrayersFragments.GoPrayerCirclesManager;
import net.ora.mobile.android.friends.fragment.CirclesPrayersFragments.GoPrayerDetailManager;
import net.ora.mobile.android.friends.fragment.CirclesPrayersFragments.GoPrayerPraysManager;
import net.ora.mobile.android.friends.fragment.CirclesPrayersFragments.GoPrayerToFriendProfileManager;
import net.ora.mobile.android.webservices.circles.WSCirclePrayers;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.circles.response.CirclePrayersResponse;
import net.ora.mobile.dto.prayers.Prayer;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;
import com.digitalgeko.mobile.android.objects.profile.PrayerView;

public class ObtainCirclePrayersAsync extends AsyncTask<Void, Prayer, Void> {
	
	private Activity context;
	private ViewGroup list;
	private BaseImageData activity;
	private Circle circle;
	private int page;
	
	private List<ImageView> pictureView;
	private List<String> pictureString;
	
	public  ObtainCirclePrayersAsync(Activity context, ViewGroup list, BaseImageData activity, Circle circle, int page){
		super();
		this.context = context;
		this.list = list;
		this.activity = activity;
		this.circle = circle;
		this.page = page;
		
		pictureView = new ArrayList<ImageView>();
		pictureString = new ArrayList<String>();
	}

	@Override
	protected Void doInBackground(Void... params) {
		final CirclePrayersResponse response = WSCirclePrayers.getCirclePrayers(context, circle.getId(), WSCirclePrayers.PRAYER_ID_ALL_PRAYERS, page);
		if(response != null){
			context.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					list.removeAllViews();
					
					for(Prayer prayer : response.getPrayers()){
						if(!isCancelled()){
							onProgressUpdate(prayer);
						}else{
							break;
						}
					}
					
					if(!isCancelled()){
						onProgressUpdate(new Prayer[0]);
					}else{
						return;
					}
				}
			});
			
			if(!isCancelled()){
				// Start loading pictures
				DownloadAnyImage async = new DownloadAnyImage("ViewFriendCircleActivity", context);
				activity.getAsyncTaskList().add(async);
				async.setListPictures(pictureView);
				
				String[] tempPictures = new String[pictureString.size()];
				for(int i = 0; i < pictureString.size(); i++){
					tempPictures[i] = pictureString.get(i);
				}
				
				async.execute(tempPictures);
			}else{
				return null;
			}
		}
		return null;
	}
	
	@Override
	protected void onProgressUpdate(Prayer... values){
		super.onProgressUpdate(values);
		
		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods
				.getProfileImageWidth(context);
		LayoutInflater inflater = LayoutInflater.from(context);

		if(values.length > 0){
			final Prayer prayer = values[0];
			
			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(
					R.layout.item_feed_prayer, null);
			OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);
			
			// Set info
			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer))
					.setText(prayer.getText());
			// Prayer User View
			TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
			prayerUserTextView.setText(prayer.getUser().getName());
			prayerUserTextView.setOnClickListener(goToProfileListener);

			// Go to user profile
			ImageView friendPicture = (ImageView) viewPrayer
					.findViewById(R.id.iv_profile_image_prayer);
			friendPicture.setOnClickListener(goToProfileListener);
			
			// Set circle
			ImageView circlePicture = (ImageView) viewPrayer
					.findViewById(R.id.iv_profile_circle_prayer);

			friendPicture
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
							width, width));
			circlePicture
					.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
							width, width));

			activity.getPictureImageViewList().add(friendPicture);
			activity.getCircleImageViewList().add(circlePicture);
			
			// Save user/image view info
//			pictures.add(friendPicture);

			// Circles
			int circlesCount = prayer.getCircles().size();
			String strCircles = "";
			if (circlesCount == 0) {
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
			} else {
				// Set listener
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(
						new GoPrayerCirclesManager(prayer));
				
				for(Circle circle : prayer.getCircles())
					strCircles += circle.getName() + ", ";
				strCircles = strCircles.substring(0, strCircles.length() - 2);
				// Set circles string
				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer))
						.setText(strCircles);
			}

			// Set prayer likes count
			TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
			likesCount.setText(Integer.toString(prayer.getLikesCount()));

			// Set prayer comments count
			TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
			commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
			// Set prayer time
			TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
			timeCount.setText(GeneralMethods.fromDate(
							GeneralMethods.parseStringToDate(prayer.getDateCreated())));
			
			// Set listeners
			TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
			View btnPray = viewPrayer
					.findViewById(R.id.feedPrayer_btnPray);
			descriptionView.setOnClickListener(
					new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray, false));
			if (prayer.isLikeAvailable()) {
				ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
				btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer,
						containerView));
			} else {
				btnPray.setVisibility(View.GONE);
			}
			viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments).setOnClickListener(
					new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray, true));
			if(prayer.getUser().equals( ((OraApplication) context.getApplication()).getUser())) {
				// Can see prays list only in is the owner of the pray
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(
						new GoPrayerPraysManager(prayer));
			}
			
			
//			ViewGroup convertView = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);
//			
//			View imgGrabber = convertView.findViewById(R.id.feedPrayer_imGrabber);
//			final View grabber = imgGrabber;
//			
//			// Set info
//			((TextView) convertView.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
//			((TextView) convertView.findViewById(R.id.tv_profile_circles_prayer)).setText(
//					String.format(context.getString(R.string.prayer_item_frends), prayer.getCircles().size()));
//			
//			((TextView) convertView.findViewById(R.id.tv_profile_prayers_prayer)).setText(Integer.toString(prayer.getLikesCount()));
//			final TextView prayersCount = ((TextView) convertView.findViewById(R.id.tv_profile_prayers_prayer));
//			
//			((TextView) convertView.findViewById(R.id.tv_profile_comments_prayer)).setText(Integer.toString(prayer.getCommentsCount()));
//			final TextView commentsCount = ((TextView) convertView.findViewById(R.id.tv_profile_comments_prayer));
//			
//			((TextView) convertView.findViewById(R.id.tv_pray_time)).setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));
//			final TextView timeCount = ((TextView) convertView.findViewById(R.id.tv_pray_time));
//			
//			((TextView) convertView.findViewById(R.id.tv_profile_name_prayer)).setText(prayer.getUser().getRealName());
//			
//			// Set listeners
//			convertView.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					PrayerView prayerView = new PrayerView(prayer, prayersCount, commentsCount, timeCount, grabber);
//					
//					((OraApplication) context.getApplication()).addParam("prayer_view", prayerView);
//					((OraApplication) context.getApplication()).addParam("prayer_friends", prayer);
//					
//					context.startActivity(new Intent(context, PrayerDetailActivity.class));
//				}
//			});
//			
//			if (prayer.isLikeAvailable()) {
//				convertView.setOnTouchListener(new SwipeToPrayDetector(prayer, convertView));
//			} else {
//				imgGrabber.setVisibility(View.GONE);
//			}
			
			ImageView picture = ((ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer));
			pictureView.add(picture);
			pictureString.add(prayer.getUser().getProfilePicture());
			
			list.addView(viewPrayer);
		}else{
			View buttonView = inflater.inflate(R.layout.button_layout, null);
			
			Button button = (Button) buttonView.findViewById(R.id.b_button_layout);
			button.setText("See all prayers");
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					activity.goToAllPrayers();
				}
			});
			
			list.addView(buttonView);
		}
		
		list.invalidate();
	}

	
	
	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private TextView prayersCount, commentsCount, timeCount;	
		private View grabber;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, TextView prayersCount, TextView commentsCount, TextView timeCount, View grabber, boolean showOnlyComments) {
			this.prayer = prayer;
			this.prayersCount = prayersCount;
			this.commentsCount = commentsCount;
			this.timeCount = timeCount;
			this.grabber = grabber;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			PrayerView prayerView = new PrayerView(prayer, prayersCount, commentsCount, timeCount, grabber);
			
			((OraApplication) context.getApplication()).addParam("prayer_view", prayerView);
			((OraApplication) context.getApplication()).addParam("prayer_friends", prayer);
			
			context.startActivity(new Intent(context, PrayerDetailActivity.class));
		}
	}
	
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			context.startActivity(new Intent(context, ProfileFriendActivity.class)
			.putExtra("friend_id", prayer.getUser().getId()));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerPraysManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			// TODO ORA
//			pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
		}
	}
	
	/**
	 * 
	 * @author byron
	 *
	 */
	public class GoPrayerCirclesManager implements OnClickListener {
		
		private Prayer prayer;
		
		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}
		
		@Override
		public void onClick(View v) {
			if(prayer.getCircles().size() == 1) {
				Circle circle = prayer.getCircles().get(0);
				Intent intent = new Intent(context, ViewFriendCircleActivity.class);
				intent.putExtra("about", circle.getAbout());
				intent.putExtra("approvesMembers", circle.isApprovesMembers());
				intent.putExtra("city", circle.getCity());
				intent.putExtra("id", circle.getId());
				intent.putExtra("isEnterprise", circle.isCommunity());
				intent.putExtra("isLite", circle.isLite());
				intent.putExtra("isMember", circle.isMember());
				intent.putExtra("isOwner", circle.isOwner());
				intent.putExtra("isPrivate", circle.isPrivate());
				intent.putExtra("isRequested", circle.isRequested());
				intent.putExtra("name", circle.getName());
				intent.putExtra("picture", circle.getPicture());
				
				context.startActivity(intent);
			} else {
				// TODO ORA 
//				pushFragment(PrayerCirclesFragment.getInstance(prayer));
			}
		}
	}
}
