package com.digitalgeko.mobile.android.helpers.profile;

import java.util.List;

import android.util.Log;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

public class ProfileGestureDetector extends SimpleOnGestureListener {

	private static final int SWIPE_MIN_DISTANCE = 20;
	private static final int SWIPE_MAX_OFF_PATH = 600;
	private static final int SWIPE_THRESHOLD_VELOCITY = 30;
	
	private LinearLayout layoutView;
	private List<View> viewList;
	private int actualView;
	
	public ProfileGestureDetector(LinearLayout layoutView, List<View> viewList){
		this.layoutView = layoutView;
		this.viewList = viewList;
		actualView = 0;
		layoutView.addView(viewList.get(actualView));
	}
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY){
		try {
			if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                return false;
            if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
            	if(actualView == 0){
            		actualView = 1;
                	layoutView.removeAllViews();
                	layoutView.addView(viewList.get(actualView));
            	}
            	//actualView = (actualView + 1) % viewList.size();
            } else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
                    && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
            	/*actualView = (actualView - 1) % viewList.size();
                if (actualView < 0) {
                	actualView = 0;
                }*/
            	if(actualView == 1){
            		actualView = 0;
                    layoutView.removeAllViews();
                	layoutView.addView(viewList.get(actualView));
            	}
            }
		} catch (Exception e) {
            Log.e("SwypeImagesActivity", "error on gesture detector");
        }
        return false;
	}
	
}
