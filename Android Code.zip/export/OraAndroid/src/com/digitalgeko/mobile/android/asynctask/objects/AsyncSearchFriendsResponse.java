package com.digitalgeko.mobile.android.asynctask.objects;

import java.util.List;

import android.graphics.Bitmap;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.objects.FriendUser;

public class AsyncSearchFriendsResponse {

	private FriendUser[] usersList;
	
	private List<ImageView> viewPictureList;
	
	private List<ImageView> viewCircleList;
	
	private List<Bitmap> imagePictureList;
	
	private Integer nextPage;

	public FriendUser[] getUsersList() {
		return usersList;
	}

	public void setUsersList(FriendUser[] usersList) {
		this.usersList = usersList;
	}

	public List<ImageView> getViewPictureList() {
		return viewPictureList;
	}

	public void setViewPictureList(List<ImageView> viewPictureList) {
		this.viewPictureList = viewPictureList;
	}

	public List<Bitmap> getImagePictureList() {
		return imagePictureList;
	}

	public void setImagePictureList(List<Bitmap> imagePictureList) {
		this.imagePictureList = imagePictureList;
	}

	public List<ImageView> getViewCircleList() {
		return viewCircleList;
	}

	public void setViewCircleList(List<ImageView> viewCircleList) {
		this.viewCircleList = viewCircleList;
	}

	public int getNextPage() {
		return ((nextPage == null) ? -1 : nextPage);
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	
}
