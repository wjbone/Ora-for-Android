package com.digitalgeko.mobile.android.objects.friends;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.friends.WSUnblockUser;
import net.ora.mobile.dto.ServiceResponse;
import android.app.Activity;

import com.actionbarsherlock.view.Menu;
import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class UnblockUserDialog extends ActionDialog<ServiceResponse> {

	private Menu menu;
	private FriendProfileUser friend;
	
	public UnblockUserDialog(Activity context, Menu menu, FriendProfileUser friend) {
		super(context);
		this.menu = menu;
		this.friend = friend;
	}

	@Override
	public ServiceResponse performAction() {
		return WSUnblockUser.unblockUser(context, friend.getId());
	}

	@Override
	public void afterAction(ServiceResponse result) {
		if(MasterService.isFailedConnection()){
			GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
		}else{
			if(result.isStatus()){
				friend.setBlocked(false);
				menu.getItem(0).getSubMenu().getItem(0).setTitle(context.getString(R.string.profile_friend_block));
			}
			GeneralMethods.crearDialogoOk(result.getMessage(), context);
		}
	}

}
