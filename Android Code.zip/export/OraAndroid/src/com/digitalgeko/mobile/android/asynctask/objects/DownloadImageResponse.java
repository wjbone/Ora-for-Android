package com.digitalgeko.mobile.android.asynctask.objects;

import android.graphics.Bitmap;

public class DownloadImageResponse {

	private Bitmap bitmap;
	
	private String file_name;

	public DownloadImageResponse() {
		bitmap = null;
		file_name = "";
	}

	public DownloadImageResponse(Bitmap bitmap, String file_name) {
		this.bitmap = bitmap;
		this.file_name = file_name;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

}
