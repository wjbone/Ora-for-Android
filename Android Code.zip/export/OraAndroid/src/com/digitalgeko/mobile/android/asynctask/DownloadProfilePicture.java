package com.digitalgeko.mobile.android.asynctask;

import java.util.List;

import net.ora.mobile.android.util.Blur;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.objects.DownloadImageResponse;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

@SuppressWarnings("unchecked")
public class DownloadProfilePicture extends AsyncTask<String, Pair<Bitmap, ImageView>, Void> {
	
	public static final int BLUR_RATIO = 5;

	private List<ImageView> listPictures;
	private List<ImageView> listPicturesFaded;
	private Activity context;
	private BaseImageData data;
	private String name;

	public DownloadProfilePicture(Activity context, BaseImageData data, List<ImageView> listPictures, 
			List<ImageView> listPicturesFaded, String name) {
		this.context = context;
		this.data = data;
		this.listPictures = listPictures;
		this.listPicturesFaded = listPicturesFaded;
		this.name = name;
	}

	@Override
	protected Void doInBackground(String... params) {
		Log.w("DownloadSamePicture", "Start: *" + name + "*");

		DownloadImageResponse response = new DownloadImageResponse();

//		if (data.isDownloadFlag()) {
			Log.w("DownloadSamePicture", "Save Image");
			response = ImageManager.downloadImage(context, params[0]);
//		} else {
//			Log.w("DownloadSamePicture", "Virtual Memory");
//			Bitmap temp = GeneralMethods.downloadImage(params[0]);
//			response = new DownloadImageResponse(temp, params[0]);
//		}

		Log.w("DownloadSamePicture", "done");

		if (response.getBitmap() != null) {
			// Normal 
			for (ImageView imageView : listPictures) {
				if (isCancelled()) {
					break;
				}
				
				sendProgress(imageView, response.getFile_name(), response.getBitmap());
			}
			
			// Blur
			Bitmap bmpBlur = Blur.fastblur(context, response.getBitmap(), BLUR_RATIO);
			for (ImageView imageView : listPicturesFaded) {
				if (isCancelled()) {
					break;
				}
				
				sendProgress(imageView, response.getFile_name(), bmpBlur);
			}
			
		}

		Log.w("DownloadSamePicture", "End: *" + name + "*");

		return null;
	}
	
	private void sendProgress(ImageView imageView, String fileName, Bitmap bitmap) {
		Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
		tempPair[0] = new Pair<Bitmap, ImageView>(bitmap, imageView);
		publishProgress(tempPair);

		data.getPictureImageViewList().add(imageView);
		data.getPictureNames().add(fileName);
	}

	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for (Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;

			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}

}
