package com.digitalgeko.mobile.android.ui;

public class UIConfiguration {

	private static boolean SHOULD_MAKE_ACTION = true;
	
	public static void setShouldMakeNextAction(boolean shouldMakeNextAction) {
		SHOULD_MAKE_ACTION = shouldMakeNextAction;
	}
	
	public static boolean shouldMakeNextAction() {
		return SHOULD_MAKE_ACTION;
	}
}
