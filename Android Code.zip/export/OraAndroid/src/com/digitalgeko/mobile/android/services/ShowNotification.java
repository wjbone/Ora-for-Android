package com.digitalgeko.mobile.android.services;

import net.ora.mobile.android.InitialActivity;
import net.ora.mobile.android.R;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

@SuppressWarnings("deprecation")
public class ShowNotification extends BroadcastReceiver {

	public static final int APP_ID_NOTIFICATION = 0;
	
	@Override
	public void onReceive(Context packageContext, Intent arg1) {
		NotificationManager notManager = (NotificationManager) packageContext.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notif = new Notification(R.drawable.ic_launcher, "ORA The new way to pray", System.currentTimeMillis());
		
		Intent notIntent = new Intent(packageContext.getApplicationContext(), InitialActivity.class);
		notIntent.putExtra("notification", true);
		
		PendingIntent contIntent = PendingIntent.getActivity(packageContext.getApplicationContext(), 0, notIntent, 0);
		notif.setLatestEventInfo(packageContext.getApplicationContext(), "ORA The new way to pray", "Remember, is time to pray", contIntent);
		
		notif.flags |= Notification.FLAG_AUTO_CANCEL;
		
		notif.defaults |= Notification.DEFAULT_ALL;
		
		try {
			notif.ledARGB = 0xff00ff00;
			notif.ledOnMS = 300;
			notif.ledOffMS = 1000;
			notif.flags |= Notification.FLAG_SHOW_LIGHTS;
        } catch(Exception ex) {
            //Nothing
        }
		
		notManager.notify(123, notif);
	}
	
}
