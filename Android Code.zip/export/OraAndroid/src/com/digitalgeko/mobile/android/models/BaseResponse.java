package com.digitalgeko.mobile.android.models;

public class BaseResponse {

	protected String token;
	protected String msg;
	protected Boolean successfull;

	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getErrorMessage() {
		return msg;
	}
	public void setErrorMessage(String userMessage) {
		this.msg = userMessage;
	}
	public Boolean getSuccessfull() {
		return successfull;
	}
	public void setSuccessfull(Boolean successfull) {
		this.successfull = successfull;
	}
	
}
