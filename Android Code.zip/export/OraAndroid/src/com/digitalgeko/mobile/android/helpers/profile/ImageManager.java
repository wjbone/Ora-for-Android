package com.digitalgeko.mobile.android.helpers.profile;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import magick.ColorspaceType;
import magick.ImageInfo;
import magick.MagickException;
import magick.MagickImage;
import net.ora.mobile.android.util.ImageDownloader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.net.http.AndroidHttpClient;
import android.util.Log;

import com.digitalgeko.mobile.android.asynctask.objects.DownloadImageResponse;

public class ImageManager {

	private static final String TAG_LOG = "ImageManager";

	public static void deleteImage(Context context, String file_name) {
		File baseDirectory = context.getFilesDir();
		for (File file : baseDirectory.listFiles()) {
			if (file.getName().equals(file_name)) {
				file.delete();
			}
		}
	}

	public static Bitmap getImage(Context context, String file_name) {
		Bitmap bmp = null;

		File baseDirectory = context.getFilesDir();
		for (File file : baseDirectory.listFiles()) {
			if (file.getName().equals(file_name)) {
				BitmapFactory.Options options = new BitmapFactory.Options();
				bmp = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
				Log.d("Load image", "Load from storage");

				break;
			}
		}

		return bmp;
	}

	public static DownloadImageResponse downloadImage(Context context, String url) {
		DownloadImageResponse response = new DownloadImageResponse();

		File baseDirectory = context.getCacheDir();
		boolean shouldDownloadIt = true;

		String file_name = Long.toString(System.currentTimeMillis());
		Bitmap bmp = null;

		try {
			for (File file : baseDirectory.listFiles()) {
				if (file.getName().equals(file_name)) {
					// Open file
					BitmapFactory.Options options = new BitmapFactory.Options();
					bmp = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
					Log.d("Load image", "Load from storage");

					// Don't download it
					shouldDownloadIt = false;
					// Stop searching
					break;
				}
			}

			if (shouldDownloadIt) {
				Log.d("Load image", "Load from server");
				URL imagenURL = new URL(url);
				HttpURLConnection conn = (HttpURLConnection) imagenURL.openConnection();
				conn.connect();
				BufferedInputStream input = new BufferedInputStream(conn.getInputStream());

				String tempImagePath = context.getCacheDir() + "/temp.jpg";
				try {
					final File file = new File(tempImagePath);
					final OutputStream output = new FileOutputStream(file);
					try {
						try {
							final byte[] buffer = new byte[1024];
							int read;

							while ((read = input.read(buffer)) != -1)
								output.write(buffer, 0, read);

							output.flush();
						} finally {
							output.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} finally {
					input.close();
				}

				// Load image into bmp
				BitmapFactory.Options options = new BitmapFactory.Options();
				options.inSampleSize = 2;
				bmp = BitmapFactory.decodeFile(new File(tempImagePath).getAbsolutePath(), options);

				// bmp = BitmapFactory.decodeStream(new
				// BufferedInputStream(conn.getInputStream()));

				// InputStream in = new java.net.URL(fullUrl).openStream();
				// bmp = BitmapFactory.decodeStream(new PatchInputStream(in));

				String TAG = "Load image";
				Log.d("Load image", "End downloaning");
				if (bmp == null) {
					Log.e("Load image", "Error downloaning");

					ImageInfo info = new ImageInfo(tempImagePath);
					MagickImage imageCMYK = new MagickImage(info);

					Log.d(TAG, "ColorSpace BEFORE => " + imageCMYK.getColorspace());
					boolean status = imageCMYK.transformRgbImage(ColorspaceType.CMYKColorspace);
					Log.d(TAG, "ColorSpace AFTER => " + imageCMYK.getColorspace() + ", success = " + status);

					imageCMYK.setFileName(baseDirectory + "/" + file_name);
					imageCMYK.writeImage(info);
					bmp = BitmapFactory.decodeFile(baseDirectory + "/" + file_name);
					if (bmp == null) {
						// if decoding fails, create empty image
						bmp = Bitmap.createBitmap(imageCMYK.getWidth(), imageCMYK.getHeight(), Config.ARGB_8888);
					}

				} else {
					// Cash it
					FileOutputStream out = new FileOutputStream(baseDirectory + "/" + file_name);
					bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
					out.flush();
					out.close();
					Log.d("Load image", "End saving image");
				}

				// Prevent gallery to use this images
				File nomedia = new File(baseDirectory + "/" + ".nomedia");
				if (!nomedia.exists()) {
					nomedia.createNewFile();
					Log.d("Load image", "End saving .nomedia");
				}
			}
		} catch (Exception e) {

		}

		response.setBitmap(bmp);
		if (bmp != null) {
			response.setFile_name(file_name);
		}
		return response;
	}

	public static DownloadImageResponse downloadCachedImage(Context context, String url, long timestamp) throws IOException,
			MagickException {
		DownloadImageResponse downloadImageResponse = new DownloadImageResponse();

		// Return bitmap
		Bitmap bmp = null;

		String filename = ImageDownloader.getBitmapFilename(url);

		// Search
		File baseDirectory = context.getFilesDir();
		bmp = ImageDownloader.getBitmapFromStorageCache(context, url);

		if (bmp == null) {
			Log.d("Load image", "Load from server");

			String tempImagePath = context.getCacheDir() + File.separator + filename;

			final AndroidHttpClient client = AndroidHttpClient.newInstance("Android");
			final HttpGet getRequest = new HttpGet(url);
			HttpResponse response = client.execute(getRequest);
			final int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != HttpStatus.SC_OK) {
				client.close();
				Log.w("ImageDownloader", "Error " + statusCode + " while retrieving bitmap from " + filename);
				return null;
			}

			final HttpEntity entity = response.getEntity();
			if (entity != null) {
				try {
					InputStream input = entity.getContent();

					try {
						final File file = new File(tempImagePath);
						final OutputStream output = new FileOutputStream(file);
						try {
							try {
								final byte[] buffer = new byte[1024];
								int read;

								while ((read = input.read(buffer)) != -1)
									output.write(buffer, 0, read);

								output.flush();
							} finally {
								output.close();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} finally {
						input.close();
					}

					// Load image into bmp
					BitmapFactory.Options options = new BitmapFactory.Options();
					bmp = BitmapFactory.decodeFile(new File(tempImagePath).getAbsolutePath(), options);

					Log.d(TAG_LOG, "End downloaning");
					if (bmp == null) {
						Log.e(TAG_LOG, "Error downloaning");

						ImageInfo info = new ImageInfo(tempImagePath);
						MagickImage imageCMYK = new MagickImage(info);

						Log.d(TAG_LOG, "ColorSpace BEFORE => " + imageCMYK.getColorspace());
						boolean status = imageCMYK.transformRgbImage(ColorspaceType.CMYKColorspace);
						Log.d(TAG_LOG, "ColorSpace AFTER => " + imageCMYK.getColorspace() + ", success = " + status);

						imageCMYK.setFileName(baseDirectory + "/" + filename);
						imageCMYK.writeImage(info);
						bmp = BitmapFactory.decodeFile(baseDirectory + "/" + filename);
						if (bmp == null) {
							// if decoding fails, create empty image
							bmp = Bitmap.createBitmap(imageCMYK.getWidth(), imageCMYK.getHeight(), Config.ARGB_8888);
						}

					}
					if (bmp != null) {
						// Save bitmap in cache
						ImageDownloader.saveBitmapInCache(context, url, bmp, response);
					}
				} catch (IllegalStateException e) {
					getRequest.abort();
					Log.w(TAG_LOG, "Incorrect URL: " + filename);
				} catch (Exception e) {
					getRequest.abort();
					Log.w(TAG_LOG, "Error while retrieving bitmap from " + filename, e);
				}

				// Prevent gallery to use this images
				File nomedia = new File(baseDirectory + "/" + ".nomedia");
				if (!nomedia.exists()) {
					nomedia.createNewFile();
					Log.d("Load image", "End saving .nomedia");
				}
			}

			// Close http client
			client.close();

		}

		downloadImageResponse.setBitmap(bmp);
		if (bmp != null) {
			downloadImageResponse.setFile_name(filename);
		}
		return downloadImageResponse;
	}

	static class FlushedInputStream extends FilterInputStream {
		public FlushedInputStream(InputStream inputStream) {
			super(inputStream);
		}

		@Override
		public long skip(long n) throws IOException {
			long totalBytesSkipped = 0L;
			while (totalBytesSkipped < n) {
				long bytesSkipped = in.skip(n - totalBytesSkipped);
				if (bytesSkipped == 0L) {
					int b = read();
					if (b < 0) {
						break; // we reached EOF
					} else {
						bytesSkipped = 1; // we read one byte
					}
				}
				totalBytesSkipped += bytesSkipped;
			}
			return totalBytesSkipped;
		}
	}

	public static class PatchInputStream extends FilterInputStream {
		public PatchInputStream(InputStream in) {
			super(in);
		}

		public long skip(long n) throws IOException {
			long m = 0L;
			while (m < n) {
				long _m = in.skip(n - m);
				if (_m == 0L)
					break;
				m += _m;
			}
			return m;
		}
	}

}
