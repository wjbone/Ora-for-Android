package com.digitalgeko.mobile.android.asynctask;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.circles.ViewCircleFragment;
import net.ora.mobile.android.feed.SwipeToPrayDetector;
import net.ora.mobile.android.friends.PrayerDetailActivity;
import net.ora.mobile.android.friends.ProfileFriendActivity;
import net.ora.mobile.android.prayers.PrayedUsersForPrayerFragment;
import net.ora.mobile.android.prayers.PrayerCirclesFragment;
import net.ora.mobile.android.prayers.PrayerDetailFragment;
import net.ora.mobile.android.webservices.friends.WSFriendPrayers;
import net.ora.mobile.android.webservices.profile.WSPrayersForUser;
import net.ora.mobile.dto.circles.Circle;
import net.ora.mobile.dto.prayers.Prayer;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;
import com.digitalgeko.mobile.android.objects.profile.PrayerView;
import com.digitalgeko.mobile.android.ui.DGFragment;

public class ObtainProfilePrayersAsync extends AsyncTask<Void, Void, RequestPrayersResponse> {

	private OraApplication application;
	private Context context;
	private LinearLayout list;
	private BaseImageData fragmentActivityView;
	private User user;
	private boolean isFriend;

	public ObtainProfilePrayersAsync(OraApplication application, Context context, LinearLayout list, BaseImageData fragmentActivityView, User user,
			boolean isFriend) {
		super();
		this.application = application;
		this.context = context;
		this.list = list;
		this.fragmentActivityView = fragmentActivityView;
		this.user = user;
		this.isFriend = isFriend;
	}
	
	public Context getContext() {
		return context;
	}

	@Override
	protected RequestPrayersResponse doInBackground(Void... params) {
		RequestPrayersResponse tempResponse = null;

		if (isCancelled()) {
			return null;
		}

		if (isFriend) {
			tempResponse = WSFriendPrayers.requestPrayersForUser(getContext(), user, "1");
		} else {
			WSPrayersForUser.searchPrayers(getContext(), Integer.toString(user.getId()), "1");
			tempResponse = WSPrayersForUser.getResponse();
		}

		if (tempResponse != null) {
			return tempResponse;
		} else {
			cancel(true);
		}

		return null;
	}

	@Override
	protected void onPostExecute(RequestPrayersResponse response) {
		super.onPostExecute(response);

		// Set vars
		int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(getContext());

		list.removeAllViews();
		List<ImageView> pictures = new ArrayList<ImageView>();

		LayoutInflater inflater = LayoutInflater.from(getContext());
		for (final Prayer prayer : response.getPrayers()) {
			if (prayer.getUser() == null)
				prayer.setUser(user);

			ViewGroup viewPrayer = (ViewGroup) inflater.inflate(R.layout.item_feed_prayer, null);
			// Multiple listener
			OnClickListener goToProfileListener = new GoPrayerToFriendProfileManager(prayer);

			// Set info
			((TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer)).setText(prayer.getText());
			// Prayer User View
			TextView prayerUserTextView = ((TextView) viewPrayer.findViewById(R.id.tv_profile_name_prayer));
			prayerUserTextView.setText(prayer.getUser().getName());
			prayerUserTextView.setOnClickListener(goToProfileListener);

			// Go to user profile
			ImageView friendPicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_image_prayer);
			friendPicture.setOnClickListener(goToProfileListener);

			// Set circle
			ImageView circlePicture = (ImageView) viewPrayer.findViewById(R.id.iv_profile_circle_prayer);

			friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
			circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));

			fragmentActivityView.getPictureImageViewList().add(friendPicture);
			fragmentActivityView.getCircleImageViewList().add(circlePicture);

			// Save user/image view info
			pictures.add(friendPicture);

			// Circles
			int circlesCount = prayer.getCircles().size();
			String strCircles = "";
			if (circlesCount == 0) {
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setVisibility(View.GONE);
			} else {
				// Set listener
				viewPrayer.findViewById(R.id.feedPrayer_vgCircles).setOnClickListener(new GoPrayerCirclesManager(prayer));

				for (Circle circle : prayer.getCircles())
					strCircles += circle.getName() + ", ";
				strCircles = strCircles.substring(0, strCircles.length() - 2);
				// Set circles string
				((TextView) viewPrayer.findViewById(R.id.tv_profile_circles_prayer)).setText(strCircles);
			}

			// Set prayer likes count
			TextView likesCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_prayers_prayer));
			likesCount.setText(Integer.toString(prayer.getLikesCount()));

			// Set prayer comments count
			TextView commentsCount = ((TextView) viewPrayer.findViewById(R.id.tv_profile_comments_prayer));
			commentsCount.setText(Integer.toString(prayer.getCommentsCount()));
			// Set prayer time
			TextView timeCount = ((TextView) viewPrayer.findViewById(R.id.tv_pray_time));
			timeCount.setText(GeneralMethods.fromDate(GeneralMethods.parseStringToDate(prayer.getDateCreated())));
			View btnPray = viewPrayer.findViewById(R.id.feedPrayer_btnPray);

			// Set listeners
			TextView descriptionView = (TextView) viewPrayer.findViewById(R.id.tv_profile_text_prayer);
			descriptionView.setOnClickListener(new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray,
					false));
			if (prayer.isLikeAvailable()) {
				ViewGroup containerView = (ViewGroup) viewPrayer.findViewById(R.id.feedPrayer_vgContainer);
				btnPray.setOnTouchListener(new SwipeToPrayDetector(prayer, containerView));
			} else {
				btnPray.setVisibility(View.GONE);
			}
			viewPrayer.findViewById(R.id.feedPrayer_vgPrayersComments).setOnClickListener(
					new GoPrayerDetailManager(prayer, likesCount, commentsCount, timeCount, btnPray, true));
			if (prayer.getUser().equals(application.getUser())) {
				// Can see prays list only in is the owner of the pray
				viewPrayer.findViewById(R.id.feedPrayer_vgPrayersPrays).setOnClickListener(new GoPrayerPraysManager(prayer));
			}

			// Add view
			list.addView(viewPrayer);
			list.invalidate();
		}

		if (user.getProfilePicture().trim().length() > 0) {
			DownloadSamePicture asyncJob = new DownloadSamePicture(getContext(), fragmentActivityView, pictures,
					"UserFragment Prayers");
			fragmentActivityView.getAsyncTaskList().add(asyncJob);
			asyncJob.execute(user.getProfilePicture().trim());
		}

		View buttonView = inflater.inflate(R.layout.button_layout, null);

		Button button = (Button) buttonView.findViewById(R.id.b_button_layout);
		button.setText("See all prayers");
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				fragmentActivityView.goToAllPrayers();
			}
		});

		list.addView(buttonView);
		list.invalidate();
	}

	/**
	 * 
	 * @author Byron
	 * 
	 */
	public class GoPrayerDetailManager implements OnClickListener {

		private Prayer prayer;
		private TextView prayersCount, commentsCount, timeCount;
		private View grabber;
		private boolean showOnlyComments;

		public GoPrayerDetailManager(Prayer prayer, TextView prayersCount, TextView commentsCount, TextView timeCount,
				View grabber, boolean showOnlyComments) {
			this.prayer = prayer;
			this.prayersCount = prayersCount;
			this.commentsCount = commentsCount;
			this.timeCount = timeCount;
			this.grabber = grabber;
			this.showOnlyComments = showOnlyComments;
		}

		public void onClick(View view) {
			if (fragmentActivityView instanceof DGFragment) {
				((DGFragment) fragmentActivityView).pushFragment(PrayerDetailFragment.getInstance(prayer, showOnlyComments));
			} else {
				PrayerView prayerView = new PrayerView(prayer, prayersCount, commentsCount, timeCount, grabber);

				application.addParam("prayer_view", prayerView);
				application.addParam("prayer_friends", prayer);

				getContext().startActivity(new Intent(getContext(), PrayerDetailActivity.class));
			}
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerToFriendProfileManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerToFriendProfileManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (fragmentActivityView instanceof DGFragment) {
				DGFragment fragment = ((DGFragment) fragmentActivityView);
				fragment.getActivity().startActivity(
						new Intent(fragment.getActivity(), ProfileFriendActivity.class).putExtra("friend_id", prayer.getUser()
								.getId()));
			}
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerPraysManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerPraysManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (fragmentActivityView instanceof DGFragment) {
				DGFragment fragment = ((DGFragment) fragmentActivityView);
				fragment.pushFragment(PrayedUsersForPrayerFragment.getInstance(prayer));
			}
		}
	}

	/**
	 * 
	 * @author byron
	 * 
	 */
	public class GoPrayerCirclesManager implements OnClickListener {

		private Prayer prayer;

		public GoPrayerCirclesManager(Prayer prayer) {
			this.prayer = prayer;
		}

		@Override
		public void onClick(View v) {
			if (fragmentActivityView instanceof DGFragment) {
				DGFragment fragment = ((DGFragment) fragmentActivityView);
				if (prayer.getCircles().size() == 1) {
					Circle circle = prayer.getCircles().get(0);
					fragment.pushFragment(ViewCircleFragment.getInstance(circle));
				} else {
					fragment.pushFragment(PrayerCirclesFragment.getInstance(prayer));
				}
			}
		}
	}

}
