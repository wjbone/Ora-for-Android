package com.digitalgeko.mobile.android.ui;


import java.util.HashMap;
import java.util.Map;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.ActionBar.Tab;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.digitalgeko.mobile.android.ui.StackTabManager.DGTabListener;

public class BaseFragmentActivity<T extends StackTabManager> extends SherlockFragmentActivity 
		implements DGTabListener {

	protected Map<Tab, T> listeners;
	private ActionDialog<Object> actionDialog;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		
		// Create listeners 
		listeners = new HashMap<Tab, T>();

	}
	
	protected Tab addActionBarTab(int tabTitleResource, DGFragment fragment, T listener) {
		// Set action bar
		ActionBar actionbar = getSupportActionBar();
		
		// Set listener
		listener.setTabListener(this);
		
		// Create new tab
		Tab tab = actionbar.newTab().setText(getString(tabTitleResource));
		tab.setTabListener(listener);
		
		// Save reference
		listeners.put(tab, listener);
		
		// Add tab
		actionbar.addTab(tab);
		
		// Return
		return tab;
	}
	
	protected Tab addActionBarTabWithDrawable(int tabDrawableResource, DGFragment fragment, T listener) {
		// Set action bar
		ActionBar actionbar = getSupportActionBar();
		
		// Set listener
		listener.setTabListener(this);
		
		// Create new tab
		Tab tab = actionbar.newTab().setIcon(tabDrawableResource);
		tab.setTabListener(listener);
		
		// Save reference
		listeners.put(tab, listener);
		
		// Add tab
		actionbar.addTab(tab);
		
		// Return
		return tab;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			popFragment();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}
	
	public void pushFragment(DGFragment fragment) {
		// search for the current tab listener
		Tab tab = getSupportActionBar().getSelectedTab();
		StackTabManager listener = listeners.get(tab);
		
		// Create a new fragment transaction
		FragmentTransaction trans = getSupportFragmentManager().beginTransaction()
                .disallowAddToBackStack();
		// Push new fragment
		listener.pushFragment(fragment);
		// Repaint
		listener.onTabSelected(tab, trans);
		// End transaction
        if (!trans.isEmpty()) {
            trans.commit();
        }
        
        // Change icon
		showActionBarIcon(fragment.getActionBarString());
	}
	
	public void popFragment() {
		// search for the current tab listener
		Tab tab = getSupportActionBar().getSelectedTab();
		StackTabManager listener = listeners.get(tab);
		
		if(listener == null || listener.isLastFragment()) {
			finish();
		} else {
			
			// Create a new fragment transaction
			FragmentTransaction trans = getSupportFragmentManager().beginTransaction()
                    .disallowAddToBackStack();
			// Pop fragment
			listener.popFragment(trans);
			DGFragment fragment = listener.peekFragment();
			// End transaction
	        if (!trans.isEmpty()) {
	            trans.commit();
	        }
	        
			// Change icon
			showActionBarIcon(fragment.getActionBarString());
		}
		
	}
	
	public void popAllFragments(DGFragment fragment) {
		// search for the current tab listener
		Tab tab = getSupportActionBar().getSelectedTab();
		T listener = getSelectedTabListener();
		
		// Create a new fragment transaction
		FragmentTransaction trans = getSupportFragmentManager().beginTransaction()
                .disallowAddToBackStack();
		// Push new fragment
		listener.popAllFragments(fragment);
		// Repaint
		listener.onTabSelected(tab, trans);
		// End transaction
        if (!trans.isEmpty()) {
            trans.commit();
        }
        
		// Change icon
		showActionBarIcon(fragment.getActionBarString());
	}
	
	public T getSelectedTabListener() {
		Tab tab = getSupportActionBar().getSelectedTab();
		return listeners.get(tab);
	}
	
	protected void showActionBarIcon(int resourceId) {
		// search for the current tab listener
		Tab tab = getSupportActionBar().getSelectedTab();
		StackTabManager listener = listeners.get(tab);
		
		ActionBar actionbar = getSupportActionBar();
		if(listener.isLastFragment()) {
			actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_TITLE | ActionBar.DISPLAY_SHOW_HOME );
			actionbar.setHomeButtonEnabled(false);
		} else {
			actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_TITLE | ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_HOME);
			actionbar.setHomeButtonEnabled(true);
		}
		
		actionbar.setTitle(getString(resourceId));
		actionbar.show();
		
//		// Hide keyboard
//		InputMethodManager inputManager = (InputMethodManager)
//                getSystemService(Context.INPUT_METHOD_SERVICE); 
//		inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
//                   InputMethodManager.HIDE_NOT_ALWAYS);
//		
//		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//		imm.hideSoftInputFromWindow(this.getWindowToken(), 0);
	}
	
	protected DGFragment getFragment(int id) {
		return (DGFragment)getSupportFragmentManager().findFragmentById(id);
	}

	protected static void makeAction(ActionDialog action) {
		action.init();
	}
	
	@Override
	public void onTabSelected(DGFragment fragment) {
		showActionBarIcon(fragment.getActionBarString());		
	}
	
	protected void clearData() {
	}

	public ActionDialog<Object> getActionDialog() {
		return actionDialog;
	}

	public void setActionDialog(ActionDialog<Object> actionDialog) {
		this.actionDialog = actionDialog;
	}
}
