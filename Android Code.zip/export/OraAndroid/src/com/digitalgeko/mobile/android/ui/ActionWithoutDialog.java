package com.digitalgeko.mobile.android.ui;

import android.app.Activity;
import android.os.Handler;

public abstract class ActionWithoutDialog {

	protected Handler mHandler;
	protected boolean ready;
	protected Activity context;
	
	public ActionWithoutDialog(final Activity context) {
		// Configure context
		this.context = context;
	}
	
	public void init() {
		new Thread(){
			public void run() {
				ready = false;
				
				// Make request
				performAction();
				
				ready = true;
			}
		}.start();
		mHandler = new Handler();
		mHandler.removeCallbacks(stopProgressBar);
		mHandler.postDelayed(stopProgressBar, 50);
	}
	
	private Runnable stopProgressBar = new Runnable() {
		public void run(){
			if(!ready){
				mHandler.postDelayed(stopProgressBar, 50);
			}
		}
	};
	
	public abstract void performAction();
}
