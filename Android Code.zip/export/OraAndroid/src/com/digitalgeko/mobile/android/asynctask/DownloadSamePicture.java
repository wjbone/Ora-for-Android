package com.digitalgeko.mobile.android.asynctask;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.objects.DownloadImageResponse;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

@SuppressWarnings("unchecked")
public class DownloadSamePicture extends AsyncTask<String, Pair<Bitmap, ImageView>, Void> {

	private List<ImageView> listPictures;
	private Context context;
	private BaseImageData data;
	private String name;

	public DownloadSamePicture(Context context, BaseImageData data, List<ImageView> listPictures, String name) {
		this.context = context;
		this.data = data;
		this.listPictures = listPictures;
		this.name = name;
	}

	// @Override
	// protected Void doInBackground(String... params) {
	// Log.w("DownloadSamePicture", "Start: *" + name + "*");
	//
	// DownloadImageResponse response = new DownloadImageResponse();
	//
	// if(data.isDownloadFlag()){
	// Log.w("DownloadSamePicture", "Save Image");
	// response = ImageManager.downloadImage(context, params[0]);
	// }else{
	// Log.w("DownloadSamePicture", "Virtual Memory");
	// Bitmap temp = GeneralMethods.downloadImage(params[0]);
	// response = new DownloadImageResponse(temp, "");
	// }
	//
	// Log.w("DownloadSamePicture", "done");
	// if(response.getBitmap() != null){
	// final Bitmap temp = response.getBitmap();
	// final String name = response.getFile_name();
	//
	// //data.getBitmapPictureList().add(temp);
	//
	// context.runOnUiThread(new Runnable() {
	// @Override
	// public void run() {
	// for(ImageView image : listPictures){
	// image.setImageBitmap(temp);
	// image.invalidate();
	//
	// data.getPictureImageViewList().add(image);
	// data.getPictureNames().add(name);
	// }
	// }
	// });
	// }
	//
	// Log.w("DownloadSamePicture", "End: *" + name + "*");
	//
	// return null;
	// }

	@Override
	protected Void doInBackground(String... params) {
		Log.w("DownloadSamePicture", "Start: *" + name + "*");

		DownloadImageResponse response = new DownloadImageResponse();

		if (data.isDownloadFlag()) {
			Log.w("DownloadSamePicture", "Save Image");
			response = ImageManager.downloadImage(context, params[0]);
		} else {
			Log.w("DownloadSamePicture", "Virtual Memory");
			Bitmap temp = GeneralMethods.downloadImage(params[0]);
			response = new DownloadImageResponse(temp, "");
		}

		Log.w("DownloadSamePicture", "done");

		if (response.getBitmap() != null) {
			for (ImageView image : listPictures) {
				if (!isCancelled()) {
					Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
					tempPair[0] = new Pair<Bitmap, ImageView>(response.getBitmap(), image);
					publishProgress(tempPair);

					data.getPictureImageViewList().add(image);
					data.getPictureNames().add(response.getFile_name());
				} else {
					break;
				}
			}
		}

		Log.w("DownloadSamePicture", "End: *" + name + "*");

		return null;
	}

	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for (Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;

			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}

}
