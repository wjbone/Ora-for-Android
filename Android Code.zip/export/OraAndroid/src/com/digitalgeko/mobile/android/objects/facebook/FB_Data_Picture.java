package com.digitalgeko.mobile.android.objects.facebook;

public class FB_Data_Picture {
	
	private Boolean is_silhouette;
	private String url;

	public Boolean getIs_silhouette() {
		return is_silhouette;
	}

	public void setIs_silhouette(Boolean is_silhouette) {
		this.is_silhouette = is_silhouette;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
