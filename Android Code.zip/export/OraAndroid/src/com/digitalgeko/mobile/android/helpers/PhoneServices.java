package com.digitalgeko.mobile.android.helpers;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telephony.SmsManager;
import android.util.Log;

public final class PhoneServices {

	public static void phoneCall(Context context, String phoneNumber){
		try{
			Intent callIntent = new Intent(Intent.ACTION_CALL);
			callIntent.setData(Uri.parse("tel:" + phoneNumber));
			context.startActivity(callIntent);
		}catch(ActivityNotFoundException e){
			Log.e("Call failed", e.getMessage());
		}
	}
	
	public static void sendEmail(Context context, String email, String subject){
		Intent itSend = new Intent(Intent.ACTION_SEND);
		itSend.setType("plain/text");
		itSend.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
		itSend.putExtra(Intent.EXTRA_SUBJECT, subject);
		context.startActivity(itSend);
	}
	
	public static void sendSMS(String phoneNumber, String message){
		SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
	}
	
	
}
