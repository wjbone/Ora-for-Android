package com.digitalgeko.mobile.android.objects.facebook;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class FB_Friend {

	private FB_Picture picture;
	private String id, username, name;
	
	@JsonIgnore
	private Bitmap bitmap_picture;
	
	public void freeBitmapMemory(){
		if(bitmap_picture != null){
			bitmap_picture.recycle();
			//System.gc();
		}
	}
	
	public void generateBitmap(){
		bitmap_picture = null;
		
		int intentos = 0;
		boolean exception = true;
		while((exception) && (intentos < 3)){
			try {
				URL imageURL = new URL(getPicture().getData().getUrl());
				HttpURLConnection conn = (HttpURLConnection) imageURL.openConnection();
				conn.connect();
				InputStream bitIs = conn.getInputStream();
				if(bitIs != null){
					Bitmap bitmap = BitmapFactory.decodeStream(bitIs);
					/*Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
					
					BitmapShader shader = new BitmapShader (bitmap,  TileMode.CLAMP, TileMode.CLAMP);
					Paint paint = new Paint();
					paint.setShader(shader);
					
					Canvas c = new Canvas(circleBitmap);
					c.drawCircle(bitmap.getWidth()/2, bitmap.getHeight()/2, (float) (((bitmap.getWidth() + bitmap.getHeight()) / 2) * 0.4), paint);
					
					bitmap_picture = circleBitmap;*/
					bitmap_picture = bitmap;
					exception = false;
				}else{
					Log.e("InputStream", "Viene null");
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
				exception = true;
			} catch (IOException e) {
				e.printStackTrace();
				exception = true;
			}
			intentos++;
		}
	}

	public Bitmap getBitmap_picture() {
		return bitmap_picture;
	}

	public void setBitmap_picture(Bitmap bitmap_picture) {
		this.bitmap_picture = bitmap_picture;
	}

	public FB_Picture getPicture() {
		return picture;
	}

	public void setPicture(FB_Picture picture) {
		this.picture = picture;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
