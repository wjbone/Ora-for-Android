package com.digitalgeko.mobile.android.asynctask;

import net.ora.mobile.dto.activity.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

@SuppressWarnings("unchecked")
public class DownloadNotificationImageAsyncTask extends AsyncTask<Pair<Notification, ImageView>, Pair<Bitmap, ImageView>, Void> {

	private Context context;
	private BaseImageData fragment;

	public DownloadNotificationImageAsyncTask(Context context, BaseImageData fragment) {
		super();
		this.context = context;
		this.fragment = fragment;
	}

	@Override
	protected Void doInBackground(Pair<Notification, ImageView>... params) {
		Log.w("DownloadActivityRequestImage", "Init");

		// Vars
		int width = GeneralMethods.getProfileImageWidth(context);

		for (int i = 0; i < params.length; i++) {
			Notification notification = params[i].first;
			ImageView imageView = params[i].second;

			String imageUrl = notification.getNotificationImageUrl();
			if (imageUrl != null && imageUrl.length() > 0) {
				try {
					Bitmap base = ImageManager.downloadCachedImage(context, imageUrl, 0L).getBitmap();
					Bitmap temp = base;
					temp = Bitmap.createScaledBitmap(base, width, width, false);
					base.recycle();

					if (!isCancelled()) {
						fragment.getBitmapPictureList().add(temp);
						Pair<Bitmap, ImageView> tempPair = new Pair<Bitmap, ImageView>(temp, imageView);
						publishProgress(tempPair);
					}
				} catch (Exception e) {
				}
			}

			if (isCancelled()) {
				break;
			}
		}

		Log.w("DownloadActivityRequestImage", "Finish Processiong Images");
		return null;
	}

	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for (Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;

			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}

}
