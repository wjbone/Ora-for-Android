package com.digitalgeko.mobile.android.objects.friends;

import com.digitalgeko.mobile.android.objects.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FriendProfileUser extends User {

	@JsonProperty(value="is_friend")
	private boolean isFriend;
	
	@JsonProperty(value="is_requested")
	private boolean isRequested;
	
	@JsonProperty(value="is_blocked")
	private boolean isBlocked;
	
	public String getRealName(){
		return ((getName() == null) || (getName().trim().length() == 0) ? getUsername() : getName());
	}
	
	public boolean isFriend() {
		return isFriend;
	}
	
	public void setFriend(boolean isFriend) {
		this.isFriend = isFriend;
	}
	
	public boolean isRequested() {
		return isRequested;
	}
	
	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}
	
	public boolean isBlocked() {
		return isBlocked;
	}
	
	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}
	
}
