package com.digitalgeko.mobile.android.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ScrollView;

import com.handmark.pulltorefresh.library.PullToRefreshScrollView;
import com.handmark.pulltorefresh.library.R;

public class OraPullToRefreshScrollView extends PullToRefreshScrollView {

	private ScrollViewListener scrollViewListener = null;
	private ScrollViewExt scrollView; 

	public OraPullToRefreshScrollView(Context context) {
		super(context);
	}

	public OraPullToRefreshScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public OraPullToRefreshScrollView(Context context, Mode mode) {
		super(context, mode);
	}

	public OraPullToRefreshScrollView(Context context, Mode mode, AnimationStyle style) {
		super(context, mode, style);
	}

	public void setScrollViewListener(ScrollViewListener scrollViewListener) {
		this.scrollViewListener = scrollViewListener;
		if(scrollView != null) {
			scrollView.setScrollViewListener(scrollViewListener);
		}
	}

	@Override
	protected ScrollView createRefreshableView(Context context, AttributeSet attrs) {
		scrollView = new ScrollViewExt(context, attrs);
		
//		if (VERSION.SDK_INT >= VERSION_CODES.GINGERBREAD) {
//			scrollView = new InternalScrollViewSDK9(context, attrs);
//		} else {
//			scrollView = new ScrollView(context, attrs);
//		}

		scrollView.setId(R.id.scrollview);
		return scrollView;
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		if (scrollViewListener != null && getChildCount() > 0) {

			// We take the last son in the scrollview
			View view = (View) getChildAt(getChildCount() - 1);
			int diff = (view.getBottom() - (getHeight() + getScrollY()));

			// if diff is zero, then the bottom has been reached
			if (diff <= 0) {
				// // Load next page of the circle's prayers
				scrollViewListener.onScrollBottomReached((ScrollViewExt) getRefreshableView());
				return;
			}
			
			// Reach top
			view = getChildAt(0);
			diff = getScrollY();
			if(diff <= 0) {
				scrollViewListener.onScrollTopReached((ScrollViewExt) getRefreshableView());
			}
		}
		super.onScrollChanged(l, t, oldl, oldt);
	}

}
