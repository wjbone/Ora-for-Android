package com.digitalgeko.mobile.android.objects.profile;

import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.webservices.profile.WSPrayersForUser;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;
import android.app.Activity;
import android.support.v4.content.AsyncTaskLoader;

public class UserPrayerLoader extends AsyncTaskLoader<RequestPrayersResponse> {

	private Activity activity;
	private String nextPage;
	
	public UserPrayerLoader(Activity activity, String nextPage) {
		super(activity);
		this.activity = activity;
		this.nextPage = nextPage;
	}

	@Override
	public RequestPrayersResponse loadInBackground() {
		WSPrayersForUser.searchPrayers(activity, Integer.toString(((OraApplication) activity.getApplication()).getUser().getId()), nextPage);
		return WSPrayersForUser.getResponse();
	}
	
	@Override
	protected void onStartLoading() {
	    forceLoad();
	}

	@Override
	protected void onStopLoading() {
	    cancelLoad();
	}

	@Override
	protected void onReset() {
	    super.onReset();        
	    onStopLoading();     
	}

}
