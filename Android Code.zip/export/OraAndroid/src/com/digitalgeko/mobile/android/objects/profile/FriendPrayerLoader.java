package com.digitalgeko.mobile.android.objects.profile;

import com.digitalgeko.mobile.android.objects.User;

import net.ora.mobile.android.webservices.friends.WSFriendPrayers;
import net.ora.mobile.dto.profile.response.RequestPrayersResponse;
import android.app.Activity;
import android.support.v4.content.AsyncTaskLoader;

public class FriendPrayerLoader extends AsyncTaskLoader<RequestPrayersResponse> {

	private Activity activity;
	private String nextPage;
	private User user;
	
	public FriendPrayerLoader(Activity activity, String nextPage, User user) {
		super(activity);
		this.activity = activity;
		this.nextPage = nextPage;
		this.user = user;
	}

	@Override
	public RequestPrayersResponse loadInBackground() {
		return WSFriendPrayers.requestPrayersForUser(activity, user, nextPage);
	}
	
	@Override
	protected void onStartLoading() {
	    forceLoad();
	}

	@Override
	protected void onStopLoading() {
	    cancelLoad();
	}

	@Override
	protected void onReset() {
	    super.onReset();        
	    onStopLoading();     
	}

}
