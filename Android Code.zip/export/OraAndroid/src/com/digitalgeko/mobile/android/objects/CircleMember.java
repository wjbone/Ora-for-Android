package com.digitalgeko.mobile.android.objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CircleMember extends User {

	@JsonProperty(value="is_invited")
	protected boolean isInvited;
	
	@JsonProperty(value="is_member")
	protected boolean isMember;
	
	@JsonProperty(value="var_par")
	protected boolean varPar;

	public boolean isInvited() {
		return isInvited;
	}

	public void setInvited(boolean isInvited) {
		this.isInvited = isInvited;
	}

	public boolean isMember() {
		return isMember;
	}

	public void setMember(boolean isMember) {
		this.isMember = isMember;
	}

	public boolean isVarPar() {
		return varPar;
	}

	public void setVarPar(boolean varPar) {
		this.varPar = varPar;
	}

}
