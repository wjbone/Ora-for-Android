package com.digitalgeko.mobile.android.objects.profile;

import net.ora.mobile.dto.prayers.Prayer;
import android.view.View;
import android.widget.TextView;

public class PrayerView {

	private Prayer prayer;	
	private TextView prayersCount, commentsCount, timeCount;	
	private View grabber;

	public PrayerView(Prayer prayer, TextView prayersCount, TextView commentsCount, TextView timeCount, View grabber) {
		this.prayer = prayer;
		this.prayersCount = prayersCount;
		this.commentsCount = commentsCount;
		this.timeCount = timeCount;
		this.grabber = grabber;
	}

	public Prayer getPrayer() {
		return prayer;
	}

	public void setPrayer(Prayer prayer) {
		this.prayer = prayer;
	}

	public TextView getPrayersCount() {
		return prayersCount;
	}

	public void setPrayersCount(TextView prayersCount) {
		this.prayersCount = prayersCount;
	}

	public TextView getCommentsCount() {
		return commentsCount;
	}

	public void setCommentsCount(TextView commentsCount) {
		this.commentsCount = commentsCount;
	}

	public TextView getTimeCount() {
		return timeCount;
	}

	public void setTimeCount(TextView timeCount) {
		this.timeCount = timeCount;
	}

	public View getGrabber() {
		return grabber;
	}

	public void setGrabber(View grabber) {
		this.grabber = grabber;
	}
	
}
