package com.digitalgeko.mobile.android.objects;

import android.os.Parcel;
import android.os.Parcelable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class User implements Parcelable {
	
	public static final String FOREIGN_FIELD_USER_ID = "user_id";
	
	@JsonIgnore
	protected boolean haveNotification = false;
	
	@JsonIgnore
	protected Integer hour;
	
	@JsonIgnore
	protected Integer minute;
	
	@DatabaseField(id = true)
	protected int id;

//	@DatabaseField(generatedId = true)
//	@JsonIgnore
//	protected int dbId;
	
	@DatabaseField
	protected String city;

	@DatabaseField
	protected String about;

	@DatabaseField
	protected String name;

	@DatabaseField
	protected String mobile;

	@DatabaseField
	@JsonProperty(value = "notifications_count")
	protected int notificationsCount;

	@DatabaseField
	@JsonProperty(value = "fb_id")
	protected String fbId;

	@DatabaseField
	@JsonProperty(value = "is_premium")
	protected boolean isPremium;

	@DatabaseField
	@JsonProperty(value = "profile_picture")
	protected String profilePicture;

	@DatabaseField
	@JsonProperty(value = "tw_id")
	protected String twId;

	@DatabaseField
	protected String email;

	@DatabaseField
	protected String username;

	@DatabaseField
	@JsonProperty(value = "ignore_lite")
	protected boolean ignoreLite;
	
	@DatabaseField
	@JsonProperty(value="friends_count")
	protected int friendsCount;
	
	@DatabaseField
	@JsonProperty(value="prayers_count")
	protected int prayersCount;
	
	@DatabaseField
	@JsonProperty(value="circles_used")
	protected int circlesUsed;
	
	@DatabaseField
	@JsonProperty(value="circles_count")
	protected int circlesCount;
	
	@DatabaseField
	@JsonProperty(value="related_circles_count")
	protected int relatedCirclesCount;
	
	@DatabaseField
	@JsonProperty(value="private")
	protected boolean privateProfile;
	
	@DatabaseField
	@JsonProperty(value="is_friend")
	protected boolean isFriend;
	
	@DatabaseField
	@JsonProperty(value="is_requested")
	protected boolean isRequested;
	
	@DatabaseField
	@JsonProperty(value="is_blocked")
	protected boolean isBlocked;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getNotificationsCount() {
		return notificationsCount;
	}

	public void setNotificationsCount(int notificationsCount) {
		this.notificationsCount = notificationsCount;
	}

	public String getFbId() {
		return fbId;
	}

	public void setFbId(String fbId) {
		this.fbId = fbId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isPremium() {
		return isPremium;
	}

	public void setPremium(boolean isPremium) {
		this.isPremium = isPremium;
	}

	public String getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(String profilePicture) {
		this.profilePicture = profilePicture;
	}

	public String getTwId() {
		return twId;
	}

	public void setTwId(String twId) {
		this.twId = twId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return (name == null) ? "" : name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public boolean isIgnoreLite() {
		return ignoreLite;
	}

	public void setIgnoreLite(boolean ignoreLite) {
		this.ignoreLite = ignoreLite;
	}
	
	public int getFriendsCount() {
		return friendsCount;
	}

	public void setFriendsCount(int friendsCount) {
		this.friendsCount = friendsCount;
	}

	public int getPrayersCount() {
		return prayersCount;
	}

	public void setPrayersCount(int prayersCount) {
		this.prayersCount = prayersCount;
	}

	public int getCirclesUsed() {
		return circlesUsed;
	}

	public void setCirclesUsed(int circlesUsed) {
		this.circlesUsed = circlesUsed;
	}

	public int getCirclesCount() {
		return circlesCount;
	}

	public void setCirclesCount(int circlesCount) {
		this.circlesCount = circlesCount;
	}

	public int getRelatedCirclesCount() {
		return relatedCirclesCount;
	}

	public void setRelatedCirclesCount(int relatedCirclesCount) {
		this.relatedCirclesCount = relatedCirclesCount;
	}

	public boolean isPrivateProfile() {
		return privateProfile;
	}

	public void setPrivateProfile(boolean privateProfile) {
		this.privateProfile = privateProfile;
	}
	
	public void changePrivateProfile(){
		setPrivateProfile(!this.privateProfile);
	}
	
	public boolean isFriend() {
		return isFriend;
	}

	public void setFriend(boolean isFriend) {
		this.isFriend = isFriend;
	}

	public boolean isRequested() {
		return isRequested;
	}

	public void setRequested(boolean isRequested) {
		this.isRequested = isRequested;
	}

	public boolean isBlocked() {
		return isBlocked;
	}

	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}
	
	
	/*
	 * Constructor
	 * 
	 */
	public User() {
		super();
	}
	
	public User(User user) {
		this.setCity(user.getCity());
		this.setAbout(user.getAbout());
		this.setName(user.getName());
		this.setMobile(user.getMobile());
		this.setNotificationsCount(user.getNotificationsCount());
		this.setFbId(user.getFbId());
		this.setId(user.getId());
		this.setPremium(user.isPremium());
		this.setProfilePicture(user.getProfilePicture());
		this.setTwId(user.getTwId());
		this.setEmail(user.getEmail());
		this.setUsername(user.getUsername());
		this.setIgnoreLite(user.isIgnoreLite());
	}
	
	/*
	 * 
	 */
	public String getRealName(){
		return ((name == null) || (name.trim().length() == 0) ? username : name);
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof User) {
			User other = (User)o;
			return other.getId() == getId();
		}
		return super.equals(o);
	}

	protected User(Parcel in) {
		city = in.readString();
		about = in.readString();
		name = in.readString();
		mobile = in.readString();
		notificationsCount = in.readInt();
		fbId = in.readString();
		id = in.readInt();
		isPremium = in.readByte() != 0x00;
		profilePicture = in.readString();
		twId = in.readString();
		email = in.readString();
		username = in.readString();
		ignoreLite = in.readByte() != 0x00;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(city);
		dest.writeString(about);
		dest.writeString(name);
		dest.writeString(mobile);
		dest.writeInt(notificationsCount);
		dest.writeString(fbId);
		dest.writeInt(id);
		dest.writeByte((byte) (isPremium ? 0x01 : 0x00));
		dest.writeString(profilePicture);
		dest.writeString(twId);
		dest.writeString(email);
		dest.writeString(username);
		dest.writeByte((byte) (ignoreLite ? 0x01 : 0x00));
	}

	public static final Parcelable.Creator<User> CREATOR = new Parcelable.Creator<User>() {
		public User createFromParcel(Parcel in) {
			return new User(in);
		}

		public User[] newArray(int size) {
			return new User[size];
		}
	};

	public boolean isHaveNotification() {
		return haveNotification;
	}

	public void setHaveNotification(boolean haveNotification) {
		this.haveNotification = haveNotification;
	}

	public int getHour() {
		return (hour == null) ? -1 : hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMinute() {
		return (minute == null) ? -1 : minute;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

}
