package com.digitalgeko.mobile.android.ui;

import android.content.Context;
import android.os.Handler;
import android.support.v4.content.AsyncTaskLoader;
import android.widget.Toast;

public abstract class DGAsyncTaskLoader<D> extends AsyncTaskLoader<D> {

	public DGAsyncTaskLoader(Context context) {
		super(context);
	}

	@Override
	protected void onStartLoading() {
		if (UIConfiguration.shouldMakeNextAction())
			forceLoad();
	}

	@Override
	protected void onStopLoading() {
		cancelLoad();
	}

	@Override
	protected void onReset() {
		super.onReset();
		onStopLoading();
	}

	protected void showErrorMessage(final String errorMessage) {
		Handler mainHandler = new Handler(getContext().getMainLooper());

		Runnable myRunnable = new Runnable() {
			@Override
			public void run() {
				Toast.makeText(getContext(), errorMessage, 
						Toast.LENGTH_SHORT).show();
			}
		};
		mainHandler.post(myRunnable);
	}
}
