package com.digitalgeko.mobile.android.objects.profile;

public class PhoneContact {

	private Long mobile;
	
	private String email;

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
