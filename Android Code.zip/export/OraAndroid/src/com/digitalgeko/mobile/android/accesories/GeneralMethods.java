package com.digitalgeko.mobile.android.accesories;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;
import net.ora.mobile.android.R;
import org.json.JSONArray;
import org.json.JSONException;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.TextView;

@SuppressWarnings("unused")
public final class GeneralMethods {

	public static boolean isKey(JSONArray nombres, String key) {
		boolean response = false;
		for(int i = 0; i < nombres.length(); i++) {
			try {
				if(nombres.getString(i).equals(key)) {
					response = true;
				}
			} catch (JSONException e) {
				Log.e("GeneralMethods - isKey", e.getMessage());
			}
		}
		return response;
	}
	
	public static void crearDialogoOk(String message, Context context){
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message);
		builder.setNeutralButton(context.getString(R.string.base_btnOK), new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}			
		});		
		builder.create().show();
	}
	
	public static void crearDialogFinish(String message, Context context, final Activity activity){
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message);
		builder.setNeutralButton(context.getString(R.string.base_btnOK), new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				activity.finish();
			}			
		});		
		builder.create().show();
	}
	
	public static void exitOfSystem(String message, final Context context, final Activity activity){
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message);
		builder.setNeutralButton(context.getString(R.string.base_btnOK), new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				salirDelSistema(context, activity);
			}			
		});		
		builder.create().show();
	}
	
	public static void showDialogYesNo(String message, final Context context, 
			final Activity activity, final Runnable runnable){
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message);
		builder.setPositiveButton(context.getString(R.string.base_btnYes), new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				runnable.run();
			}			
		});
		builder.setNegativeButton(context.getString(R.string.base_btnNo), new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}			
		});
		builder.setCancelable(true);
		builder.create().show();
	}
	
	@SuppressLint("NewApi")
	@SuppressWarnings("deprecation")
	public static int getWidth(Context context){
		Display display = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		
		int width;
		
		if(Build.VERSION.SDK_INT >= 13) {
			Point size = new Point();
			display.getSize(size);
			width = size.x;
		} else {
			width = display.getWidth();
		}
		
		return width;
	}
	
	public static int getProfileBackgroundWidth(Activity activity){
		return ((int) (getWidth(activity) * 0.3));
	}
	
	public static int getProfileImageWidth(Context context){
		if(context == null) {
			return 0;
		}
		
		Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		
		int width = (int) (getWidth(context) * 0.15);
		
		switch (metrics.densityDpi) {
		case DisplayMetrics.DENSITY_LOW:
			width = (width > 36) ? 36 : width;
			break;
		case DisplayMetrics.DENSITY_MEDIUM:
			width = (width > 48) ? 48 : width;
			break;
		case DisplayMetrics.DENSITY_HIGH:
			width = (width > 72) ? 72 : width;
			break;
		case DisplayMetrics.DENSITY_XHIGH:
			width = (width > 96) ? 96 : width;
			break;
		case DisplayMetrics.DENSITY_XXHIGH:
			width = (width > 144) ? 144 : width;
			break;
		}
		
		return width;
	}
		
	public static Bitmap downloadImage(String url){
		Bitmap result = null;
		
		int intentos = 0;
		boolean exception = true;
		while((exception) && (intentos < 3)){
			try {
				URL imageURL = new URL(url);
				HttpURLConnection conn = (HttpURLConnection) imageURL.openConnection();
				conn.connect();
				InputStream bitIs = conn.getInputStream();
				if(bitIs != null){
					BitmapFactory.Options options = new BitmapFactory.Options();
					options.inSampleSize = 2;
					result = BitmapFactory.decodeStream(bitIs, null, options);
					exception = false;
				}else{
					Log.e("InputStream", "Viene null");
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
				exception = true;
			} catch (IOException e) {
				e.printStackTrace();
				exception = true;
			}
			intentos++;
		}
		
		return result;
	}
	
	public static TextView createLine(int colorLine, Context context){
		TextView result = new TextView(context);
		result.setTextSize(1);
		result.setBackgroundColor(context.getResources().getColor(colorLine));
		return result;
	}
	
	public static Calendar parseDate(String date){
		
		String dateSample = "10-01-2010 21:10:05";
		if(Pattern.matches("\\d\\d-\\d\\d-\\d\\dT\\d\\d:\\d\\d:\\d\\d", date)){
			String[] timeArray = date.split("T");
			String[] dateArray = timeArray[0].split("-");
			String[] hourArray = timeArray[1].split(":");
			
			Calendar result = Calendar.getInstance();
			
			result.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateArray[0]));
			result.set(Calendar.MONTH, Integer.parseInt(dateArray[1]));
			result.set(Calendar.YEAR, Integer.parseInt(dateArray[2]));
			
			result.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hourArray[0]));
			result.set(Calendar.MINUTE, Integer.parseInt(hourArray[1]));
			result.set(Calendar.SECOND, Integer.parseInt(hourArray[2]));
			
			return result;
		}
		
		return null;
	}
	
	public static Date parseStringToDate(String date){
		
		try {
			TimeZone timeZone = TimeZone.getTimeZone("UTC");
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss", 
					Locale.getDefault());
			format.setTimeZone(timeZone);
			Date object = format.parse(date);
			return object;
		} catch (Exception e) {
		}
		
		return null;
	}
	
	public static String fromDate(Date date){
		String result = "";
		
		Long difference = System.currentTimeMillis() - date.getTime();
		final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000;
		final long MILLSECS_PER_HOUR = 60 * 60 * 1000;
		final long MILLSECS_PER_MINUTE = 60 * 1000;
		
		long time = difference / MILLSECS_PER_DAY;
		if(time > 0){
			result = time + " days ago";
		}else{
			time = difference / MILLSECS_PER_HOUR;
			if(time > 0){
				result = time + " hours ago";
			}else{
				time = difference / MILLSECS_PER_MINUTE;
				result = time + " minutes ago";
			}
		}
		
		return result;
	}
	
	public static long parsePhoneNumber(String number){
		StringBuilder newNumber = new StringBuilder();
		
		if(number != null) {
			for(int i = 0; i < number.length(); i++) {
				if(Character.isDigit(number.charAt(i))){
					newNumber.append(number.charAt(i));
				}
			}
		}
		
		return ((newNumber.length() > 0) && (newNumber.length() < 12)) ? Long.parseLong(newNumber.toString()) : 0;
	}
	
	public static void salirDelSistema(Context context, Activity activity){
//		activity.startActivity(new Intent().setComponent(new ComponentName(context, ViewValidateUser.class)));
//		MasterService.resetPile();
//		MasterService.setToken(null);
//		WSValidateLealtadUser.cardNumber = null;
//		WSLoginVirtual.response = null;
	}
	
}
