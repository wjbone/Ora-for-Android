package com.digitalgeko.mobile.android.ui;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.asynctask.AsyncDowloadImageContactFriends;

public class DGListFriendsFragment extends DGFragment {
	
	public List<ImageView> friendsImageList = new ArrayList<ImageView>();
	public List<ImageView> friendsCircleList = new ArrayList<ImageView>();
	public List<Bitmap> friendsPictureList = new ArrayList<Bitmap>();
	public List<AsyncDowloadImageContactFriends> friendsRequestList = new ArrayList<AsyncDowloadImageContactFriends>();
	
	@Override
	public void onDestroy(){
		super.onDestroy();
		for(AsyncDowloadImageContactFriends temp : friendsRequestList){
			temp.cancel(true);
		}
		
		for(ImageView temp : friendsImageList){
			unbindDrawables(temp);
		}
		
		for(ImageView temp : friendsCircleList){
			unbindDrawables(temp);
		}
		
		for(Bitmap temp : friendsPictureList){
			temp.recycle();
		}
		
		System.gc();
	}
	
	protected void unbindDrawables(View view){
		if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            	unbindDrawables(((ViewGroup) view).getChildAt(i));
            }
            ((ViewGroup) view).removeAllViews();
        }
	}

}
