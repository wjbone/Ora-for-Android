package com.digitalgeko.mobile.android.asynctask;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.User;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

public class AsyncDownloadImageUser extends AsyncTask<Pair<User, ImageView>, Pair<Bitmap, ImageView>, Void> {

	private Context context;
	private String name;
	private BaseImageData fragment;
	private boolean shouldResize = true;

	public AsyncDownloadImageUser(String name, Context context, BaseImageData fragment) {
		super();
		this.name = name;
		this.context = context;
		this.fragment = fragment;
	}

	public void setShouldResize(boolean shouldResize) {
		this.shouldResize = shouldResize;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Void doInBackground(Pair<User, ImageView>... params) {
		int width = GeneralMethods.getProfileImageWidth(context);

		Log.d("Download Short User Image", name);
		for (int i = 0; i < params.length; i++) {
			User user = params[i].first;
			ImageView imageView = params[i].second;

			if (user.getProfilePicture().trim().length() > 0) {
				try {
					Bitmap base = ImageManager.downloadCachedImage(context, user.getProfilePicture(), 0L).getBitmap();
					Bitmap temp = base;
					if (shouldResize) {
						temp = Bitmap.createScaledBitmap(base, width, width, false);
						base.recycle();
					}

					if (!isCancelled()) {
						fragment.getBitmapPictureList().add(temp);
						Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
						tempPair[0] = new Pair<Bitmap, ImageView>(temp, imageView);
						publishProgress(tempPair);
					}
				} catch (Exception e) {
				}
			}

			if (isCancelled()) {
				break;
			}
		}
		Log.i("Download Short User Image", "Ending Process Images - " + name);

		return null;
	}

	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for (Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;

			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}
}
