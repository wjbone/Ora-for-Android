package com.digitalgeko.mobile.android.objects.friends;

import net.ora.mobile.android.webservices.circles.WSCirclePrayers;
import net.ora.mobile.dto.circles.response.CirclePrayersResponse;
import android.app.Activity;
import android.support.v4.content.AsyncTaskLoader;

public class CirclePrayerLoader extends AsyncTaskLoader<CirclePrayersResponse> {
	
	private Activity activity;
	private int next_page, circle_id;

	public CirclePrayerLoader(Activity context, int next_page, int circle_id) {
		super(context);
		this.activity = context;
		this.next_page = next_page;
		this.circle_id = circle_id;
	}

	@Override
	public CirclePrayersResponse loadInBackground() {
		CirclePrayersResponse response = WSCirclePrayers.getCirclePrayers(activity, circle_id, WSCirclePrayers.PRAYER_ID_ALL_PRAYERS, next_page);
		return response;
	}
	
	@Override
	protected void onStartLoading() {
	    forceLoad();
	}

	@Override
	protected void onStopLoading() {
	    cancelLoad();
	}

	@Override
	protected void onReset() {
	    super.onReset();        
	    onStopLoading();     
	}

}
