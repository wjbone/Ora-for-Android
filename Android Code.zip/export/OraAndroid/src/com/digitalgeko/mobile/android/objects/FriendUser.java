package com.digitalgeko.mobile.android.objects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FriendUser {

	private String name;

	private String city;
	
	@JsonProperty(value="is_friend")
	private boolean friend;
	
	@JsonProperty(value="is_requested")
	private boolean requested;
	
	@JsonProperty(value="is_blocked")
	private boolean blocked;
	
	@JsonProperty(value="profile_picture")
	private String picture;
	
	private int id;
	
	@JsonIgnore
	public String getStringId(){
		return Integer.toString(id);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public boolean isFriend() {
		return friend;
	}

	public void setFriend(boolean friend) {
		this.friend = friend;
	}

	public boolean isRequested() {
		return requested;
	}

	public void setRequested(boolean requested) {
		this.requested = requested;
	}

	public boolean isBlocked() {
		return blocked;
	}

	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	public FriendUser() {
	}
	
	public FriendUser(User user) {
		setName(user.getName());
		setCity(user.getCity());
//		setFriend(user.isFriend);
//		setBlocked(user.isBlocked());
		setPicture(user.getProfilePicture());
		setId(user.getId());
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof User) {
			User other = (User)o;
			return other.getId() == getId();
		}
		return super.equals(o);
	}
}
