package com.digitalgeko.mobile.android.asynctask;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import net.ora.mobile.android.profile.AddOraFriendsListFragment;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSSearchUser;
import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.objects.AsyncSearchFriendsResponse;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.RequestFriendshipDialog;

public class LoadingSearchFriendsAsync extends AsyncTask<String, Void, AsyncSearchFriendsResponse> {
	
	private LinearLayout list;
	private Activity context;
	private View loadingView;
	private String name;
	private AddOraFriendsListFragment fragment;
	
	public LoadingSearchFriendsAsync(String name, Activity context, LinearLayout list, View loading, AddOraFriendsListFragment fragment){
		super();
		this.name = name;
		this.context = context;
		this.list = list;
		this.loadingView = loading;
		this.fragment = fragment;
	}

	@Override
	protected AsyncSearchFriendsResponse doInBackground(String... params) {
		Log.w("LoadingSearchFriendsAsync", name);
		
		WSSearchUser.searchForUser(context, params[0], params[1], params[2]);
		final List<ImageView> listForImages = new ArrayList<ImageView>();
		
		context.runOnUiThread(new Runnable(){
			public void run() {
				if(MasterService.isFailedConnection()){
					GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
				}else{
					list.removeView(loadingView);
					
					int width = com.digitalgeko.mobile.android.accesories.GeneralMethods.getProfileImageWidth(context);
					LayoutInflater inflater = LayoutInflater.from(context);
					
					for(final FriendUser temp : WSSearchUser.getResponse().getUsers()){
						View view = inflater.inflate(R.layout.item_friend_list, null);
						
						final TextView div = GeneralMethods.createLine(R.color.friends_div_line, context);
						
						ImageView friendPicture = ((ImageView) view.findViewById(R.id.iv_item_friend_image));
						ImageView circlePicture = (ImageView) view.findViewById(R.id.iv_friends_Cirle);
						
						friendPicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
						circlePicture.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(width, width));
						
						fragment.getPictureImageViewList().add(friendPicture);
						listForImages.add(friendPicture);
						fragment.getCircleImageViewList().add(circlePicture);
						
						((TextView) view.findViewById(R.id.tv_item_friend_name)).setText(temp.getName());
						
						final ImageButton button = ((ImageButton) view.findViewById(R.id.b_item_friend_button));
						if(temp.isFriend()){
							button.setImageResource(R.drawable.ic_check_green);
						}else if(temp.isRequested()){
							button.setImageResource(R.drawable.ic_check_gray_pending);
						}else{
							button.setImageResource(R.drawable.ic_add_request);
						}
						button.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								if((!temp.isFriend()) && (!temp.isRequested())){
									new RequestFriendshipDialog(context, button, temp, null).init();
								}
							}
						});
						
						list.addView(view);
						list.addView(div);
						list.invalidate();
					}
					
					AsyncDownloadImageSearchFriends async = new AsyncDownloadImageSearchFriends(name, context, fragment);
					async.setListPictures(listForImages);
					
					fragment.getAsyncTaskList().add(async);
					
					async.execute(WSSearchUser.getResponse().getUsers());
				}
			}
		});

		Log.w("LoadingSearchFriendsAsync", "Ending Process - " + name);
		return null;
	}

}
