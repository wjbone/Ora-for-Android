package com.digitalgeko.mobile.android.ui;


public interface ScrollViewListener {

	void onScrollBottomReached(ScrollViewExt scrollView);

	void onScrollTopReached(ScrollViewExt scrollView);
	
}
