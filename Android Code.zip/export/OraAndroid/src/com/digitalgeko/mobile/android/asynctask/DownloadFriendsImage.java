package com.digitalgeko.mobile.android.asynctask;

import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.objects.facebook.FB_Friend;

@SuppressWarnings("unchecked")
public class DownloadFriendsImage extends AsyncTask<FB_Friend, Pair<Bitmap, ImageView>, Void> {
	
	private List<ImageView> listPictures;
	private String name;
	
	public DownloadFriendsImage(String name, Activity context){
		super();
		this.name = name;
	}

	public void setListPictures(List<ImageView> listPictures) {
		this.listPictures = listPictures;
	}
	
//	@Override
//	protected Void doInBackground(FB_Friend... params) {
//		Log.d("DownloadFriendsImage", name);
//		for(int i = 0; i < params.length; i++){
//			final FB_Friend temp = params[i];
//			temp.generateBitmap();
//			
//			final int temp_i = i;
//			context.runOnUiThread(new Runnable() {
//				public void run() {
//					listPictures.get(temp_i).setImageBitmap(temp.getBitmap_picture());
//					listPictures.get(temp_i).invalidate();
//				}
//			});
//		}
//		Log.i("DownloadFriendsImage", "Ending Process Images - " + name);
//		return null;
//	}
	
	@Override
	protected Void doInBackground(FB_Friend... params) {
		Log.w("DownloadFriendsImage", name);
		
		for(int i = 0; i < params.length; i++){
			FB_Friend temp = params[i];
			temp.generateBitmap();
			
			if(!isCancelled()){
				if(temp.getBitmap_picture() != null){
					Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
					tempPair[0] = new Pair<Bitmap, ImageView>(temp.getBitmap_picture(), listPictures.get(i));
					publishProgress(tempPair);
				}
			}else{
				break;
			}
		}
		
		Log.w("DownloadFriendsImage", "Ending Process Images - " + name);
		return null;
	}
	
	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for(Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;
			
			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}

}
