package com.digitalgeko.mobile.android.objects.facebook;

public class FB_Picture {

	private FB_Data_Picture data;

	public FB_Picture() {
		this.data = new FB_Data_Picture();
	}

	public FB_Data_Picture getData() {
		return data;
	}

	public void setData(FB_Data_Picture data) {
		this.data = data;
	}
	
}
