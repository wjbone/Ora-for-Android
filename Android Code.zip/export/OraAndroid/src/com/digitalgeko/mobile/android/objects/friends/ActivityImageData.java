package com.digitalgeko.mobile.android.objects.friends;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.MainActivity;
import net.ora.mobile.android.OraApplication;
import net.ora.mobile.android.R;
import net.ora.mobile.android.profile.ProfileManager;
import net.ora.mobile.android.ui.activities.OraSherlockActivity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class ActivityImageData extends OraSherlockActivity implements BaseImageData {
	
	protected List<ImageView> pictureImageViewList = new ArrayList<ImageView>();
	protected List<ImageView> circleImageViewList = new ArrayList<ImageView>();
	
	protected List<Bitmap> bitmapPictureList = new ArrayList<Bitmap>();
	protected List<AsyncTask<?,?,?>> asyncTaskList = new ArrayList<AsyncTask<?,?,?>>();
	protected List<ActionDialog<?>> actionDialogList = new ArrayList<ActionDialog<?>>();
	protected List<String> pictureNames = new ArrayList<String>();
	
	protected boolean downloadFlag = false;
	protected boolean prayerDetail = false;
	
	private boolean returnBackground = false;
	protected TextView titleView;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		ActionBar _actionBar = getSupportActionBar();

		_actionBar.setDisplayHomeAsUpEnabled(true);
		_actionBar.setDisplayShowTitleEnabled(false);
		_actionBar.setDisplayShowCustomEnabled(true);

		// Save action bar title view
		_actionBar.setCustomView(R.layout.custom_action_layout);
		View customView = _actionBar.getCustomView();
		titleView = (TextView) customView.findViewById(R.id.action_custom_title);
	}
	
	protected void setTitle(String title){
		titleView.setText(title);
	}
	
	@Override
	public void onDestroy(){
		super.onDestroy();
		cleanMemory();
	}
	
	@Override
	public void onPause(){
		super.onPause();
		
		if(downloadFlag){
			Log.e("ActivityImageData", "reciclando todos los bitmaps");
			for(Bitmap temp : bitmapPictureList){
				if(temp != null){
					temp.recycle();
				}
			}
			
			bitmapPictureList = new ArrayList<Bitmap>();
			returnBackground = true;
		}
	}
	
	@Override
	public void onResume(){
		super.onResume();
		if(returnBackground){
			Log.e("ActivityImageData", "Charging again the images");
			for(int i = 0; i < pictureNames.size(); i++){
				String name =  pictureNames.get(i);
				ImageView image = pictureImageViewList.get(i);
				System.out.println(name);
				if(name.length() > 0){
					Bitmap bmp = ImageManager.getImage(this, name);
					image.setImageBitmap(bmp);
					bitmapPictureList.add(bmp);
				}else{
					image.setImageResource(R.drawable.ic_launcher);
				}
			}
			Log.e("ActivityImageData", "ending the images");
		}
	}

	@Override
	public void cleanMemory() {
		// Stop async task list
		for(AsyncTask<?,?,?> temp : asyncTaskList){
			temp.cancel(true);
		}
		// Stop action dialog list
		for(ActionDialog<?> actionDialog : actionDialogList){
			actionDialog.cancel();
		}
		
		for(ImageView temp : pictureImageViewList){
			unbindDrawables(temp);
		}
		
		for(ImageView temp : circleImageViewList){
			unbindDrawables(temp);
		}
		
		for(Bitmap temp : bitmapPictureList){
			if(temp != null){
				temp.recycle();
			}
		}
		
		for(String temp : pictureNames){
			ImageManager.deleteImage(this, temp);
		}
		
		System.gc();
	}

	@Override
	public void unbindDrawables(View view) {
		if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            	unbindDrawables(((ViewGroup) view).getChildAt(i));
            }
            ((ViewGroup) view).removeAllViews();
        }
	}

	@Override
	public void goToAllPrayers() { }

	@Override
	public List<ImageView> getPictureImageViewList() {
		return pictureImageViewList;
	}

	@Override
	public List<ImageView> getCircleImageViewList() {
		return circleImageViewList;
	}

	@Override
	public List<Bitmap> getBitmapPictureList() {
		return bitmapPictureList;
	}

	@Override
	public List<AsyncTask<?,?,?>> getAsyncTaskList() {
		return asyncTaskList;
	}
	
	@Override
	public List<ActionDialog<?>> getActionDialogList() {
		return actionDialogList;
	}

	@Override
	public List<String> getPictureNames() {
		return pictureNames;
	}

	@Override
	public boolean isDownloadFlag() {
		return downloadFlag;
	}

	@Override
	public void setDownloadFlag(boolean flag) {
		downloadFlag = flag;
	}

	@Override
	public boolean isPrayerDetail() {
		return prayerDetail;
	}

	@Override
	protected void onStart() {
		super.onStart();
		
		ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
		if(manager.isGoToProfileSettings()) {
			finish();
		} else if(manager.isLogout()) {
			finish();
		}
	}
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	if(MainActivity.shouldShowOldMenu()) {
    		MenuInflater inflater = getSupportMenuInflater();
    		inflater.inflate(R.menu.base_menu, menu);
    		return true;
    	} else {
    		return super.onCreateOptionsMenu(menu);
    	}
    }
    

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			finish();
			break;
		} case R.id.menu__base_setting: {
			ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
			manager.setGoToProfileSettings(true);
			finish();
			return true;
		} case R.id.menu__base_logout: {
			ProfileManager manager = ((OraApplication) getApplication()).getProfileManager();
			manager.setLogout(true);
			finish();
			return true;
		} default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}
}
