package com.digitalgeko.mobile.android.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;

public abstract class ActionDialog<T> {

	protected ProgressDialog dialog;
	protected Handler mHandler;
	protected boolean ready;
	private boolean isCancelled;
	protected Context context;
	private T result;
	private Thread thread;
	
	public ActionDialog(Context context) {
		// Configure context
		this.context = context;
		setCancelled(false);
	}
	
	public Context getContext() {
		return context;
	}
	
	public void init() {
		if(UIConfiguration.shouldMakeNextAction()) {
			T preActionResponse = preAction();
			if(preActionResponse == null) {
				dialog = ProgressDialog.show(context, "", "Loading");
				thread = new Thread() {
					public void run() {
						dialog.show();
						ready = false;
						
						// Make request
						result = performAction();
						
						ready = true;
					}
				};
				thread.start();
				mHandler = new Handler();
				mHandler.removeCallbacks(stopProgressBar);
				mHandler.postDelayed(stopProgressBar, 50);
			} else {
				afterAction(preActionResponse);
			}
			finallyAction();
		}
	}
	
	private Runnable stopProgressBar = new Runnable() {
		public void run() {
			if(!ready && !isCancelled()){
				mHandler.postDelayed(stopProgressBar, 50);
			}else{
				dialog.dismiss();
				dialog.cancel();
				if(!isCancelled) {
					afterAction(result);
				}
			}
		}
	};
	
	public T preAction() {
		return null;
	}
	
	public abstract T performAction();
	
	public abstract void afterAction(T result);
	
	public void finallyAction() {};

	public boolean isCancelled() {
		return isCancelled;
	}

	private void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public void cancel() {
		setCancelled(true);
	}
	
}
