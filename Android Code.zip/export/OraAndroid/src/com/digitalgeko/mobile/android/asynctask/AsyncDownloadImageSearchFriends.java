package com.digitalgeko.mobile.android.asynctask;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.objects.FriendUser;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

@SuppressWarnings("unchecked")
public class AsyncDownloadImageSearchFriends extends AsyncTask<FriendUser, Pair<Bitmap, ImageView>, Void> {

	private List<ImageView> listPictures;
	private String name;
	
	public AsyncDownloadImageSearchFriends(String name, Context context, BaseImageData fragment){
		super();
		this.name = name;
	}

	public void setListPictures(List<ImageView> listPictures) {
		this.listPictures = listPictures;
	}

//	@Override
//	protected Void doInBackground(FriendUser... params) {
//		Log.w("AsyncDownloadImageSearchFriends", name);
//		for(int i = 0; i < params.length; i++){
//			if(params[i].getPicture().trim().length() > 0){
//				final Bitmap temp = GeneralMethods.downloadImage(params[i].getPicture());
//				//fragment.getBitmapPictureList().add(temp);
//				
//				Log.w("AsyncDownloadImageSearchFriends", "done");
//				
//				final int temp_i = i;
//				context.runOnUiThread(new Runnable() {
//					@Override
//					public void run() {
//						listPictures.get(temp_i).setImageBitmap(temp);
//						listPictures.get(temp_i).invalidate();
//					}
//				});
//			}
//		}
//		Log.w("AsyncDownloadImageSearchFriends", "Ending Process Images - " + name);
//		
//		return null;
//	}
	
	@Override
	protected Void doInBackground(FriendUser... params) {
		Log.w("AsyncDownloadImageSearchFriends", name);
		
		for(int i = 0; i < params.length; i++){
			if(params[i].getPicture().trim().length() > 0){
				Bitmap temp = GeneralMethods.downloadImage(params[i].getPicture());
				Log.w("AsyncDownloadImageSearchFriends", "done");
				
				if(!isCancelled()) {
					Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
					tempPair[0] = new Pair<Bitmap, ImageView>(temp, listPictures.get(i));
					publishProgress(tempPair);
				} else {
					break;
				}
			}
		}
		
		Log.w("AsyncDownloadImageSearchFriends", "Ending Process Images - " + name);
		
		return null;
	}
	
	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for(Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;
			
			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}
	
}
