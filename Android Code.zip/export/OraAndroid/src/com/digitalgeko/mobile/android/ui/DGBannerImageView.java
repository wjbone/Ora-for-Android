package com.digitalgeko.mobile.android.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class DGBannerImageView extends ImageView {

	// Constructor
	public DGBannerImageView(Context context) {
		super(context);
	}
	
	public DGBannerImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public DGBannerImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	// Overriden methods
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		if (getDrawable() != null) {
			int width = MeasureSpec.getSize(widthMeasureSpec);
			int height = width * getDrawable().getIntrinsicHeight() / getDrawable().getIntrinsicWidth();
			setMeasuredDimension(width, height);
		} else {
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		}
	}
}