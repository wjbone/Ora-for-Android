package com.digitalgeko.mobile.android.objects.friends;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;
import net.ora.mobile.android.webservices.profile.WSRequestFriend;
import net.ora.mobile.dto.profile.response.RequestFriendResponse;
import android.app.Activity;
import android.widget.Button;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.ui.ActionDialog;

public class RequestFriendsDialog extends ActionDialog<RequestFriendResponse> {

	private Button button;
	private FriendProfileUser user;
	
	public RequestFriendsDialog(Activity context, Button button, FriendProfileUser user) {
		super(context);
		this.button = button;
		this.user = user;
	}

	@Override
	public RequestFriendResponse performAction() {
		return WSRequestFriend.requestFriend(context, user.getId());
	}

	@Override
	public void afterAction(RequestFriendResponse result) {
		if(MasterService.isFailedConnection()){
			GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
		}else{
			if(result.isStatus()){
				user.setFriend(result.isFriend());
				user.setRequested(result.isRequested());
				
				if(result.isFriend()){
					button.setText(context.getString(R.string.profile_friend_is));
				}else if(result.isRequested()){
					button.setText(context.getString(R.string.profile_friend_pending));
				}else{
					button.setText(context.getString(R.string.profile_friend_add));
				}
			}else{
				GeneralMethods.crearDialogoOk(MasterService.getErrorMessage(), context);
			}
		}
	}

}
