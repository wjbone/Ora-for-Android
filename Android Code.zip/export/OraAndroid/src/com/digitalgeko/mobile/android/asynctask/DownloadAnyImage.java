package com.digitalgeko.mobile.android.asynctask;

import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.helpers.profile.ImageManager;

@SuppressWarnings("unchecked")
public class DownloadAnyImage extends AsyncTask<String, Pair<Bitmap, ImageView>, Void> {

	private List<ImageView> listPictures;
	private String name;
	private Activity context;

	public DownloadAnyImage(String name, Activity context) {
		super();
		this.name = name;
		this.context = context;
	}

	public void setListPictures(List<ImageView> listPictures) {
		this.listPictures = listPictures;
	}

	// @Override
	// protected Void doInBackground(String... params) {
	// Log.w("DownloadAnyImage", name);
	//
	// for(int i = 0; i < params.length; i++){
	// final Bitmap temp = GeneralMethods.downloadImage(params[i]);
	// //result.add(temp);
	//
	// Log.w("DownloadAnyImage", "done");
	//
	// final int temp_i = i;
	// context.runOnUiThread(new Runnable() {
	// @Override
	// public void run() {
	// listPictures.get(temp_i).setImageBitmap(temp);
	// listPictures.get(temp_i).invalidate();
	// }
	// });
	// }
	//
	// Log.w("DownloadAnyImage", "Ending Process Images - " + name);
	//
	// return null;
	// }

	@Override
	protected Void doInBackground(String... params) {
		Log.w("DownloadAnyImage", name);

		for (int i = 0; i < params.length; i++) {
			try {
				// Bitmap temp = GeneralMethods.downloadImage(params[i]);
				Bitmap temp = ImageManager.downloadCachedImage(context, params[i], 0L).getBitmap();
				Log.w("DownloadAnyImage", "done");
				
				if (!isCancelled()) {
					if (temp != null) {
						Pair<Bitmap, ImageView>[] tempPair = new Pair[1];
						tempPair[0] = new Pair<Bitmap, ImageView>(temp, listPictures.get(i));
						publishProgress(tempPair);
					}
				} else {
					break;
				}
			} catch (Exception e) {
				Log.e("DownloadAnyImage", "Error downloading");
			}
		}

		Log.w("DownloadAnyImage", "Ending Process Images - " + name);

		return null;
	}

	@Override
	protected void onProgressUpdate(Pair<Bitmap, ImageView>... values) {
		super.onProgressUpdate(values);

		for (Pair<Bitmap, ImageView> value : values) {
			Bitmap bitmap = value.first;
			ImageView imageView = value.second;

			// Set new bitmap
			imageView.setImageBitmap(bitmap);
			imageView.invalidate();
		}
	}

}
