package com.digitalgeko.mobile.android.ui;

import java.util.List;

import net.ora.mobile.android.R;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.actionbarsherlock.app.SherlockFragment;

public class DGFragment extends SherlockFragment {

	private StackTabManager tabListener;

	private View viewInitial;

	public void setTabListener(StackTabManager tabListener) {
		this.tabListener = tabListener;
	}

	public StackTabManager getTabListener() {
		return tabListener;
	}

	public View getViewInitial() {
		return viewInitial;
	}

	public void setViewInitial(View viewInitial) {
		this.viewInitial = viewInitial;
	}

	protected boolean isShowKeyboard() {
		return true;
	}

	public void pushFragment(DGFragment fragment) {
		((BaseFragmentActivity<?>) getActivity()).pushFragment(fragment);
	}

	protected void popFragment() {
		((BaseFragmentActivity<?>) getActivity()).popFragment();
	}

	protected void popAllFragments(DGFragment fragment) {
		((BaseFragmentActivity<?>) getActivity()).popAllFragments(fragment);
	}

	// @Override
	// public void onActivityCreated(Bundle savedInstanceState) {
	// super.onActivityCreated(savedInstanceState);
	// }

	@Override
	public void onStart() {
		super.onStart();

		// Search
		List<View> views = getView().getFocusables(View.FOCUS_FORWARD);
		setViewInitial(null);
		for (View view : views) {
			if (view instanceof EditText) {
				setViewInitial(view);
				break;
			}
		}

		// Show keyboard
		if (isShowKeyboard()) {
			showKeyboard(getViewInitial());
		}
	}

	@Override
	public void onDetach() {
		hideKeyboard(getViewInitial());
		super.onDetach();
		UIConfiguration.setShouldMakeNextAction(true);
	}

	public void onFragmentDetach() {
		super.onDetach();
	}

	protected int getActionBarString() {
		return R.string.app_name;
	}

	public static void hideKeyboard(View view) {
		// Hide keyboard
		if (view != null) {
			InputMethodManager im = (InputMethodManager) view.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			view.clearFocus();
			im.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
		}
	}

	public static void showKeyboard(View view) {
		// Show keyboard
		if (view != null) {
			view.requestFocus();
			InputMethodManager imm = (InputMethodManager) view.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			// imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
			imm.showSoftInput(view, 0);
		}
	}

}
