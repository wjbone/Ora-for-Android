package com.digitalgeko.mobile.android.objects.profile;

import java.util.List;

import com.digitalgeko.mobile.android.ui.ActionDialog;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ImageView;

public interface BaseImageData {
	
	public List<ImageView> getPictureImageViewList();
	public List<ImageView> getCircleImageViewList();
	
	public List<Bitmap> getBitmapPictureList();
	
	public List<AsyncTask<?,?,?>> getAsyncTaskList();
	
	public List<ActionDialog<?>> getActionDialogList();
	
	public List<String> getPictureNames();
	
	public boolean isDownloadFlag();
	public boolean isPrayerDetail();
	
	public void setDownloadFlag(boolean flag);
	
	public void cleanMemory();
	
	public void unbindDrawables(View view);
	
	public void goToAllPrayers();
	
}
