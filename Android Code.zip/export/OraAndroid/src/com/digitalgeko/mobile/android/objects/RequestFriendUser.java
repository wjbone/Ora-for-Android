package com.digitalgeko.mobile.android.objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestFriendUser extends FriendUser {
	
	@JsonProperty(value="fb_id")
	private String fbId;
	
	@JsonProperty(value="tw_id")
	private String twId;

	public String getFbId() {
		return fbId;
	}

	public void setFbId(String fbId) {
		this.fbId = fbId;
	}

	public String getTwId() {
		return twId;
	}

	public void setTwId(String twId) {
		this.twId = twId;
	}
	
	
	
	/*
	 * CONSTRUCTORS 
	 */
	public RequestFriendUser() {
	}
	
	public RequestFriendUser(FriendUser that) {
		this.setBlocked(that.isBlocked());
		this.setCity(that.getCity());
		this.setFbId("");
		this.setFriend(that.isFriend());
		this.setId(that.getId());
		this.setName(that.getName());
		this.setPicture(that.getPicture());
		this.setRequested(that.isRequested());
		this.setTwId("");
	}
}
