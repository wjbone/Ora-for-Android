package com.digitalgeko.mobile.android.helpers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import java.util.Vector;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;

import net.ora.mobile.android.R;
import net.ora.mobile.android.webservices.MasterService;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.loopj.android.http.PersistentCookieStore;

public final class ConnectionHelper {

	public static enum CONNECTION_TYPE {
		GET, POST
	};

	public static String getJsonObject(Context context, String domainUrl, String url, CONNECTION_TYPE type,
			Vector<NameValuePair> vars, CustomHttpEntityBuilder customHttpEntityBuilder) throws ClientProtocolException,
			IOException {

		String finalUrl = domainUrl + url;
		AbstractHttpClient client = new DefaultHttpClient();
		HttpRequestBase request;
		PersistentCookieStore cookieStore = new PersistentCookieStore(context);
		HttpResponse response;
		String strResponse = null;

		if (type.equals(CONNECTION_TYPE.POST)) {
			// Url request
			request = new HttpPost(finalUrl);
			// Add parameters
			if (customHttpEntityBuilder == null) {
				((HttpPost) request).setEntity(new UrlEncodedFormEntity(vars));
			} else {
				customHttpEntityBuilder.build(vars, (HttpPost) request);
			}
		} else {
			// Add parameter
			String paramString = URLEncodedUtils.format(vars, "utf-8");
			finalUrl += "?" + paramString;

			request = new HttpGet(finalUrl);
		}

		// Log
		Log.i("url", finalUrl);
		Log.d("parametros", vars.toString());

		HttpParams params = client.getParams();
		int timeoutConnection = 60000;
		HttpConnectionParams.setConnectionTimeout(params, timeoutConnection);
		int timeoutSocket = 120000;
		HttpConnectionParams.setSoTimeout(params, timeoutSocket);

		for (Cookie cookie : cookieStore.getCookies()) {
			Log.i("Cookie", cookie.getName() + ": " + cookie.getValue());
		}

		HttpContext localContext = new BasicHttpContext();
		localContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);

		if (MasterService.IS_PRODUCTION_SERVER) {
			// ====================================================================================================================
			// HTTP
			// client = new DefaultHttpClient(params);
			// response = client.execute(request, localContext);

			// DgHttpClient dgClient = new DgHttpClient();
			// dgClient.getContext().setAttribute(ClientContext.COOKIE_STORE, cookieStore);
			// response = dgClient.getResponseFromUrl(request);
			// ====================================================================================================================

			Log.i("Man:", Build.MANUFACTURER);
			if (!(Build.MANUFACTURER != "SAMSUNG" && Build.VERSION.SDK_INT == Build.VERSION_CODES.GINGERBREAD_MR1)) {
				client = new MyHttpClient(params, context);
				response = client.execute(request, localContext);
			} else {
				// APIS
				HostnameVerifier hostnameVerifier = org.apache.http.conn.ssl.SSLSocketFactory.STRICT_HOSTNAME_VERIFIER;
				SchemeRegistry registry = new SchemeRegistry();
				SSLSocketFactory socketFactory = SSLSocketFactory.getSocketFactory();
				socketFactory.setHostnameVerifier((X509HostnameVerifier) hostnameVerifier);
				registry.register(new Scheme("https", socketFactory, 443));
				ThreadSafeClientConnManager mgr = new ThreadSafeClientConnManager(params, registry);
				DefaultHttpClient httpClient = new DefaultHttpClient(mgr, params);
				// Set verifier
				HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
				// Example send http request
				response = httpClient.execute(request, localContext);
			}
		} else {
			// HTTPS for DEV
			// este es el que se cambie para que acepte el nuevo server.
			client = new MyHttpClient(params, context);
			response = client.execute(request, localContext);
		}

		for (Header header : response.getAllHeaders()) {
			Log.i("Header response", header.getName() + ": " + header.getValue());
		}
		for (Cookie cookie : cookieStore.getCookies()) {
			Log.i("Cookie", cookie.getName() + ": " + cookie.getValue());
		}

		Log.i("Inicial Json", response.getStatusLine().toString());
		HttpEntity entity = response.getEntity();
		if (entity != null) {
			InputStream instream = entity.getContent();
			strResponse = convertStreamToString(instream);
			Log.i("Result Stream", strResponse);
		}

		return strResponse;
	}

	private static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	/**
	 * Clase para realizar conexiones hacia certificados autogenerados o no v�lidos, este debe ser envevido en la aplicaci�n para
	 * poder ser validado.
	 */

	static class MyHttpClient extends DefaultHttpClient {

		private Context context;

		public MyHttpClient(HttpParams params, Context context) {
			super(params);
			this.context = context;
		}

		@Override
		protected ClientConnectionManager createClientConnectionManager() {
			SchemeRegistry registry = new SchemeRegistry();
			// registry.register(new Scheme("http",
			// PlainSocketFactory.getSocketFactory(), 80));
			// Register for port 443 our SSLSocketFactory with our keystore
			// to the ConnectionManager
			// registry.register(new Scheme("https", newSslSocketFactory(),
			// 9080));
			registry.register(new Scheme("https", newSslSocketFactory(), 443));
			return new SingleClientConnManager(getParams(), registry);
		}

		private SSLSocketFactory newSslSocketFactory() {
			try {
				// Get an instance of the Bouncy Castle KeyStore format
				KeyStore trusted = KeyStore.getInstance("BKS");
				// Get the raw resource, which contains the keystore with
				// your trusted certificates (root and any intermediate certs)

				InputStream in;
				if (MasterService.IS_PRODUCTION_SERVER) {
					// APIS
					in = context.getResources().openRawResource(R.raw.ora_apis_certificate);
				} else {
					// DEV
					in = context.getResources().openRawResource(R.raw.ora);
				}
				
				try {
					// Initialize the keystore with the provided trusted
					// certificates
					// Also provide the password of the keystore
					trusted.load(in, "qwerty".toCharArray());
				} finally {
					in.close();
				}
				// Pass the keystore to the SSLSocketFactory. The factory is
				// responsible
				// for the verification of the server certificate.
				SSLSocketFactory sf = new SSLSocketFactory(trusted);
				// Hostname verification from certificate
				// http://hc.apache.org/httpcomponents-client-ga/tutorial/html/connmgmt.html#d4e506
				sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
				return sf;
			} catch (Exception e) {
				throw new AssertionError(e);
			}
			// return null;
		}
	}

	public static interface CustomHttpEntityBuilder {

		public void build(Vector<NameValuePair> vars, HttpPost request);
	}

}
