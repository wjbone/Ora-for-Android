package com.digitalgeko.mobile.android.objects.profile;

import java.util.ArrayList;
import java.util.List;

import net.ora.mobile.android.R;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.ui.ActionDialog;
import com.digitalgeko.mobile.android.ui.DGFragment;

public class FragmentImageData extends DGFragment implements BaseImageData {
	
	protected List<ImageView> pictureImageViewList = new ArrayList<ImageView>();
	protected List<ImageView> circleImageViewList = new ArrayList<ImageView>();
	
	protected List<Bitmap> bitmapPictureList = new ArrayList<Bitmap>();
	
	protected List<AsyncTask<?,?,?>> asyncTaskList = new ArrayList<AsyncTask<?,?,?>>();
	
	protected List<ActionDialog<?>> actionDialogList = new ArrayList<ActionDialog<?>>();
	
	protected List<String> pictureNames = new ArrayList<String>();
	
	protected boolean downloadFlag = false;
	protected boolean prayerDetail = false;
	
	private boolean returnBackground = false;

	@Override
	public void onDestroy(){
		super.onDestroy();
		cleanMemory();
	}
	
	@Override
	public void onPause(){
		super.onPause();
		
		if(downloadFlag){
			Log.e("FragmentImageData", "reciclando todos los bitmaps");
			for(Bitmap temp : bitmapPictureList){
				if(temp != null){
					temp.recycle();
				}
			}
			
			bitmapPictureList = new ArrayList<Bitmap>();
			returnBackground = true;
		}
	}
	
	@Override
	public void onResume(){
		super.onResume();
		if(returnBackground){
			Log.e("ActivityImageData", "Charging again the images");
			for(int i = 0; i < pictureNames.size(); i++){
				String name =  pictureNames.get(i);
				ImageView image = pictureImageViewList.get(i);
				System.out.println(name);
				if(name.length() > 0){
					Bitmap bmp = ImageManager.getImage(getActivity(), name);
					image.setImageBitmap(bmp);
					bitmapPictureList.add(bmp);
				}else{
					image.setImageResource(R.drawable.ic_launcher);
				}
			}
			Log.e("ActivityImageData", "ending the images");
		}
	}

	@Override
	public void cleanMemory() {
		for(AsyncTask<?,?,?> temp : asyncTaskList){
			temp.cancel(true);
		}
		
		// Stop action dialog list
		for(ActionDialog<?> actionDialog : actionDialogList){
			actionDialog.cancel();
		}

		for(ImageView temp : pictureImageViewList){
			unbindDrawables(temp);
		}
		
		for(ImageView temp : circleImageViewList){
			unbindDrawables(temp);
		}
		
		for(Bitmap temp : bitmapPictureList){
			if(temp != null){
				temp.recycle();
			}
		}
		
		System.gc();
	}

	@Override
	public void unbindDrawables(View view) {
		if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            	unbindDrawables(((ViewGroup) view).getChildAt(i));
            }
            ((ViewGroup) view).removeAllViews();
        }
	}

	@Override
	public void goToAllPrayers() { }

	@Override
	public List<ImageView> getPictureImageViewList() {
		return pictureImageViewList;
	}

	@Override
	public List<ImageView> getCircleImageViewList() {
		return circleImageViewList;
	}

	@Override
	public List<Bitmap> getBitmapPictureList() {
		return bitmapPictureList;
	}

	@Override
	public List<AsyncTask<?,?,?>> getAsyncTaskList() {
		return asyncTaskList;
	}

	@Override
	public List<ActionDialog<?>> getActionDialogList() {
		return actionDialogList;
	}

	@Override
	public List<String> getPictureNames() {
		return pictureNames;
	}

	@Override
	public boolean isDownloadFlag() {
		return downloadFlag;
	}

	@Override
	public void setDownloadFlag(boolean flag) {
		downloadFlag = flag;
	}

	@Override
	public boolean isPrayerDetail() {
		return prayerDetail;
	}

}
