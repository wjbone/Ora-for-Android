package com.digitalgeko.mobile.android.asynctask;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.widget.ImageView;

import com.digitalgeko.mobile.android.accesories.GeneralMethods;
import com.digitalgeko.mobile.android.asynctask.AsyncDownloadImage.InfoHolder;
import com.digitalgeko.mobile.android.helpers.profile.ImageManager;
import com.digitalgeko.mobile.android.objects.profile.BaseImageData;

public class AsyncDownloadImage extends AsyncTask<Pair<String, ImageView>, InfoHolder, Void> {

	private Context context;
	private String name;
	private BaseImageData fragment;
	private boolean shouldResize = true;

	public AsyncDownloadImage(String name, Context context, BaseImageData fragment) {
		super();
		this.name = name;
		this.context = context;
		this.fragment = fragment;
	}

	public void setShouldResize(boolean shouldResize) {
		this.shouldResize = shouldResize;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Void doInBackground(Pair<String, ImageView>... params) {
		int width = GeneralMethods.getProfileImageWidth(context);

		Log.d("Download Short User Image", name);
		for (int i = 0; i < params.length; i++) {
			String url = params[i].first;
			ImageView imageView = params[i].second;

			if (url.length() > 0) {
				try {
					Bitmap base = ImageManager.downloadCachedImage(context, url, 0L).getBitmap();
					Bitmap temp = base;
					if (shouldResize) {
						temp = Bitmap.createScaledBitmap(base, width, width, false);
						base.recycle();
					}

					if (!isCancelled()) {
						fragment.getBitmapPictureList().add(temp);
						InfoHolder tempHolder = new InfoHolder();
						tempHolder.url = url;
						tempHolder.bitmap = temp;
						tempHolder.imageView = imageView;
						publishProgress(tempHolder);
					}
				} catch (Exception e) {
				}
			}

			if (isCancelled()) {
				break;
			}
		}
		Log.i("Download Short User Image", "Ending Process Images - " + name);

		return null;
	}

	@Override
	protected void onProgressUpdate(InfoHolder... values) {
		super.onProgressUpdate(values);

		for (InfoHolder value : values) {
			Bitmap bitmap = value.bitmap;
			ImageView imageView = value.imageView;

			// Set new bitmap
			Object tag = value.imageView.getTag();
			if (tag != null && value.url.equals(tag)) {
				imageView.setImageBitmap(bitmap);
				imageView.invalidate();
			}
		}
	}

	public static class InfoHolder {
		public ImageView imageView;
		public String url;
		public Bitmap bitmap;
	}
}
