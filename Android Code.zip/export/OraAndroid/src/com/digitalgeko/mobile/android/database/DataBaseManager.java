package com.digitalgeko.mobile.android.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseManager extends SQLiteOpenHelper {

	/**
	 * General DataBase Syntax
	 */
	public static final String CREATE_TABLE = "CREATE TABLE ";
	public static final String ALTER_TABLE = "ALTER TABLE ";
	public static final String ADD_COLUMN = " ADD COLUMN ";
	
	public static final String PRIMARY_KEY = " INTEGER PRIMARY KEY AUTOINCREMENT, ";
	public static final String FOREIGN_KEY = "FOREIGN KEY"; 
	public static final String REFERENCES = "REFERENCES ";
	public static final String UNIQUE = " UNIQUE";
	public static final String NOT_NULL = " NOT NULL";
	public static final String TYPE_TEXT = " TEXT";
	public static final String TYPE_INTEGER = " INTEGER";
	public static final String TYPE_NUMERIC = " NUMERIC";
	public static final String TYPE_FECHA = " CURRENT_DATE";
	public static final String TYPE_HORA = " CURRENT_TIME";
	public static final String TYPE_DATE = " CURRENT_TIMESTAMP";
	
	/**
	 * General Information of the DataBase
	 */
	public static final String DATABASE_NAME = "Ora.db";
	public static final int DATABASE_VERSION = 2;
	
	/**
	 * User Ora Table
	 */
	public static final String USER_ORA_TABLE = "UserOraTable";
	public static final String USER_ORA_FIELD_ID = "UserOraId";
	public static final String USER_ORA_FIELD_ABOUT = "UserOraAbout";
	public static final String USER_ORA_FIELD_CITY = "UserOraCity";
	public static final String USER_ORA_FIELD_EMAIL = "UserOraEmail";
	public static final String USER_ORA_FIELD_FACEBOOK_ID = "UserOraFacebookId";
	public static final String USER_ORA_FIELD_MOBILE = "UserOraMobile";
	public static final String USER_ORA_FIELD_NAME = "UserOraName";
	public static final String USER_ORA_FIELD_PROFILE_PICTURE = "UserOraProfilePicture";
	public static final String USER_ORA_FIELD_TWITTER_ID = "UserOraTwitterId";
	public static final String USER_ORA_FIELD_USERNAME = "UserOraUsername";
	public static final String USER_ORA_FIELD_HAVE_HOUR = "UserOraHour";
	public static final String USER_ORA_FIELD_ORA_ID = "UserOraIdentifier";
	public static final String USER_ORA_FIELD_HAVE_MINUTE = "UserOraMinute";
	public static final String USER_ORA_FIELD_NOTIFICATIONS_COUNT = "UserOraNotificationsCount";
	public static final String USER_ORA_FIELD_HAVE_NOTIFICATION = "UserOraHaveNotification";
	public static final String USER_ORA_FIELD_IGNORE_LITE = "UserOraIgnoreLite";
	public static final String USER_ORA_FIELD_PREMIUM = "UserOraPremium";
	
	public static final String USER_ORA_ID = "1";

	public DataBaseManager(Context context){
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE + USER_ORA_TABLE +
				   " (" + USER_ORA_FIELD_ID + PRIMARY_KEY +
				   USER_ORA_FIELD_CITY + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_ABOUT + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_NAME + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_MOBILE + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_NOTIFICATIONS_COUNT + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_FACEBOOK_ID + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_ORA_ID + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_PREMIUM + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_PROFILE_PICTURE + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_TWITTER_ID + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_EMAIL + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_USERNAME + TYPE_TEXT + ", " +
				   USER_ORA_FIELD_HAVE_NOTIFICATION + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_HAVE_HOUR + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_HAVE_MINUTE + TYPE_INTEGER + ", " +
				   USER_ORA_FIELD_IGNORE_LITE + TYPE_INTEGER + ");");
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		
	}

}
